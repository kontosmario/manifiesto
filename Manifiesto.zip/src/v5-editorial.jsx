// V5 — "Editorial minimal"
// Estilo revista financiera cálida: mucho espacio, tipografía serif protagonista,
// números enormes, poca UI. Contención, calma, confianza. Menos gamificación,
// más respiración. Imagen de calidad editorial para quien no quiere "app
// de finanzas" pero sí control.

function V5Editorial() {
  return (
    <div className="screen" style={{ background:'#FAF4EA', color:'#0F2A1E' }}>
      <StatusBar color="#0F2A1E"/>

      {/* masthead */}
      <div style={{ padding:'6px 24px 0', display:'flex', justifyContent:'space-between', alignItems:'center', borderBottom:'1px solid #EFE8D9', paddingBottom:10 }}>
        <div className="serif" style={{ fontSize:13, fontWeight:700, letterSpacing:3, textTransform:'uppercase' }}>Manifiesto</div>
        <div style={{ fontSize:10, color:'#6F7A73', fontWeight:600, letterSpacing:1 }}>MARTES · ABRIL 22</div>
        <div style={{ display:'flex', gap:6 }}>
          <div style={{ width:28, height:28, display:'grid', placeItems:'center', border:'1px solid #EFE8D9', borderRadius:999 }}><BellIcon/></div>
        </div>
      </div>

      {/* kicker */}
      <div style={{ padding:'20px 24px 0', animation:'mf-rise .8s ease both' }}>
        <div style={{ fontSize:10, letterSpacing:2, fontWeight:700, color:'#E08E63' }}>HOY · DISPONIBLE</div>
      </div>

      {/* giant amount */}
      <div style={{ padding:'4px 24px 0', animation:'mf-rise 1s .1s ease both' }}>
        <div className="serif" style={{
          fontSize:66, fontWeight:600, letterSpacing:-2.5, lineHeight:0.95, color:'#0F2A1E',
          fontVariationSettings:'"opsz" 144',
        }}>
          <CountUp to={4455000} duration={1600} prefix="$"/>
        </div>
        <div style={{ marginTop:10, fontSize:13, color:'#6F7A73', lineHeight:1.4, fontFamily:'Instrument Serif, Fraunces, serif', fontStyle:'italic' }}>
          &ldquo;Margen del mes <span style={{ color:'#0F2A1E', fontWeight:600 }}>+$2.535.000</span> — el mejor martes en seis semanas.&rdquo;
        </div>
      </div>

      {/* hairline + next cobro */}
      <div style={{ padding:'16px 24px 0', display:'flex', gap:18, alignItems:'center', animation:'mf-rise .9s .2s ease both' }}>
        <div style={{ flex:1, height:1, background:'#E9E1D3' }}/>
        <div style={{ fontSize:10, color:'#6F7A73', fontWeight:600, letterSpacing:1.4 }}>PRÓX · COBRO 19 MAY</div>
        <div style={{ flex:1, height:1, background:'#E9E1D3' }}/>
      </div>

      {/* area chart */}
      <div style={{ padding:'14px 16px 0', animation:'mf-rise 1s .25s ease both' }}>
        <EditorialAreaChart/>
      </div>

      {/* three col stats */}
      <div style={{ padding:'10px 24px 0', display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:14, animation:'mf-rise .9s .35s ease both' }}>
        <EditorialStat label="AHORRO" value="1.920k" delta="+14%" up/>
        <EditorialStat label="GASTO" value="685k" delta="-8%" up sep/>
        <EditorialStat label="FIJOS" value="0" delta="ok" up sep/>
      </div>

      {/* category breakdown */}
      <div style={{ padding:'20px 24px 0', animation:'mf-rise .9s .45s ease both' }}>
        <div style={{ fontSize:10, letterSpacing:2, fontWeight:700, color:'#6F7A73', marginBottom:10 }}>DÓNDE VA EL DINERO</div>
        <CategoryBar items={[
          { label:'Casa',      pct: 42, color:'#0F2A1E' },
          { label:'Comida',    pct: 26, color:'#E08E63' },
          { label:'Transporte',pct: 14, color:'#2E7D5B' },
          { label:'Ocio',      pct: 10, color:'#F1D690' },
          { label:'Otros',     pct:  8, color:'#9AA39D' },
        ]}/>
      </div>

      {/* closing note */}
      <div style={{ padding:'16px 24px 0', animation:'mf-rise .9s .55s ease both', display:'flex', gap:12, alignItems:'center' }}>
        <div style={{ display:'flex' }}>
          {FAMILY.slice(0,3).map((f,i)=>(
            <div key={i} style={{ marginLeft:i===0?0:-8 }}>
              <Avatar name={f.name} color={f.color} size={22} ring ringColor="#FAF4EA"/>
            </div>
          ))}
        </div>
        <div className="serif" style={{ fontSize:13, fontStyle:'italic', color:'#6B3A4F', flex:1, lineHeight:1.35 }}>
          Tres personas registraron gastos hoy. Todo dentro del plan.
        </div>
      </div>

      {/* FAB */}
      <button style={{
        position:'absolute', bottom:112, right:22, width:56, height:56, border:'none', borderRadius:999,
        background:'#0F2A1E', color:'#FFFBF2', fontSize:26, fontWeight:700, cursor:'pointer',
        boxShadow:'0 10px 20px -8px rgba(15,42,30,0.4)', animation:'mf-pulse 2.4s 1.6s infinite',
      }}>+</button>

      <TabBar accent="#F2B58A" bg="#FAF4EA"/>
    </div>
  );
}

function EditorialAreaChart() {
  const data = [22,28,26,33,31,38,36,42,40,47,52,58,55,62];
  const w = 380, h = 100, pad = 16;
  const max = Math.max(...data), min = Math.min(...data);
  const pts = data.map((v,i)=>{
    const x = pad + (i/(data.length-1))*(w-2*pad);
    const y = pad + (1 - (v-min)/(max-min))*(h-2*pad);
    return [x,y];
  });
  const d = pts.map((p,i)=>(i===0?'M':'L')+p[0].toFixed(1)+' '+p[1].toFixed(1)).join(' ');
  const area = d + ` L ${w-pad} ${h-pad} L ${pad} ${h-pad} Z`;
  const ref = useRef();
  useEffect(()=>{
    if (!ref.current) return;
    const len = ref.current.getTotalLength();
    ref.current.style.strokeDasharray = len;
    ref.current.style.strokeDashoffset = len;
    ref.current.style.animation = 'mf-draw 1.6s 600ms ease forwards';
  },[]);
  return (
    <svg width="100%" height={h} viewBox={`0 0 ${w} ${h}`}>
      <defs>
        <linearGradient id="areaFill" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#E08E63" stopOpacity="0.25"/>
          <stop offset="1" stopColor="#E08E63" stopOpacity="0"/>
        </linearGradient>
      </defs>
      <path d={area} fill="url(#areaFill)" style={{ animation:'mf-fade 1s 1.2s both' }}/>
      <path ref={ref} d={d} fill="none" stroke="#E08E63" strokeWidth="2" strokeLinecap="round"/>
      <circle cx={pts[pts.length-1][0]} cy={pts[pts.length-1][1]} r="4" fill="#0F2A1E"
        style={{ animation:'mf-fade .4s 1.8s both, mf-breathe 2s 2s ease-in-out infinite' }}/>
    </svg>
  );
}

function EditorialStat({ label, value, delta, up, sep }) {
  return (
    <div style={{ position:'relative', paddingLeft: sep?14:0 }}>
      {sep && <div style={{ position:'absolute', left:0, top:4, bottom:4, width:1, background:'#E9E1D3' }}/>}
      <div style={{ fontSize:9, letterSpacing:1.8, fontWeight:700, color:'#6F7A73' }}>{label}</div>
      <div className="serif" style={{ fontSize:22, fontWeight:700, letterSpacing:-0.6, marginTop:2 }}>${value}</div>
      <div style={{ fontSize:10, fontWeight:700, color: up ? '#2CAE6E' : '#D96A4F', marginTop:2 }}>{delta}</div>
    </div>
  );
}

function CategoryBar({ items }) {
  const ref = useRef();
  return (
    <div>
      <div ref={ref} style={{ display:'flex', height:14, borderRadius:7, overflow:'hidden' }}>
        {items.map((it,i)=>(
          <div key={i} style={{
            width:`${it.pct}%`, background: it.color,
            transformOrigin:'left', animation:`mf-grow-bar .9s ${0.5+i*0.1}s cubic-bezier(.2,.9,.2,1) both`
          }}/>
        ))}
      </div>
      <div style={{ marginTop:12, display:'flex', flexWrap:'wrap', gap:10 }}>
        {items.map((it,i)=>(
          <div key={i} style={{ display:'flex', alignItems:'center', gap:6, fontSize:11, color:'#0F2A1E', fontWeight:600, animation:`mf-fade .6s ${0.7+i*0.08}s both` }}>
            <span style={{ width:8, height:8, borderRadius:4, background:it.color }}/>
            {it.label} <span style={{ color:'#6F7A73', fontWeight:500 }}>{it.pct}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}

window.V5Editorial = V5Editorial;
