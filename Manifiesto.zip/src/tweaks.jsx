// Tweaks panel — shown when host posts __activate_edit_mode.
// Exposes animation intensity, density, hide amounts, and greeting hour.

const { useState: useStateTw, useEffect: useEffectTw } = React;

function TweaksPanel({ tweaks, setTweaks, onClose }) {
  const set = (k, v) => setTweaks(t => ({ ...t, [k]: v }));
  return (
    <div style={{
      position:'fixed', bottom:16, right:16, width:300, zIndex:9999,
      background:'#0F2A1E', color:'#FFFBF2', borderRadius:16, padding:'14px 16px',
      fontFamily:'Plus Jakarta Sans, system-ui, sans-serif',
      boxShadow:'0 20px 60px -20px rgba(0,0,0,0.5)',
      border:'1px solid rgba(255,255,255,0.1)',
    }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:10 }}>
        <div style={{ fontSize:11, fontWeight:700, letterSpacing:1.4 }}>TWEAKS</div>
        <button onClick={onClose} style={{ background:'none', border:'none', color:'#FFFBF2', cursor:'pointer', fontSize:16 }}>×</button>
      </div>

      <Row label="Animaciones">
        <Segmented value={tweaks.animations} onChange={v=>set('animations',v)} opts={['off','suave','full']}/>
      </Row>
      <Row label="Densidad">
        <Segmented value={tweaks.density} onChange={v=>set('density',v)} opts={['compacto','aireado']}/>
      </Row>
      <Row label="Ocultar montos">
        <Toggle value={tweaks.hideAmounts} onChange={v=>set('hideAmounts',v)}/>
      </Row>
      <Row label="Hora del día">
        <Segmented value={tweaks.hour} onChange={v=>set('hour',v)} opts={['mañana','tarde','noche']}/>
      </Row>
      <Row label="Datos">
        <Segmented value={tweaks.dataset} onChange={v=>set('dataset',v)} opts={['vacío','normal','mucho']}/>
      </Row>
    </div>
  );
}

function Row({ label, children }) {
  return (
    <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', gap:10, padding:'8px 0', borderTop:'1px solid rgba(255,255,255,0.08)' }}>
      <div style={{ fontSize:12, color:'rgba(255,255,255,0.75)' }}>{label}</div>
      {children}
    </div>
  );
}

function Segmented({ value, onChange, opts }) {
  return (
    <div style={{ display:'flex', gap:2, background:'rgba(255,255,255,0.08)', padding:2, borderRadius:8 }}>
      {opts.map(o => (
        <button key={o} onClick={()=>onChange(o)} style={{
          border:'none', padding:'4px 8px', borderRadius:6, fontSize:11, fontWeight:600, cursor:'pointer',
          background: value===o ? '#6FE09A' : 'transparent',
          color: value===o ? '#0F2A1E' : 'rgba(255,255,255,0.7)',
        }}>{o}</button>
      ))}
    </div>
  );
}

function Toggle({ value, onChange }) {
  return (
    <button onClick={()=>onChange(!value)} style={{
      width:36, height:20, borderRadius:999, border:'none', cursor:'pointer',
      background: value ? '#6FE09A' : 'rgba(255,255,255,0.15)',
      position:'relative', padding:0,
    }}>
      <div style={{
        position:'absolute', top:2, left: value?18:2, width:16, height:16, borderRadius:999, background:'#FFFBF2',
        transition:'left .2s',
      }}/>
    </button>
  );
}

window.TweaksPanel = TweaksPanel;
