// Add Expense Sheet + Add Fijo Sheet — bottom sheets
// Compact modal for gasto rápido; evolved for fijo (frecuencia, cuotas, preview)

const { useState: useStateAs, useEffect: useEffectAs, useRef: useRefAs } = React;

// shared underlay
function SheetUnderlay({ children, onClose, dark }) {
  useEffectAs(() => {
    const handler = (e) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [onClose]);
  return (
    <div style={{
      position:'absolute', inset:0, zIndex:60,
      background: dark ? 'rgba(0,0,0,0.68)' : 'rgba(15,42,30,0.45)',
      backdropFilter:'blur(6px)',
      display:'flex', flexDirection:'column', justifyContent:'flex-end',
      animation:'mf-fade .25s ease',
    }} onClick={onClose}>
      <div onClick={e=>e.stopPropagation()} style={{
        background: dark ? '#0E1A15' : '#EFF5E8',
        borderTopLeftRadius:28, borderTopRightRadius:28,
        boxShadow: dark ? '0 -20px 40px -10px rgba(0,0,0,0.6)' : '0 -20px 40px -10px rgba(15,42,30,0.3)',
        border: dark ? '1px solid #1F332A' : '1px solid #EFE8D9',
        animation:'mf-sheet-up .35s cubic-bezier(.2,.9,.2,1)',
        maxHeight:'85%', overflowY:'auto', overflowX:'hidden',
        position:'relative',
      }}>
        <div style={{
          position:'sticky', top:0, zIndex:2,
          background: dark ? '#0E1A15' : '#EFF5E8',
          padding:'10px 0 4px',
        }}>
          <div style={{ width:40, height:4, background: dark?'#2A3D33':'#D9D2C4',
            borderRadius:2, margin:'0 auto' }}/>
        </div>
        {children}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// ADD EXPENSE — compact
// ─────────────────────────────────────────────────────────────
const QUICK_AMOUNTS = [1000, 5000, 10000, 25000, 50000];
const DESC_SUGGESTIONS = ['Supermercado', 'Nafta', 'Café', 'Delivery', 'Farmacia', 'Varios'];
// descripción → categoría sugerida
const AUTO_CAT = {
  'super':'mer','mercado':'mer','almacen':'mer','coto':'mer',
  'nafta':'tra','combust':'tra','uber':'tra','sube':'tra','taxi':'tra',
  'cafe':'oci','café':'oci','cine':'oci',
  'delivery':'rst','pedidos':'rst','restaur':'rst',
  'farmac':'sal',
  'netflix':'sus','spotify':'sus','disney':'sus',
  'alquiler':'alq','expensas':'alq',
  'edenor':'ser','metrogas':'ser','aysa':'ser','luz':'ser','gas':'ser','agua':'ser',
};

function AddExpenseSheet({ mode='light', onClose }) {
  const dark = mode === 'dark';
  const [amount, setAmount] = useStateAs(0);
  const [desc, setDesc] = useStateAs('');
  const [cat, setCat] = useStateAs(null); // cat id
  const [expanded, setExpanded] = useStateAs(false);
  const [recurringAsk, setRecurringAsk] = useStateAs(false);

  // palette
  const P = dark
    ? { bg:'#0E1A15', card:'#13221B', cardSoft:'#1A2B22', line:'#1F332A', ink:'#F6FBEF', muted:'#8FA094', accent:'#C7EE9C', accentInk:'#0A1410' }
    : { bg:'#EFF5E8', card:'#FFFBF2', cardSoft:'#F6F1E4', line:'#EFE8D9', ink:'#0F2A1E', muted:'#6F7A73', accent:'#0F2A1E', accentInk:'#F6FBEF' };

  // auto-categorize desde descripción
  useEffectAs(() => {
    if (!desc) return;
    const lower = desc.toLowerCase();
    for (const key in AUTO_CAT) {
      if (lower.includes(key)) {
        // pick first matching GASTOS cat by label substring
        const c = (window.GASTOS_CATS || []).find(x => x.id === AUTO_CAT[key]);
        if (c) setCat(c.id);
        break;
      }
    }
    // detectar recurrencia ('mensual', 'suscripcion', 'netflix')
    const recurrHints = ['mensual','suscrip','netflix','spotify','disney','abono','cuota','alquiler'];
    if (recurrHints.some(h => lower.includes(h))) {
      setRecurringAsk(true);
    } else {
      setRecurringAsk(false);
    }
  }, [desc]);

  const cats = window.GASTOS_CATS || [];
  const displayAmt = amount ? `$${amount.toLocaleString('es-AR')}` : '$0';

  return (
    <SheetUnderlay onClose={onClose} dark={dark}>
      <div style={{ padding:'6px 22px 28px' }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', marginBottom:8 }}>
          <div className="sf-display" style={{ fontSize:22, fontWeight:800, color:P.ink, letterSpacing:-0.6 }}>
            Agregar gasto
          </div>
          <button onClick={onClose} style={{ background:'transparent', border:'none', color:P.muted,
            fontSize:14, fontWeight:600, cursor:'pointer', fontFamily:'inherit' }}>Cancelar</button>
        </div>

        {/* AMOUNT hero */}
        <div style={{
          background: dark ? 'linear-gradient(135deg, #13221B, #0E1A15)' : 'linear-gradient(135deg, #FFFBF2, #F6F1E4)',
          border: `1px solid ${P.line}`,
          borderRadius:20, padding:'18px 20px',
          position:'relative', overflow:'hidden',
          animation:'mf-rise .4s .05s ease both',
        }}>
          <div style={{ fontSize:10, letterSpacing:1.6, fontWeight:700, color:P.muted }}>MONTO</div>
          <div className="sf-display" style={{
            fontSize:44, fontWeight:800, color:amount?P.ink:P.muted,
            letterSpacing:-2, lineHeight:1, marginTop:4,
            transition:'color .2s ease',
          }}>
            {displayAmt}
          </div>
          {/* quick amounts */}
          <div style={{ display:'flex', gap:6, marginTop:12, overflowX:'auto', scrollbarWidth:'none' }}>
            {QUICK_AMOUNTS.map(v => (
              <button key={v} onClick={()=>setAmount(a => a + v)} style={{
                flexShrink:0, padding:'6px 12px', borderRadius:999, border:`1px solid ${P.line}`,
                background: dark? '#0A1410' : '#FFFBF2', color:P.ink, fontSize:12, fontWeight:700,
                cursor:'pointer', fontFamily:'inherit',
              }}>
                +${v.toLocaleString('es-AR')}
              </button>
            ))}
            {amount > 0 && (
              <button onClick={()=>setAmount(0)} style={{
                flexShrink:0, padding:'6px 12px', borderRadius:999,
                border:`1px dashed ${dark?'#2A3D33':'#D9D2C4'}`,
                background:'transparent', color:P.muted, fontSize:12, fontWeight:700,
                cursor:'pointer', fontFamily:'inherit',
              }}>Borrar</button>
            )}
          </div>
        </div>

        {/* DESCRIPTION */}
        <div style={{ marginTop:14, animation:'mf-rise .4s .1s ease both' }}>
          <div style={{ fontSize:10, letterSpacing:1.6, fontWeight:700, color:P.muted, marginBottom:6 }}>DESCRIPCIÓN</div>
          <input value={desc} onChange={e=>setDesc(e.target.value)}
            placeholder="Ej: Supermercado Coto"
            style={{
              width:'100%', padding:'12px 14px', borderRadius:14,
              background:P.card, color:P.ink, fontSize:14, fontWeight:500,
              border:`1px solid ${P.line}`, outline:'none', fontFamily:'inherit',
              boxSizing:'border-box',
            }}/>
          <div style={{ display:'flex', gap:6, marginTop:8, overflowX:'auto', scrollbarWidth:'none' }}>
            {DESC_SUGGESTIONS.map(d => (
              <button key={d} onClick={()=>setDesc(d)} style={{
                flexShrink:0, padding:'5px 10px', borderRadius:999, border:`1px solid ${P.line}`,
                background:'transparent', color:P.muted, fontSize:11, fontWeight:600,
                cursor:'pointer', fontFamily:'inherit',
              }}>{d}</button>
            ))}
          </div>
        </div>

        {/* CATEGORY grid */}
        <div style={{ marginTop:14, animation:'mf-rise .4s .15s ease both' }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', marginBottom:8 }}>
            <div style={{ fontSize:10, letterSpacing:1.6, fontWeight:700, color:P.muted }}>CATEGORÍA</div>
            {cat && <div style={{ fontSize:10, color:'#C7EE9C', fontWeight:700 }}>✓ sugerida</div>}
          </div>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:6 }}>
            {cats.slice(0,8).map(c => {
              const on = cat === c.id;
              return (
                <button key={c.id} onClick={()=>setCat(c.id)} style={{
                  aspectRatio:'1', borderRadius:14,
                  background: on ? `linear-gradient(140deg, ${c.color}35, ${c.color}18)` : P.card,
                  border: on ? `1.5px solid ${c.color}` : `1px solid ${P.line}`,
                  color:P.ink, cursor:'pointer', fontFamily:'inherit',
                  display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap:4,
                  padding:6, transition:'transform .15s ease',
                  transform: on ? 'scale(1.03)' : 'scale(1)',
                }}>
                  <div style={{ fontSize:22 }}>{c.emoji}</div>
                  <div style={{ fontSize:9, fontWeight:700, textAlign:'center', lineHeight:1.1,
                    whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis', maxWidth:'100%' }}>
                    {c.label}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Smart: detect recurring */}
        {recurringAsk && (
          <div style={{
            marginTop:12,
            background: `linear-gradient(135deg, ${dark?'#3A2A4E55':'#F3E8F8'}, ${dark?'#2A1F3666':'#EDD9F0'})`,
            border:`1px solid ${dark?'#4A3A5E':'#E0C4E8'}`,
            borderRadius:14, padding:'10px 14px',
            display:'flex', alignItems:'center', gap:10,
            animation:'mf-rise .4s ease both',
          }}>
            <div style={{ fontSize:20 }}>🔁</div>
            <div style={{ flex:1, fontSize:12 }}>
              <div style={{ fontWeight:700, color:P.ink }}>¿Es un gasto recurrente?</div>
              <div style={{ color:P.muted, fontSize:11, marginTop:1 }}>Podemos crearlo como fijo en un toque.</div>
            </div>
            <button style={{ background:'#C9A6E0', color:'#0A1410', border:'none',
              padding:'6px 12px', borderRadius:999, fontSize:11, fontWeight:700, cursor:'pointer',
              fontFamily:'inherit' }}>
              Sí, fijo
            </button>
          </div>
        )}

        {/* Expand toggle */}
        <button onClick={()=>setExpanded(e=>!e)} style={{
          width:'100%', marginTop:12, padding:'10px', borderRadius:12,
          background:'transparent', color:P.muted, border:`1px dashed ${dark?'#2A3D33':'#D9D2C4'}`,
          fontSize:12, fontWeight:600, cursor:'pointer', fontFamily:'inherit',
          display:'flex', alignItems:'center', justifyContent:'center', gap:6,
        }}>
          {expanded ? 'Menos detalles' : 'Más detalles (fecha, quién, método)'}
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" style={{
            transform: expanded ? 'rotate(180deg)':'rotate(0)', transition:'transform .2s ease',
          }}>
            <path d="M6 9l6 6 6-6" stroke={P.muted} strokeWidth="2" strokeLinecap="round"/>
          </svg>
        </button>

        {expanded && (
          <div style={{ marginTop:10, display:'grid', gridTemplateColumns:'1fr 1fr', gap:8,
            animation:'mf-fade .25s ease both' }}>
            <MiniTile dark={dark} label="FECHA" value="Hoy · 14:20"/>
            <MiniTile dark={dark} label="QUIÉN" value="Mario" accent="#2E7D5B"/>
            <MiniTile dark={dark} label="MÉTODO" value="Tarjeta"/>
            <MiniTile dark={dark} label="COMPARTIR" value="Solo yo"/>
          </div>
        )}

        {/* CTA */}
        <button style={{
          width:'100%', marginTop:18, padding:'16px',
          background: amount > 0 && cat
            ? (dark ? 'linear-gradient(140deg,#C7EE9C,#8DD66A)' : '#0F2A1E')
            : (dark ? '#1A2B22' : '#D9D2C4'),
          color: amount > 0 && cat ? (dark ? '#0A1410':'#F6FBEF') : P.muted,
          border:'none', borderRadius:16,
          fontSize:15, fontWeight:800, cursor: amount > 0 && cat ? 'pointer' : 'not-allowed',
          fontFamily:'inherit',
          boxShadow: amount > 0 && cat
            ? (dark ? '0 12px 28px -8px rgba(199,238,156,0.5)' : '0 12px 28px -8px rgba(15,42,30,0.4)')
            : 'none',
          transition:'all .2s ease',
        }}>
          {amount > 0 ? `Guardar $${amount.toLocaleString('es-AR')}` : 'Ingresá un monto'}
        </button>
      </div>
    </SheetUnderlay>
  );
}

function MiniTile({ label, value, accent, dark }) {
  const P = dark
    ? { bg:'#13221B', ink:'#F6FBEF', muted:'#8FA094', line:'#1F332A' }
    : { bg:'#FFFBF2', ink:'#0F2A1E', muted:'#9AA39D', line:'#EFE8D9' };
  return (
    <div style={{ padding:'10px 12px', background:P.bg, borderRadius:12, border:`1px solid ${P.line}` }}>
      <div style={{ fontSize:9, letterSpacing:1.2, fontWeight:700, color:P.muted }}>{label}</div>
      <div style={{ fontSize:13, fontWeight:700, color: accent || P.ink, marginTop:2 }}>{value}</div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// ADD FIJO — evolved
// frecuencia, cuotas N/M, fecha próximo pago, recordatorio,
// preview impacto en presupuesto, animación "aterriza" en calendario
// ─────────────────────────────────────────────────────────────
const FREQS = [
  { id:'mensual',    label:'Mensual',     months:1 },
  { id:'bimestral',  label:'Bimestral',   months:2 },
  { id:'trimestral', label:'Trimestral',  months:3 },
  { id:'semestral',  label:'Semestral',   months:6 },
  { id:'anual',      label:'Anual',       months:12 },
  { id:'cuotas',     label:'Cuotas',      months:1 },
];

function AddFijoSheet({ mode='light', onClose }) {
  const dark = mode === 'dark';
  const [step, setStep] = useStateAs(1); // 1: datos, 2: preview
  const [name, setName] = useStateAs('');
  const [amount, setAmount] = useStateAs(0);
  const [cat, setCat] = useStateAs(null);
  const [freq, setFreq] = useStateAs('mensual');
  const [cuotaTot, setCuotaTot] = useStateAs(12);
  const [day, setDay] = useStateAs(15);
  const [notify, setNotify] = useStateAs(true);

  const P = dark
    ? { bg:'#0E1A15', card:'#13221B', line:'#1F332A', ink:'#F6FBEF', muted:'#8FA094', accent:'#C7EE9C', accentInk:'#0A1410', cardSoft:'#1A2B22' }
    : { bg:'#EFF5E8', card:'#FFFBF2', line:'#EFE8D9', ink:'#0F2A1E', muted:'#6F7A73', accent:'#0F2A1E', accentInk:'#F6FBEF', cardSoft:'#F6F1E4' };

  const cats = window.FIJOS_CATS || [];

  // preview impact
  const prevTotal = (window.FIJOS_ITEMS||[]).reduce((s,i)=>s+i.amount, 0);
  const nuevoTotal = prevTotal + (amount || 0);
  const sueldo = 2200000;
  const pctAntes = Math.round((prevTotal / sueldo) * 100);
  const pctDespues = Math.round((nuevoTotal / sueldo) * 100);
  const deltaPct = pctDespues - pctAntes;
  const libreDespues = sueldo - nuevoTotal;

  const canContinue = amount > 0 && cat && name.trim();

  return (
    <SheetUnderlay onClose={onClose} dark={dark}>
      <div style={{ padding:'6px 22px 28px' }}>
        {/* header with step indicator */}
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:10 }}>
          <div style={{ display:'flex', alignItems:'center', gap:10 }}>
            {step === 2 && (
              <button onClick={()=>setStep(1)} style={{ background:'transparent', border:'none', color:P.ink,
                cursor:'pointer', padding:0, display:'grid', placeItems:'center', fontFamily:'inherit' }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                  <path d="M15 6l-6 6 6 6" stroke={P.ink} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </button>
            )}
            <div className="sf-display" style={{ fontSize:22, fontWeight:800, color:P.ink, letterSpacing:-0.6 }}>
              {step === 1 ? 'Nuevo fijo' : 'Revisá el impacto'}
            </div>
          </div>
          <button onClick={onClose} style={{ background:'transparent', border:'none', color:P.muted,
            fontSize:14, fontWeight:600, cursor:'pointer', fontFamily:'inherit' }}>Cancelar</button>
        </div>

        {/* step dots */}
        <div style={{ display:'flex', gap:6, marginBottom:14 }}>
          {[1,2].map(s => (
            <div key={s} style={{
              flex:1, height:3, borderRadius:2,
              background: s <= step ? (dark?'#C7EE9C':'#0F2A1E') : (dark?'#1F332A':'#D9D2C4'),
              transition:'background .25s ease',
            }}/>
          ))}
        </div>

        {step === 1 && (
          <>
            {/* NAME */}
            <div style={{ animation:'mf-rise .4s .05s ease both' }}>
              <div style={{ fontSize:10, letterSpacing:1.6, fontWeight:700, color:P.muted, marginBottom:6 }}>NOMBRE</div>
              <input value={name} onChange={e=>setName(e.target.value)} autoFocus
                placeholder="Ej: Alquiler, Netflix, Cuota iPhone"
                style={{
                  width:'100%', padding:'12px 14px', borderRadius:14,
                  background:P.card, color:P.ink, fontSize:14, fontWeight:600,
                  border:`1px solid ${P.line}`, outline:'none', fontFamily:'inherit',
                  boxSizing:'border-box',
                }}/>
            </div>

            {/* AMOUNT */}
            <div style={{
              marginTop:12,
              background: dark ? 'linear-gradient(135deg, #13221B, #0E1A15)' : 'linear-gradient(135deg, #FFFBF2, #F6F1E4)',
              border: `1px solid ${P.line}`,
              borderRadius:20, padding:'16px 20px',
              animation:'mf-rise .4s .1s ease both',
            }}>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline' }}>
                <div style={{ fontSize:10, letterSpacing:1.6, fontWeight:700, color:P.muted }}>MONTO</div>
                {freq === 'cuotas' && amount > 0 && (
                  <div style={{ fontSize:11, color:P.muted, fontWeight:600 }}>
                    Total: ${(amount * cuotaTot).toLocaleString('es-AR')}
                  </div>
                )}
              </div>
              <div className="sf-display" style={{
                fontSize:38, fontWeight:800, color:amount?P.ink:P.muted,
                letterSpacing:-1.8, lineHeight:1, marginTop:4,
              }}>
                ${amount.toLocaleString('es-AR') || 0}
                {freq === 'cuotas' && amount > 0 && (
                  <span style={{ fontSize:14, color:P.muted, fontWeight:600, marginLeft:6 }}>/ cuota</span>
                )}
              </div>
              <div style={{ display:'flex', gap:6, marginTop:10, overflowX:'auto', scrollbarWidth:'none' }}>
                {[5000, 15000, 30000, 50000, 100000].map(v => (
                  <button key={v} onClick={()=>setAmount(a => a + v)} style={{
                    flexShrink:0, padding:'6px 12px', borderRadius:999, border:`1px solid ${P.line}`,
                    background: dark? '#0A1410' : '#FFFBF2', color:P.ink, fontSize:12, fontWeight:700,
                    cursor:'pointer', fontFamily:'inherit',
                  }}>+${(v/1000).toFixed(0)}k</button>
                ))}
                {amount > 0 && (
                  <button onClick={()=>setAmount(0)} style={{
                    flexShrink:0, padding:'6px 12px', borderRadius:999,
                    border:`1px dashed ${dark?'#2A3D33':'#D9D2C4'}`,
                    background:'transparent', color:P.muted, fontSize:12, fontWeight:700,
                    cursor:'pointer', fontFamily:'inherit',
                  }}>Borrar</button>
                )}
              </div>
            </div>

            {/* CATEGORY */}
            <div style={{ marginTop:12, animation:'mf-rise .4s .15s ease both' }}>
              <div style={{ fontSize:10, letterSpacing:1.6, fontWeight:700, color:P.muted, marginBottom:6 }}>CATEGORÍA</div>
              <div style={{ display:'flex', gap:6, overflowX:'auto', scrollbarWidth:'none', paddingBottom:4 }}>
                {cats.map(c => {
                  const on = cat === c.id;
                  return (
                    <button key={c.id} onClick={()=>setCat(c.id)} style={{
                      flexShrink:0, padding:'10px 12px', borderRadius:14,
                      background: on ? `linear-gradient(140deg, ${c.color}35, ${c.color}18)` : P.card,
                      border: on ? `1.5px solid ${c.color}` : `1px solid ${P.line}`,
                      color:P.ink, cursor:'pointer', fontFamily:'inherit',
                      display:'flex', alignItems:'center', gap:6,
                      transform: on ? 'scale(1.02)' : 'scale(1)', transition:'transform .15s ease',
                    }}>
                      <span style={{ fontSize:16 }}>{c.emoji}</span>
                      <span style={{ fontSize:12, fontWeight:700 }}>{c.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* FRECUENCIA */}
            <div style={{ marginTop:12, animation:'mf-rise .4s .2s ease both' }}>
              <div style={{ fontSize:10, letterSpacing:1.6, fontWeight:700, color:P.muted, marginBottom:6 }}>FRECUENCIA</div>
              <div style={{ display:'flex', gap:6, flexWrap:'wrap' }}>
                {FREQS.map(f => {
                  const on = freq === f.id;
                  return (
                    <button key={f.id} onClick={()=>setFreq(f.id)} style={{
                      padding:'8px 14px', borderRadius:999,
                      background: on ? (dark?'linear-gradient(140deg,#C7EE9C,#8DD66A)':'#0F2A1E') : P.card,
                      color: on ? (dark?'#0A1410':'#F6FBEF') : P.ink,
                      border: on ? 'none' : `1px solid ${P.line}`,
                      cursor:'pointer', fontSize:12, fontWeight:700, fontFamily:'inherit',
                    }}>{f.label}</button>
                  );
                })}
              </div>

              {freq === 'cuotas' && (
                <div style={{
                  marginTop:10, padding:'12px 14px', borderRadius:14,
                  background:`linear-gradient(135deg, ${dark?'#1F3A5E33':'#DCE8F5'}, ${dark?'#15293E44':'#C7D9EC'})`,
                  border:`1px solid ${dark?'#2E4A6E':'#A8BED4'}`,
                  animation:'mf-rise .3s ease both',
                }}>
                  <div style={{ fontSize:10, letterSpacing:1.4, fontWeight:700, color:P.muted }}>¿Cuántas cuotas?</div>
                  <div style={{ display:'flex', alignItems:'center', gap:10, marginTop:6 }}>
                    {[3, 6, 12, 18, 24, 36].map(n => {
                      const on = cuotaTot === n;
                      return (
                        <button key={n} onClick={()=>setCuotaTot(n)} style={{
                          padding:'6px 11px', borderRadius:999,
                          background: on ? '#6B9AD6' : 'transparent',
                          color: on ? '#F6FBEF' : P.ink,
                          border: on ? 'none' : `1px solid ${dark?'#2E4A6E':'#A8BED4'}`,
                          cursor:'pointer', fontSize:12, fontWeight:700, fontFamily:'inherit',
                        }}>{n}</button>
                      );
                    })}
                  </div>
                  {amount > 0 && (
                    <div style={{ marginTop:8, fontSize:11, color:P.muted }}>
                      {cuotaTot} cuotas de <b style={{color:P.ink}}>${amount.toLocaleString('es-AR')}</b> ·
                      Total <b style={{color:P.ink}}>${(amount*cuotaTot).toLocaleString('es-AR')}</b>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* DAY + NOTIFY */}
            <div style={{ marginTop:12, display:'grid', gridTemplateColumns:'1fr 1fr', gap:10,
              animation:'mf-rise .4s .25s ease both' }}>
              <div style={{ background:P.card, border:`1px solid ${P.line}`, borderRadius:14, padding:'10px 12px' }}>
                <div style={{ fontSize:9, letterSpacing:1.2, fontWeight:700, color:P.muted }}>DÍA DEL MES</div>
                <div style={{ display:'flex', alignItems:'center', gap:8, marginTop:4 }}>
                  <button onClick={()=>setDay(d => d<=1?30:d-1)} style={{
                    width:24, height:24, borderRadius:999, background:P.cardSoft, border:'none',
                    cursor:'pointer', color:P.ink, fontSize:12, fontWeight:700, fontFamily:'inherit',
                  }}>−</button>
                  <div className="sf-display" style={{ fontSize:22, fontWeight:800, color:P.ink, letterSpacing:-0.5, flex:1, textAlign:'center' }}>
                    {day}
                  </div>
                  <button onClick={()=>setDay(d => d>=30?1:d+1)} style={{
                    width:24, height:24, borderRadius:999, background:P.cardSoft, border:'none',
                    cursor:'pointer', color:P.ink, fontSize:12, fontWeight:700, fontFamily:'inherit',
                  }}>+</button>
                </div>
              </div>
              <button onClick={()=>setNotify(n=>!n)} style={{
                background: notify ? (dark?'#C7EE9C33':'#DDEFE3') : P.card,
                border: notify ? `1px solid ${dark?'#C7EE9C88':'#8DD66A'}` : `1px solid ${P.line}`,
                borderRadius:14, padding:'10px 12px', cursor:'pointer', fontFamily:'inherit',
                display:'flex', flexDirection:'column', alignItems:'flex-start', textAlign:'left',
              }}>
                <div style={{ fontSize:9, letterSpacing:1.2, fontWeight:700, color:P.muted }}>RECORDATORIO</div>
                <div style={{ fontSize:13, fontWeight:700, color:P.ink, marginTop:4,
                  display:'flex', alignItems:'center', gap:6 }}>
                  <span style={{ fontSize:16 }}>{notify ? '🔔' : '🔕'}</span>
                  {notify ? '2 días antes' : 'Sin aviso'}
                </div>
              </button>
            </div>

            {/* continue */}
            <button
              onClick={()=> canContinue && setStep(2)}
              disabled={!canContinue}
              style={{
                width:'100%', marginTop:18, padding:'16px',
                background: canContinue
                  ? (dark ? 'linear-gradient(140deg,#C7EE9C,#8DD66A)' : '#0F2A1E')
                  : (dark ? '#1A2B22' : '#D9D2C4'),
                color: canContinue ? (dark?'#0A1410':'#F6FBEF') : P.muted,
                border:'none', borderRadius:16,
                fontSize:15, fontWeight:800, cursor: canContinue ? 'pointer' : 'not-allowed',
                fontFamily:'inherit',
                boxShadow: canContinue
                  ? (dark ? '0 12px 28px -8px rgba(199,238,156,0.5)' : '0 12px 28px -8px rgba(15,42,30,0.4)')
                  : 'none',
              }}>
              {canContinue ? 'Ver impacto →' : 'Completá los datos'}
            </button>
          </>
        )}

        {step === 2 && (
          <PreviewStep
            dark={dark} P={P}
            name={name} amount={amount} cat={cat} freq={freq}
            cuotaTot={cuotaTot} day={day} notify={notify}
            prevTotal={prevTotal} nuevoTotal={nuevoTotal}
            sueldo={sueldo} pctAntes={pctAntes} pctDespues={pctDespues}
            deltaPct={deltaPct} libreDespues={libreDespues}
            onConfirm={()=>{ onClose(); }}
          />
        )}
      </div>
    </SheetUnderlay>
  );
}

function PreviewStep({ dark, P, name, amount, cat, freq, cuotaTot, day, notify,
  prevTotal, nuevoTotal, sueldo, pctAntes, pctDespues, deltaPct, libreDespues, onConfirm }) {
  const catObj = (window.FIJOS_CATS || []).find(c=>c.id===cat);
  const freqObj = FREQS.find(f=>f.id===freq);
  return (
    <>
      {/* summary card */}
      <div style={{
        background: dark ? 'linear-gradient(135deg, #13221B, #0E1A15)' : 'linear-gradient(135deg, #FFFBF2, #F6F1E4)',
        border:`1px solid ${P.line}`, borderRadius:20, padding:'16px 18px',
        animation:'mf-rise .4s ease both',
      }}>
        <div style={{ display:'flex', alignItems:'center', gap:12 }}>
          <div style={{ width:48, height:48, borderRadius:14,
            background:`linear-gradient(140deg, ${catObj.color}35, ${catObj.color}15)`,
            border:`1px solid ${catObj.color}55`,
            display:'grid', placeItems:'center', fontSize:24 }}>{catObj.emoji}</div>
          <div style={{ flex:1 }}>
            <div style={{ fontSize:15, fontWeight:800, color:P.ink }}>{name}</div>
            <div style={{ fontSize:11, color:P.muted, marginTop:2 }}>
              {catObj.label} · {freqObj.label}{freq==='cuotas'?` (${cuotaTot})`:''} · día {day}
            </div>
          </div>
          <div style={{ textAlign:'right' }}>
            <div className="sf-display" style={{ fontSize:20, fontWeight:800, color:P.ink, letterSpacing:-0.5 }}>
              ${amount.toLocaleString('es-AR')}
            </div>
            {freq === 'cuotas' && (
              <div style={{ fontSize:10, color:P.muted, fontWeight:600 }}>
                × {cuotaTot} · ${(amount*cuotaTot/1000).toFixed(0)}k total
              </div>
            )}
          </div>
        </div>
      </div>

      {/* IMPACT visualization */}
      <div style={{ marginTop:14, animation:'mf-rise .4s .1s ease both' }}>
        <div style={{ fontSize:10, letterSpacing:1.6, fontWeight:700, color:P.muted, marginBottom:8 }}>
          IMPACTO EN EL PRESUPUESTO
        </div>
        <div style={{
          background:P.card, border:`1px solid ${P.line}`, borderRadius:18, padding:'14px 16px',
        }}>
          {/* before */}
          <div>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline' }}>
              <div style={{ fontSize:11, color:P.muted, fontWeight:600 }}>Antes</div>
              <div style={{ fontSize:12, fontWeight:700, color:P.ink }}>
                <b>{pctAntes}%</b> <span style={{ color:P.muted, fontWeight:500 }}>en fijos</span>
              </div>
            </div>
            <div style={{ marginTop:4, height:8, borderRadius:4, background: dark?'#0A1410':'#EFE8D9', overflow:'hidden' }}>
              <div style={{ width:`${pctAntes}%`, height:'100%',
                background:'linear-gradient(90deg, #F2B58A, #E8976A)',
                animation:'mf-grow-bar 1s .2s cubic-bezier(.2,.9,.2,1) both', transformOrigin:'left' }}/>
            </div>
          </div>

          {/* arrow */}
          <div style={{ margin:'10px 0', display:'flex', alignItems:'center', gap:8 }}>
            <div style={{ flex:1, height:1, background: dark?'#1F332A':'#EFE8D9' }}/>
            <div style={{
              padding:'3px 8px', borderRadius:999, fontSize:11, fontWeight:700,
              color: deltaPct >= 5 ? (dark?'#E88A70':'#C03A2A') : (dark?'#F2B58A':'#A3452A'),
              background: deltaPct >= 5 ? (dark?'#4A201A':'#F5C6B6') : (dark?'#3A2A22':'#FADFC8'),
            }}>
              ↑ +{deltaPct} pts
            </div>
            <div style={{ flex:1, height:1, background: dark?'#1F332A':'#EFE8D9' }}/>
          </div>

          {/* after */}
          <div>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline' }}>
              <div style={{ fontSize:11, color:P.muted, fontWeight:600 }}>Después</div>
              <div style={{ fontSize:12, fontWeight:700, color:P.ink }}>
                <b>{pctDespues}%</b> <span style={{ color:P.muted, fontWeight:500 }}>en fijos</span>
              </div>
            </div>
            <div style={{ marginTop:4, height:8, borderRadius:4, background: dark?'#0A1410':'#EFE8D9', overflow:'hidden' }}>
              <div style={{ width:`${pctDespues}%`, height:'100%',
                background:'linear-gradient(90deg, #F2B58A, #D96A4F)',
                animation:'mf-grow-bar 1.2s .5s cubic-bezier(.2,.9,.2,1) both', transformOrigin:'left' }}/>
            </div>
          </div>

          {/* libre proyectado */}
          <div style={{ marginTop:12, paddingTop:12, borderTop:`1px dashed ${P.line}`,
            display:'flex', justifyContent:'space-between', alignItems:'center' }}>
            <div>
              <div style={{ fontSize:10, letterSpacing:1.2, fontWeight:700, color:P.muted }}>
                TE QUEDA LIBRE
              </div>
              <div className="sf-display" style={{ fontSize:20, fontWeight:800, color:P.ink, letterSpacing:-0.5, marginTop:2 }}>
                ${libreDespues.toLocaleString('es-AR')}
              </div>
            </div>
            <div style={{
              padding:'4px 10px', borderRadius:999,
              background: pctDespues > 70 ? (dark?'#4A201A':'#F5C6B6') : pctDespues > 50 ? (dark?'#3A2A22':'#FADFC8') : (dark?'#1F4F30':'#DDEFE3'),
              color: pctDespues > 70 ? (dark?'#E88A70':'#C03A2A') : pctDespues > 50 ? (dark?'#F2B58A':'#A3452A') : (dark?'#9EE0B2':'#2E7D5B'),
              fontSize:11, fontWeight:700,
            }}>
              {pctDespues > 70 ? 'Alto' : pctDespues > 50 ? 'Medio' : 'Sano'}
            </div>
          </div>
        </div>
      </div>

      {/* animación: gasto aterrizando en calendario */}
      <div style={{ marginTop:14, animation:'mf-rise .4s .2s ease both' }}>
        <div style={{ fontSize:10, letterSpacing:1.6, fontWeight:700, color:P.muted, marginBottom:8 }}>
          SE AGENDARÁ EN
        </div>
        <CalendarDropAnim day={day} cat={catObj} dark={dark} P={P}/>
      </div>

      {/* Confirm */}
      <button onClick={onConfirm} style={{
        width:'100%', marginTop:16, padding:'16px',
        background: dark ? 'linear-gradient(140deg,#C7EE9C,#8DD66A)' : '#0F2A1E',
        color: dark ? '#0A1410' : '#F6FBEF',
        border:'none', borderRadius:16, fontSize:15, fontWeight:800, cursor:'pointer',
        fontFamily:'inherit',
        boxShadow: dark ? '0 12px 28px -8px rgba(199,238,156,0.5)' : '0 12px 28px -8px rgba(15,42,30,0.4)',
      }}>
        ✓ Crear gasto fijo
      </button>
    </>
  );
}

// Mini calendar with an animated drop marker on the chosen day
function CalendarDropAnim({ day, cat, dark, P }) {
  const days = 30;
  return (
    <div style={{
      background:P.card, border:`1px solid ${P.line}`, borderRadius:14, padding:'12px',
      position:'relative', overflow:'hidden',
    }}>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(7, 1fr)', gap:4 }}>
        {['L','M','M','J','V','S','D'].map((d,i)=>(
          <div key={i} style={{ fontSize:8, textAlign:'center', color:P.muted, fontWeight:700, letterSpacing:1, paddingBottom:2 }}>{d}</div>
        ))}
        {[0,1,2].map(i => <div key={'o'+i}/>)}
        {Array.from({length: days}, (_, idx) => {
          const n = idx+1;
          const isTarget = n === day;
          return (
            <div key={n} style={{
              position:'relative',
              aspectRatio:'1', borderRadius:6,
              background: isTarget
                ? `linear-gradient(140deg, ${cat.color}, ${cat.color}cc)`
                : (dark?'#0A1410':'#F6F1E4'),
              color: isTarget ? '#0A1410' : P.muted,
              display:'grid', placeItems:'center', fontSize:9, fontWeight:700,
              boxShadow: isTarget ? `0 0 0 2px ${cat.color}55, 0 6px 12px -4px ${cat.color}80` : 'none',
              animation: isTarget ? 'mf-drop-land 1.1s .3s cubic-bezier(.2,.9,.2,1) both' : undefined,
              zIndex: isTarget ? 2 : 1,
            }}>
              {n}
              {isTarget && (
                <div style={{
                  position:'absolute', top:-10, left:'50%', transform:'translateX(-50%)',
                  fontSize:14, animation:'mf-drop-ping 1.4s .4s ease both',
                }}>{cat.emoji}</div>
              )}
            </div>
          );
        })}
      </div>
      <div style={{ marginTop:10, fontSize:11, color:P.muted, fontWeight:600, textAlign:'center' }}>
        Se agendará el <b style={{ color:P.ink }}>día {day}</b> de cada mes
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Showcases — render sheets inline in a phone-sized artboard
// so designers can review without tapping through the flow
// ─────────────────────────────────────────────────────────────
function AddExpenseShowcase({ mode='light' }) {
  const dark = mode === 'dark';
  return (
    <div style={{
      width:'100%', height:'100%', position:'relative', overflow:'hidden',
      background: dark ? '#0A1410' : '#EFF5E8',
    }}>
      {/* faded behind screen */}
      <div style={{
        position:'absolute', inset:0, opacity:0.35,
        background: dark
          ? 'radial-gradient(ellipse at top, #13221B 0%, #0A1410 70%)'
          : 'radial-gradient(ellipse at top, #FFFBF2 0%, #EFF5E8 70%)',
      }}/>
      <AddExpenseSheet mode={mode} onClose={()=>{}}/>
    </div>
  );
}

function AddFijoShowcase({ mode='light', step=1 }) {
  const dark = mode === 'dark';
  const [s, setS] = useStateAs(step);
  // Pre-populate for step 2 preview
  const Preloaded = () => {
    const P = dark
      ? { bg:'#0E1A15', card:'#13221B', line:'#1F332A', ink:'#F6FBEF', muted:'#8FA094', accent:'#C7EE9C', accentInk:'#0A1410', cardSoft:'#1A2B22' }
      : { bg:'#EFF5E8', card:'#FFFBF2', line:'#EFE8D9', ink:'#0F2A1E', muted:'#6F7A73', accent:'#0F2A1E', accentInk:'#F6FBEF', cardSoft:'#F6F1E4' };
    const catObj = (window.FIJOS_CATS || [])[2]; // subs
    const amount = 18900;
    const prevTotal = (window.FIJOS_ITEMS||[]).reduce((s,i)=>s+i.amount, 0);
    const nuevoTotal = prevTotal + amount;
    const sueldo = 2200000;
    const pctAntes = Math.round((prevTotal / sueldo) * 100);
    const pctDespues = Math.round((nuevoTotal / sueldo) * 100);
    return (
      <SheetUnderlay onClose={()=>{}} dark={dark}>
        <div style={{ padding:'6px 22px 28px' }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:10 }}>
            <div style={{ display:'flex', alignItems:'center', gap:10 }}>
              <div style={{ background:'transparent', color:P.ink, display:'grid', placeItems:'center' }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                  <path d="M15 6l-6 6 6 6" stroke={P.ink} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <div className="sf-display" style={{ fontSize:22, fontWeight:800, color:P.ink, letterSpacing:-0.6 }}>
                Revisá el impacto
              </div>
            </div>
            <div style={{ color:P.muted, fontSize:14, fontWeight:600 }}>Cancelar</div>
          </div>
          <div style={{ display:'flex', gap:6, marginBottom:14 }}>
            <div style={{ flex:1, height:3, borderRadius:2, background: dark?'#C7EE9C':'#0F2A1E' }}/>
            <div style={{ flex:1, height:3, borderRadius:2, background: dark?'#C7EE9C':'#0F2A1E' }}/>
          </div>
          <PreviewStep
            dark={dark} P={P}
            name="HBO Max" amount={amount} cat={catObj.id} freq="mensual"
            cuotaTot={12} day={15} notify={true}
            prevTotal={prevTotal} nuevoTotal={nuevoTotal}
            sueldo={sueldo} pctAntes={pctAntes} pctDespues={pctDespues}
            deltaPct={pctDespues - pctAntes} libreDespues={sueldo - nuevoTotal}
            onConfirm={()=>{}}
          />
        </div>
      </SheetUnderlay>
    );
  };

  return (
    <div style={{
      width:'100%', height:'100%', position:'relative', overflow:'hidden',
      background: dark ? '#0A1410' : '#EFF5E8',
    }}>
      <div style={{
        position:'absolute', inset:0, opacity:0.35,
        background: dark
          ? 'radial-gradient(ellipse at top, #13221B 0%, #0A1410 70%)'
          : 'radial-gradient(ellipse at top, #FFFBF2 0%, #EFF5E8 70%)',
      }}/>
      {step === 1 ? <AddFijoSheet mode={mode} onClose={()=>{}}/> : <Preloaded/>}
    </div>
  );
}

// export
Object.assign(window, { AddExpenseSheet, AddFijoSheet, AddExpenseShowcase, AddFijoShowcase });
