// V6 — "Calendario diario"
// Vista centrada en el día: calendario vivo del mes con días marcados
// verde/ámbar/rojo (cómo gastaste), "hoy" resaltado, comparación con mes
// pasado. Tono tranquilo pero visualmente rico. Balance entre compacto y
// aireado. Menos gamificación, mucho contexto temporal.

function V6Calendario() {
  const today = 22;
  const days = 30;
  const mood = {}; // 1..22 filled
  for (let i=1;i<=today;i++) {
    // deterministic-ish pattern: mostly green, some amber, one red
    const r = Math.sin(i*1.7)*Math.cos(i*0.9);
    mood[i] = r > 0.3 ? 'amber' : r < -0.55 ? 'red' : 'green';
  }
  return (
    <div className="screen" style={{ background:'#F6EFE3', color:'#0F2A1E' }}>
      <StatusBar color="#0F2A1E"/>

      {/* header */}
      <div style={{ padding:'2px 22px 0', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <div>
          <div style={{ fontSize:12, color:'#6F7A73' }}>Hola, Mario</div>
          <div className="serif" style={{ fontSize:26, fontWeight:700, letterSpacing:-0.6 }}>Abril 2026</div>
        </div>
        <div style={{ display:'flex', gap:8 }}>
          <CircleBtn><BellIcon/></CircleBtn>
          <CircleBtn><SlidersIcon/></CircleBtn>
        </div>
      </div>

      {/* big disponible + action */}
      <div style={{ padding:'10px 22px 0', animation:'mf-rise .8s .1s ease both' }}>
        <div style={{
          background:'#0F2A1E', color:'#FFFBF2', borderRadius:22, padding:'14px 16px',
          display:'flex', alignItems:'center', justifyContent:'space-between',
        }}>
          <div>
            <div style={{ fontSize:10, letterSpacing:1.4, fontWeight:700, color:'#9EE5BA' }}>DISPONIBLE HOY</div>
            <div className="serif" style={{ fontSize:34, fontWeight:700, letterSpacing:-1.2, lineHeight:1, marginTop:2 }}>
              <CountUp to={4455000} duration={1400} prefix="$"/>
            </div>
            <div style={{ fontSize:11, color:'rgba(255,255,255,0.6)', marginTop:2 }}>
              cobro en <b style={{ color:'#9EE5BA' }}>27 días</b> · margen <span style={{ color:'#6FE09A', fontWeight:700 }}>+$2.535k</span>
            </div>
          </div>
          <button style={{
            border:'none', background:'#6FE09A', color:'#0F2A1E', width:50, height:50, borderRadius:999,
            fontSize:22, fontWeight:800, cursor:'pointer', animation:'mf-pulse 2.4s 1.6s infinite',
          }}>+</button>
        </div>
      </div>

      {/* calendar */}
      <div style={{ padding:'14px 22px 0', animation:'mf-rise .9s .2s ease both' }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:8 }}>
          <div style={{ fontSize:11, letterSpacing:1.4, fontWeight:700, color:'#6F7A73' }}>TU MES EN UN VISTAZO</div>
          <div style={{ display:'flex', gap:8, fontSize:10, color:'#6F7A73', fontWeight:600 }}>
            <Legend color="#6FE09A" label="bien"/>
            <Legend color="#F2B58A" label="alerta"/>
            <Legend color="#D96A4F" label="exceso"/>
          </div>
        </div>

        <div style={{ display:'grid', gridTemplateColumns:'repeat(7, 1fr)', gap:6 }}>
          {['L','M','M','J','V','S','D'].map((d,i)=>(
            <div key={i} style={{ fontSize:9, textAlign:'center', color:'#9AA39D', fontWeight:700, letterSpacing:1 }}>{d}</div>
          ))}
          {/* offset for month starting Wed (arbitrary) */}
          {[0,1,2].map(i => <div key={'o'+i}/>)}
          {Array.from({length: days}, (_, idx) => {
            const n = idx+1;
            const m = mood[n];
            const bg = m==='green' ? '#DDEFE3' : m==='amber' ? '#FADFC8' : m==='red' ? '#F5C6B6' : 'transparent';
            const border = n > today ? '1px dashed #E9E1D3' : 'none';
            const color = m==='green' ? '#2E7D5B' : m==='amber' ? '#6B3A4F' : m==='red' ? '#A3452A' : '#9AA39D';
            const isToday = n === today;
            return (
              <div key={n} style={{
                aspectRatio:'1', borderRadius:10, background: isToday ? '#0F2A1E' : bg,
                color: isToday ? '#FFFBF2' : color,
                display:'grid', placeItems:'center', fontSize:12, fontWeight:700,
                border, position:'relative',
                animation:`mf-fade .5s ${0.3 + n*0.015}s both`,
                boxShadow: isToday ? '0 6px 14px -4px rgba(15,42,30,0.4)' : 'none',
              }}>
                {n}
                {isToday && <div style={{ position:'absolute', bottom:3, width:4, height:4, borderRadius:2, background:'#6FE09A', animation:'mf-breathe 1.6s ease-in-out infinite' }}/>}
              </div>
            );
          })}
        </div>
      </div>

      {/* compare + streak */}
      <div style={{ padding:'14px 22px 0', display:'grid', gridTemplateColumns:'1fr 1fr', gap:10, animation:'mf-rise .9s .3s ease both' }}>
        <div style={{ background:'#FFFBF2', borderRadius:16, padding:'12px', border:'1px solid #EFE8D9' }}>
          <div style={{ fontSize:9, color:'#6F7A73', fontWeight:700, letterSpacing:1.2 }}>VS MARZO</div>
          <div className="serif" style={{ fontSize:20, fontWeight:700, letterSpacing:-0.4, marginTop:2 }}>+$320k</div>
          <div style={{ fontSize:10, color:'#2CAE6E', fontWeight:700 }}>▲ 18% mejor</div>
          {/* tiny comparison bars */}
          <div style={{ display:'flex', gap:6, marginTop:8, alignItems:'flex-end', height:22 }}>
            <div style={{ flex:1, height:'60%', background:'#E9E1D3', borderRadius:3, transformOrigin:'bottom', animation:'mf-grow-bar .8s .6s ease both' }}/>
            <div style={{ flex:1, height:'100%', background:'#2E7D5B', borderRadius:3, transformOrigin:'bottom', animation:'mf-grow-bar .8s .8s ease both' }}/>
          </div>
        </div>
        <div style={{ background:'#FFFBF2', borderRadius:16, padding:'12px', border:'1px solid #EFE8D9', position:'relative', overflow:'hidden' }}>
          <div style={{ fontSize:9, color:'#6F7A73', fontWeight:700, letterSpacing:1.2 }}>RACHA</div>
          <div className="serif" style={{ fontSize:20, fontWeight:700, letterSpacing:-0.4, marginTop:2 }}>14 días</div>
          <div style={{ fontSize:10, color:'#6B3A4F', fontWeight:600 }}>sin excesos</div>
          <div style={{ position:'absolute', right:8, bottom:6, fontSize:28, animation:'mf-wiggle 2s ease-in-out infinite' }}>🔥</div>
        </div>
      </div>

      {/* today narrative */}
      <div style={{ padding:'12px 22px 0', animation:'mf-rise .9s .4s ease both' }}>
        <div style={{ background:'#FFFBF2', borderRadius:18, padding:'12px 14px', border:'1px solid #EFE8D9', display:'flex', alignItems:'center', gap:10 }}>
          <div style={{
            width:34, height:34, borderRadius:12, background:'#DDEFE3',
            display:'grid', placeItems:'center', fontSize:16, animation:'mf-bob 3s ease-in-out infinite',
          }}>☀️</div>
          <div style={{ flex:1 }}>
            <div style={{ fontSize:12, fontWeight:700, color:'#0F2A1E' }}>Martes tranquilo</div>
            <div style={{ fontSize:11, color:'#6F7A73', lineHeight:1.35 }}>Un gasto registrado · <b style={{ color:'#0F2A1E' }}>Fernet con coca $25k</b> · por Mario</div>
          </div>
          <div style={{ fontSize:11, fontWeight:700, color:'#2CAE6E' }}>bien</div>
        </div>
      </div>

      <TabBar accent="#6FE09A" bg="#F6EFE3"/>
    </div>
  );
}

function Legend({ color, label }) {
  return (
    <div style={{ display:'flex', alignItems:'center', gap:4 }}>
      <span style={{ width:7, height:7, borderRadius:4, background:color }}/>
      {label}
    </div>
  );
}

window.V6Calendario = V6Calendario;
