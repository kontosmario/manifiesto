// Control v2 — pantallas Light & Dark
// Lenguaje simple, sin jerga. Para principiantes.

// ─────────────────────────────────────────────────────────────
// LIGHT
// ─────────────────────────────────────────────────────────────
function ControlLight() {
  const D = CTRL;
  const S = useMemoCv(() => calcControl(D), []);
  return (
    <div className="screen" style={{ background:'#EFF5E8', overflowY:'auto' }}>
      <StatusBar color="#0F2A1E"/>

      {/* Ambient */}
      <div style={{ position:'absolute', top:-60, right:-60, width:240, height:240, borderRadius:'50%',
        background:'radial-gradient(closest-side, rgba(141,214,106,0.22), transparent 70%)',
        pointerEvents:'none', animation:'mf-float-slow 10s ease-in-out infinite' }}/>
      <div style={{ position:'absolute', top:720, left:-80, width:240, height:240, borderRadius:'50%',
        background:'radial-gradient(closest-side, rgba(242,181,138,0.14), transparent 70%)',
        pointerEvents:'none', animation:'mf-float-slow 14s ease-in-out infinite', animationDelay:'-4s' }}/>

      {/* Header con Score */}
      <HeaderScoreLt S={S}/>

      {/* 1. HOY */}
      <HoyLt D={D} S={S}/>

      {/* 2. HASTA CUÁNDO TE ALCANZA (proyección fecha exacta) */}
      <AlcanzaLt D={D} S={S}/>

      {/* 3. ALCANCÍA (vault) + NO-SPEND badges */}
      <AlcanciaLt D={D} S={S}/>

      {/* 4. CÓMO VENÍS ESTA SEMANA (ritmo 7 días) */}
      <SemanaLt D={D} S={S}/>

      {/* 4b. VS MES PASADO (comparación histórica) */}
      <VsMesLt D={D} S={S}/>

      {/* 5. PATRÓN — en qué día de la semana gastás más */}
      <PatronLt D={D} S={S}/>

      {/* 6. SIMULADOR — qué pasa si recortás $X por día */}
      <SimuladorLt D={D} S={S}/>

      {/* 7. COBERTURA de fijos */}
      <CoberturaLt D={D} S={S}/>

      {/* 8. ASESOR — tareas */}
      <AsesorLt D={D} S={S}/>

      <div style={{ height:120 }}/>
      <TabBar active="control" accent="#8DD66A" bg="#EFF5E8"/>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// HEADER con Score 0–100
// ─────────────────────────────────────────────────────────────
function HeaderScoreLt({ S }) {
  return (
    <div style={{ padding:'2px 22px 0', display:'flex', alignItems:'center', justifyContent:'space-between',
      animation:'mf-rise .6s ease both' }}>
      <div style={{ flex:1 }}>
        <div className="sf-display" style={{ fontSize:34, fontWeight:800, color:'#0F2A1E', letterSpacing:-1.2, lineHeight:1 }}>
          Control
        </div>
        <div style={{ fontSize:13, color:'#6F7A73', marginTop:6, maxWidth:220 }}>
          Tu guía simple de gastos, día a día.
        </div>
      </div>
      {/* Score badge */}
      <div style={{ position:'relative', width:76, height:76 }}>
        <svg width="76" height="76" viewBox="0 0 76 76">
          <circle cx="38" cy="38" r="32" fill="none" stroke="#EFE8D9" strokeWidth="6"/>
          <circle cx="38" cy="38" r="32" fill="none" stroke={S.scoreColor} strokeWidth="6"
            strokeLinecap="round"
            strokeDasharray={`${(S.score/100) * 2 * Math.PI * 32} ${2 * Math.PI * 32}`}
            style={{ transform:'rotate(-90deg)', transformOrigin:'38px 38px',
              animation:'mf-fj-ring-paid 1.4s .4s cubic-bezier(.2,.9,.2,1) both' }}/>
        </svg>
        <div style={{ position:'absolute', inset:0, display:'flex', flexDirection:'column',
          alignItems:'center', justifyContent:'center' }}>
          <div className="sf-display" style={{ fontSize:22, fontWeight:800, color:'#0F2A1E', lineHeight:1 }}>
            <CountUp to={S.score} duration={1100}/>
          </div>
          <div style={{ fontSize:8, color: S.scoreColor, fontWeight:800, letterSpacing:0.8, textTransform:'uppercase' }}>
            {S.scoreLabel}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// 1. HOY — cuánto podés gastar hoy
// ─────────────────────────────────────────────────────────────
function HoyLt({ D, S }) {
  const R = 80, C = 2 * Math.PI * R;
  const gastoPct = Math.min(1, D.gastoHoy / D.cupoDiario);
  const horaPct = S.horaF / 24;

  return (
    <div style={{ margin:'16px 22px 0',
      background:'linear-gradient(135deg, #0F2A1E 0%, #143B2A 100%)',
      borderRadius:28, padding:'20px 20px 18px', color:'#F6FBEF',
      position:'relative', overflow:'hidden',
      boxShadow:'0 18px 40px -16px rgba(15,42,30,0.5)',
      animation:'mf-rise .8s .1s ease both' }}>

      <div style={{ position:'absolute', top:-40, right:-40, width:200, height:200, borderRadius:'50%',
        background:`radial-gradient(closest-side, ${S.estaOk?'rgba(199,238,156,0.22)':'rgba(242,181,138,0.22)'}, transparent 70%)` }}/>

      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', position:'relative' }}>
        <div style={{ fontSize:11, letterSpacing:1.6, fontWeight:700, color:'#C7EE9C' }}>HOY · MARTES 22</div>
        <div style={{ fontSize:10, fontWeight:700, color:'rgba(246,251,239,0.85)',
          padding:'3px 10px', borderRadius:999,
          background:`rgba(${S.estaOk?'199,238,156':'242,181,138'},0.15)`,
          border:`1px solid rgba(${S.estaOk?'199,238,156':'242,181,138'},0.35)`,
        }}>
          {S.estaOk ? '👍 vas bien' : '⚠ ojo'}
        </div>
      </div>

      <div style={{ display:'flex', alignItems:'center', gap:14, marginTop:14, position:'relative' }}>
        <div style={{ width:190, height:190, position:'relative', flexShrink:0 }}>
          <svg width="190" height="190" viewBox="0 0 190 190">
            <defs>
              <linearGradient id="hoy-lt" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor={S.estaOk?'#C7EE9C':'#F2B58A'}/>
                <stop offset="100%" stopColor={S.estaOk?'#6FE09A':'#E8976A'}/>
              </linearGradient>
            </defs>
            {/* ticks cada 3h para menos ruido */}
            {Array.from({length: 8}).map((_, i) => {
              const angle = (i / 8) * 2 * Math.PI - Math.PI/2;
              const r1 = 92, r2 = 87;
              return <line key={i}
                x1={95 + r1*Math.cos(angle)} y1={95 + r1*Math.sin(angle)}
                x2={95 + r2*Math.cos(angle)} y2={95 + r2*Math.sin(angle)}
                stroke="rgba(246,251,239,0.3)" strokeWidth="1.5" strokeLinecap="round"/>;
            })}
            {/* aguja hora actual */}
            <g transform={`rotate(${horaPct * 360 - 90} 95 95)`}>
              <circle cx="182" cy="95" r="4" fill="#C7EE9C"
                style={{ animation:'mf-breathe 2.4s ease-in-out infinite' }}/>
            </g>
            <circle cx="95" cy="95" r={R} fill="none" stroke="rgba(246,251,239,0.08)" strokeWidth="14"/>
            <g transform="rotate(-90 95 95)">
              <circle cx="95" cy="95" r={R} fill="none" stroke="url(#hoy-lt)"
                strokeWidth="14" strokeLinecap="round"
                strokeDasharray={`${C * gastoPct} ${C}`}
                style={{ animation:'mf-fj-ring-paid 1.4s .3s cubic-bezier(.2,.9,.2,1) both',
                  filter:`drop-shadow(0 0 8px ${S.estaOk?'rgba(199,238,156,0.4)':'rgba(242,181,138,0.4)'})` }}/>
            </g>
          </svg>

          <div style={{ position:'absolute', inset:0, display:'flex', flexDirection:'column',
            alignItems:'center', justifyContent:'center', textAlign:'center' }}>
            <div style={{ fontSize:9, letterSpacing:1.4, fontWeight:700, color:'rgba(246,251,239,0.6)' }}>
              TE QUEDAN PARA HOY
            </div>
            <div className="sf-display" style={{ fontSize:26, fontWeight:800, color:'#F6FBEF',
              letterSpacing:-1, lineHeight:1, marginTop:3,
              textShadow:'0 0 16px rgba(199,238,156,0.25)' }}>
              $<CountUp to={Math.max(0, S.libreHoy)} duration={1200}/>
            </div>
            <div style={{ marginTop:4, fontSize:10, color:'rgba(246,251,239,0.55)', fontWeight:600 }}>
              ya gastaste ${D.gastoHoy.toLocaleString('es-AR')}
            </div>
          </div>
        </div>

        {/* side info */}
        <div style={{ flex:1, display:'flex', flexDirection:'column', gap:8 }}>
          <div style={{ padding:'10px 12px', borderRadius:12,
            background:'rgba(246,251,239,0.05)', border:'1px solid rgba(246,251,239,0.08)' }}>
            <div style={{ fontSize:9, letterSpacing:1.3, fontWeight:700, color:'rgba(246,251,239,0.55)' }}>
              TU PLATA DEL DÍA
            </div>
            <div className="sf-display" style={{ fontSize:18, fontWeight:800, color:'#F6FBEF', letterSpacing:-0.5, marginTop:2 }}>
              ${D.cupoDiario.toLocaleString('es-AR')}
            </div>
            <div style={{ fontSize:10, color:'rgba(246,251,239,0.5)', marginTop:1 }}>
              sin tocar fijos
            </div>
          </div>

          <div style={{ padding:'10px 12px', borderRadius:12,
            background: S.estaOk ? 'linear-gradient(135deg, rgba(199,238,156,0.14), rgba(141,214,106,0.04))'
                               : 'linear-gradient(135deg, rgba(242,181,138,0.14), rgba(232,151,106,0.04))',
            border: `1px solid ${S.estaOk?'rgba(199,238,156,0.25)':'rgba(242,181,138,0.25)'}` }}>
            <div style={{ fontSize:9, letterSpacing:1.3, fontWeight:700, color:'rgba(246,251,239,0.55)' }}>
              {S.estaOk ? 'TE ESTÁS AHORRANDO' : 'TE PASASTE POR'}
            </div>
            <div className="sf-display" style={{ fontSize:18, fontWeight:800,
              color: S.estaOk ? '#C7EE9C' : '#F2B58A', letterSpacing:-0.5, marginTop:2 }}>
              ${Math.abs(Math.round(S.delta)).toLocaleString('es-AR')}
            </div>
            <div style={{ fontSize:10, color: 'rgba(246,251,239,0.55)', fontWeight:600, marginTop:1 }}>
              a las {D.horaActual}:{String(D.minActual).padStart(2,'0')}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// 2. HASTA CUÁNDO TE ALCANZA — proyección fecha exacta
// ─────────────────────────────────────────────────────────────
function AlcanzaLt({ D, S }) {
  // Mini calendario horizontal del mes con marcadores
  const diaAgot = S.diaAgotamiento;
  const alcanza = S.alcanzaElMes;

  return (
    <div style={{ margin:'16px 22px 0', animation:'mf-rise .8s .2s ease both' }}>
      <div style={{ display:'flex', alignItems:'baseline', justifyContent:'space-between', marginBottom:8 }}>
        <CvLabel theme="light">HASTA CUÁNDO TE ALCANZA</CvLabel>
        <CvWhat theme="light" text="según cómo venís gastando"/>
      </div>
      <div style={{
        background: alcanza ? 'linear-gradient(135deg, #C7EE9C22, #8DD66A08)' : 'linear-gradient(135deg, #F2B58A22, #E8976A08)',
        border:`1px solid ${alcanza?'#C7EE9C66':'#F2B58A66'}`, borderRadius:20, padding:'16px 18px',
      }}>
        <div style={{ display:'flex', alignItems:'flex-start', gap:14 }}>
          <div style={{ fontSize:32, lineHeight:1 }}>{alcanza ? '✅' : '⚠️'}</div>
          <div style={{ flex:1 }}>
            <div className="sf-display" style={{ fontSize:20, fontWeight:800, color:'#0F2A1E', lineHeight:1.2, letterSpacing:-0.4 }}>
              {alcanza
                ? <>La plata te alcanza <span style={{ color:'#2E7D5B' }}>todo el mes</span>.</>
                : <>Si seguís así, la plata se te acaba el <span style={{ color:'#D96A4F' }}>día {diaAgot}</span>.</>
              }
            </div>
            <div style={{ fontSize:12, color:'#6F7A73', marginTop:4, lineHeight:1.4 }}>
              {alcanza
                ? <>A tu ritmo actual, vas a terminar con <b>${Math.round(S.sobrantePresupuestadoMes).toLocaleString('es-AR')} de sobra</b> el día 30.</>
                : <>Te faltarían <b>{D.diasMes - diaAgot} días</b> para el próximo sueldo. Recortá un poco para llegar.</>
              }
            </div>
          </div>
        </div>

        {/* Mini calendario 30 días */}
        <div style={{ marginTop:14, padding:'10px 12px', background:'#FFFBF2', borderRadius:12,
          border:'1px solid #EFE8D9' }}>
          <div style={{ display:'flex', justifyContent:'space-between', fontSize:9,
            color:'#9AA39D', fontWeight:700, letterSpacing:1, marginBottom:6 }}>
            <span>DÍA 1</span><span>HOY</span><span>DÍA 30</span>
          </div>
          <div style={{ position:'relative', height:24 }}>
            {/* track */}
            <div style={{ position:'absolute', top:10, left:0, right:0, height:4,
              background:'#EFE8D9', borderRadius:2 }}/>
            {/* pasado */}
            <div style={{ position:'absolute', top:10, left:0, width:`${(D.diaActual/D.diasMes)*100}%`,
              height:4, background:'linear-gradient(90deg, #2E7D5B, #8DD66A)', borderRadius:2,
              animation:'mf-grow-bar 1s .5s ease both', transformOrigin:'left' }}/>
            {/* proyección restante */}
            {!alcanza && (
              <div style={{ position:'absolute', top:10,
                left:`${(D.diaActual/D.diasMes)*100}%`,
                width:`${((diaAgot - D.diaActual)/D.diasMes)*100}%`,
                height:4, background:'linear-gradient(90deg, #F2B58A, #D96A4F)', borderRadius:2,
                animation:'mf-grow-bar 1s .8s ease both', transformOrigin:'left' }}/>
            )}
            {/* marcador hoy */}
            <div style={{ position:'absolute', top:4, left:`calc(${(D.diaActual/D.diasMes)*100}% - 8px)`,
              width:16, height:16, borderRadius:'50%', background:'#0F2A1E',
              border:'3px solid #FFFBF2', boxShadow:'0 0 0 1px #EFE8D9' }}>
              <div style={{ position:'absolute', top:-20, left:'50%', transform:'translateX(-50%)',
                fontSize:9, fontWeight:800, color:'#0F2A1E', whiteSpace:'nowrap' }}>HOY</div>
            </div>
            {/* marcador día agotamiento */}
            {!alcanza && (
              <div style={{ position:'absolute', top:4, left:`calc(${(diaAgot/D.diasMes)*100}% - 8px)`,
                width:16, height:16, borderRadius:'50%', background:'#D96A4F',
                border:'3px solid #FFFBF2', boxShadow:'0 0 0 1px #EFE8D9',
                animation:'mf-breathe 2s ease-in-out infinite' }}>
                <div style={{ position:'absolute', top:20, left:'50%', transform:'translateX(-50%)',
                  fontSize:9, fontWeight:800, color:'#D96A4F', whiteSpace:'nowrap' }}>día {diaAgot}</div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// 3. ALCANCÍA + NO-SPEND DAYS
// ─────────────────────────────────────────────────────────────
function AlcanciaLt({ D, S }) {
  return (
    <div style={{ margin:'16px 22px 0', animation:'mf-rise .8s .3s ease both' }}>
      <div style={{
        background:'#FFFBF2', border:'1px solid #EFE8D9', borderRadius:24,
        padding:'18px 20px', position:'relative', overflow:'hidden',
      }}>
        <CvLabel theme="light">TU ALCANCÍA · lo que ya guardaste este mes</CvLabel>
        <div style={{ display:'flex', alignItems:'flex-end', gap:14, marginTop:6 }}>
          <div style={{ flex:1 }}>
            <div className="sf-display" style={{ fontSize:36, fontWeight:800, color:'#0F2A1E',
              letterSpacing:-1.4, lineHeight:1 }}>
              +$<CountUp to={S.vault} duration={1400}/>
            </div>
            <div style={{ fontSize:12, color:'#2E7D5B', fontWeight:700, marginTop:4 }}>
              en {S.diasGanadores} días que no gastaste todo
            </div>
          </div>
          <VaultGlyphLt/>
        </div>

        {/* No-spend badge bar */}
        <div style={{ marginTop:14, padding:'12px 14px', background:'#F3EFE0',
          borderRadius:14, border:'1px dashed #D9D2C4',
          display:'flex', alignItems:'center', gap:10 }}>
          <div style={{ fontSize:26 }}>🎯</div>
          <div style={{ flex:1 }}>
            <div style={{ fontSize:13, fontWeight:800, color:'#0F2A1E' }}>
              {D.logrosNoSpendSemana} de {D.metaNoSpendSemana} días sin gastar esta semana
            </div>
            <div style={{ fontSize:11, color:'#6F7A73', marginTop:2 }}>
              Un día sin gastar = un día entero de cupo al bolsillo.
            </div>
          </div>
          <div style={{ display:'flex', gap:3 }}>
            {Array.from({length: D.metaNoSpendSemana}).map((_,i)=>(
              <div key={i} style={{ width:14, height:14, borderRadius:'50%',
                background: i < D.logrosNoSpendSemana ? '#2E7D5B' : '#D9D2C4',
                border: i < D.logrosNoSpendSemana ? 'none' : '1px dashed #9AA39D',
              }}>
                {i < D.logrosNoSpendSemana && <div style={{ color:'#FFFBF2', fontSize:9, textAlign:'center',
                  lineHeight:'14px', fontWeight:800 }}>✓</div>}
              </div>
            ))}
          </div>
        </div>

        {/* stats */}
        <div style={{ marginTop:12, display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:8 }}>
          <MiniLt label="RACHA" value={`${S.racha} días`} sub="sin pasarte" emoji="🔥" tint="#E8976A"/>
          <MiniLt label="MEJOR DÍA" value={`$${(S.mejor.gasto/1000).toFixed(0)}k`} sub={`día ${S.mejor.dia}`} emoji="⭐" tint="#2E7D5B"/>
          <MiniLt label="SIN GASTAR" value={`${S.noSpendCount}`} sub="días este mes" emoji="🏆" tint="#C9A23A"/>
        </div>
      </div>
    </div>
  );
}

function VaultGlyphLt() {
  return (
    <svg width="86" height="78" viewBox="0 0 86 78" style={{ animation:'mf-bob 4s ease-in-out infinite' }}>
      <defs>
        <linearGradient id="vlt-coin-lt" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#F2B58A"/><stop offset="100%" stopColor="#E8976A"/>
        </linearGradient>
      </defs>
      {[2,1,0].map(i => (
        <ellipse key={i} cx="20" cy={54 - i*6} rx="14" ry="4.5" fill="url(#vlt-coin-lt)" opacity={0.85 - i*0.12}/>
      ))}
      <path d="M42 58 C 42 34, 58 22, 74 32 C 82 38, 84 54, 72 62 C 60 70, 46 68, 42 58 Z"
        fill="#2E7D5B" opacity="0.9"/>
      <path d="M42 58 C 42 34, 58 22, 74 32 C 82 38, 84 54, 72 62 C 60 70, 46 68, 42 58 Z"
        fill="none" stroke="#0F2A1E" strokeWidth="1.5"/>
      <rect x="56" y="28" width="14" height="3" rx="1.5" fill="#0F2A1E"/>
      <circle cx="68" cy="44" r="1.5" fill="#0F2A1E"/>
      <circle cx="64" cy="38" r="3" fill="#F6FBEF" opacity="0.28"/>
    </svg>
  );
}

function MiniLt({ label, value, sub, emoji, tint }) {
  return (
    <div style={{ padding:'10px 10px', background:'#F6F1E4', borderRadius:12, border:'1px solid #EFE8D9' }}>
      <div style={{ display:'flex', alignItems:'center', gap:4 }}>
        <span style={{ fontSize:11 }}>{emoji}</span>
        <span style={{ fontSize:9, letterSpacing:1.2, fontWeight:700, color:'#9AA39D' }}>{label}</span>
      </div>
      <div style={{ fontSize:14, fontWeight:800, color: tint || '#0F2A1E', marginTop:2, letterSpacing:-0.3 }}>
        {value}
      </div>
      {sub && <div style={{ fontSize:10, color:'#9AA39D', marginTop:1 }}>{sub}</div>}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// 4. CÓMO VENÍS ESTA SEMANA
// ─────────────────────────────────────────────────────────────
function SemanaLt({ D, S }) {
  const items = S.last7;
  const maxDisplay = Math.max(D.cupoDiario * 1.4, ...items.map(i => i.gasto));
  const momentumLabel = S.momentum > 1.1 ? 'acelerando' : S.momentum < 0.9 ? 'frenando' : 'estable';
  const momColor = S.momentum > 1.1 ? '#D96A4F' : S.momentum < 0.9 ? '#2E7D5B' : '#6F7A73';

  return (
    <div style={{ margin:'16px 22px 0', animation:'mf-rise .8s .4s ease both' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', marginBottom:8 }}>
        <CvLabel theme="light">CÓMO VENÍS ESTA SEMANA</CvLabel>
        <div style={{ fontSize:11, color: momColor, fontWeight:800 }}>
          {S.momentum > 1.1 ? '↑' : S.momentum < 0.9 ? '↓' : '→'} {momentumLabel}
        </div>
      </div>
      <div style={{ background:'#FFFBF2', border:'1px solid #EFE8D9', borderRadius:20,
        padding:'16px 18px 14px' }}>
        <div style={{ display:'grid', gridTemplateColumns:`repeat(${items.length}, 1fr)`, gap:8,
          alignItems:'flex-end', height:110, position:'relative' }}>
          <div style={{ position:'absolute', left:0, right:0,
            bottom: `${(D.cupoDiario/maxDisplay)*100}%`,
            height:1, background:'#D9D2C4', zIndex:1 }}>
            <span style={{ position:'absolute', right:0, top:-14, fontSize:9, fontWeight:700,
              color:'#9AA39D', background:'#FFFBF2', padding:'0 4px' }}>TU PLATA/DÍA</span>
          </div>
          {items.map((d, i) => {
            const pct = Math.min(1, d.gasto / maxDisplay);
            const over = d.gasto > D.cupoDiario && !d.inProgress;
            const gradient = d.inProgress
              ? 'linear-gradient(180deg, #8FB8E0, #6B9AD6)'
              : over
              ? 'linear-gradient(180deg, #E88A70, #C03A2A)'
              : 'linear-gradient(180deg, #8DD66A, #2E7D5B)';
            return (
              <div key={i} style={{ position:'relative', height:'100%',
                display:'flex', flexDirection:'column', justifyContent:'flex-end', zIndex:2 }}>
                <div style={{
                  width:'100%', height:`${pct*100}%`, borderRadius:'6px 6px 2px 2px',
                  background: gradient,
                  animation: `mf-grow-vert .7s ${0.4 + i*0.06}s cubic-bezier(.2,.9,.2,1) both`,
                  transformOrigin:'bottom',
                  position:'relative',
                }}>
                  {d.inProgress && (
                    <div style={{ position:'absolute', inset:0,
                      background:'repeating-linear-gradient(45deg, transparent 0 6px, rgba(246,251,239,0.2) 6px 8px)',
                      borderRadius:'inherit' }}/>
                  )}
                </div>
              </div>
            );
          })}
        </div>
        <div style={{ marginTop:6, display:'grid', gridTemplateColumns:`repeat(${items.length}, 1fr)`, gap:8 }}>
          {items.map((d, i) => (
            <div key={i} style={{ textAlign:'center', fontSize:10,
              fontWeight: d.inProgress ? 800 : 600,
              color: d.inProgress ? '#0F2A1E' : '#9AA39D' }}>{d.dia}</div>
          ))}
        </div>
        <div style={{ marginTop:10, padding:'8px 10px', background:'#F6F1E4', borderRadius:10,
          fontSize:11, color:'#6F7A73' }}>
          💡 Promedio últimos 7 días: <b style={{ color:'#0F2A1E' }}>${Math.round(S.avgU7).toLocaleString('es-AR')}/día</b>
          {S.momentum > 1.05 && <> — gastás {((S.momentum-1)*100).toFixed(0)}% más que la semana anterior.</>}
          {S.momentum < 0.95 && <> — gastás {((1-S.momentum)*100).toFixed(0)}% menos que la semana anterior. ¡Bien!</>}
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// 4b. VS MES PASADO
// ─────────────────────────────────────────────────────────────
function VsMesLt({ D, S }) {
  const mp = D.mesPasado;
  const mejor = S.vsMesMejor;
  const diffAbs = Math.abs(S.vsMesAhorro);
  const pctAbs = Math.abs(S.vsMesDeltaPct);
  const maxVal = Math.max(S.proyectadoMes, S.mpTotal);
  const pctThis = (S.proyectadoMes / maxVal) * 100;
  const pctLast = (S.mpTotal / maxVal) * 100;

  return (
    <div style={{ margin:'16px 22px 0', animation:'mf-rise .8s .45s ease both' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', marginBottom:8 }}>
        <CvLabel theme="light">VS {mp.nombre.toUpperCase()}</CvLabel>
        <div style={{ fontSize:11, color: mejor ? '#2E7D5B' : '#D96A4F', fontWeight:800 }}>
          {mejor ? '▼' : '▲'} {pctAbs.toFixed(0)}%
        </div>
      </div>
      <div style={{
        background: mejor ? 'linear-gradient(135deg, #C7EE9C22, #8DD66A08)' : 'linear-gradient(135deg, #F2B58A22, #E8976A08)',
        border:`1px solid ${mejor?'#C7EE9C66':'#F2B58A66'}`, borderRadius:20, padding:'16px 18px',
      }}>
        <div className="sf-display" style={{ fontSize:17, fontWeight:800, color:'#0F2A1E', lineHeight:1.3, letterSpacing:-0.3 }}>
          {mejor
            ? <>Vas a <span style={{ color:'#2E7D5B' }}>ahorrar ${Math.round(diffAbs/1000)}k</span> comparado con {mp.nombre}.</>
            : <>Vas a <span style={{ color:'#D96A4F' }}>gastar ${Math.round(diffAbs/1000)}k más</span> que en {mp.nombre}.</>
          }
        </div>
        <div style={{ fontSize:12, color:'#6F7A73', marginTop:4 }}>
          Si seguís al ritmo de estos últimos días.
        </div>

        {/* barras comparativas */}
        <div style={{ marginTop:14, display:'flex', flexDirection:'column', gap:10 }}>
          <BarRowLt
            label={`${mp.nombre} (cerrado)`}
            amount={S.mpTotal}
            pct={pctLast}
            color="#D9D2C4"
            sub={`${mp.diasBajoCupo} días bajo cupo`}
            delay={0.5}
          />
          <BarRowLt
            label="Abril (proyección)"
            amount={S.proyectadoMes}
            pct={pctThis}
            color={mejor ? 'linear-gradient(90deg,#2E7D5B,#8DD66A)' : 'linear-gradient(90deg,#D96A4F,#E88A70)'}
            sub={`${S.diasGanadores} días bajo cupo${S.vsMesDiasBajoCupo > 0 ? ` · +${S.vsMesDiasBajoCupo} vs ${mp.nombre.toLowerCase()}` : ''}`}
            delay={0.65}
            highlight
          />
        </div>

        <div style={{ marginTop:12, padding:'8px 10px', background:'#F6F1E4', borderRadius:10,
          fontSize:11, color:'#6F7A73' }}>
          💡 En {mp.nombre} lo peor fue <b style={{ color:'#0F2A1E' }}>{mp.topCat.label}</b> (${mp.topCat.amount.toLocaleString('es-AR')}).
          {' '}Mantené esa categoría bajo control.
        </div>
      </div>
    </div>
  );
}

function BarRowLt({ label, amount, pct, color, sub, delay=0, highlight }) {
  return (
    <div>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', marginBottom:5 }}>
        <div style={{ fontSize:12, fontWeight: highlight ? 800 : 600, color:'#0F2A1E' }}>{label}</div>
        <div className="sf-display" style={{ fontSize:14, fontWeight:800, color:'#0F2A1E', letterSpacing:-0.3 }}>
          ${amount.toLocaleString('es-AR')}
        </div>
      </div>
      <div style={{ height:10, background:'#EFE8D9', borderRadius:5, overflow:'hidden', position:'relative' }}>
        <div style={{
          height:'100%', width:`${pct}%`,
          background: color,
          borderRadius:5, transformOrigin:'left',
          animation: `mf-grow-bar 1s ${delay}s cubic-bezier(.2,.9,.2,1) both`,
        }}/>
      </div>
      {sub && <div style={{ fontSize:10.5, color:'#9AA39D', marginTop:4, fontWeight:600 }}>{sub}</div>}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// 5. PATRÓN — día de la semana
// ─────────────────────────────────────────────────────────────
function PatronLt({ D, S }) {
  const dows = S.porDowEnriched;
  const maxAvg = Math.max(...dows.map(d=>d.avg));

  return (
    <div style={{ margin:'16px 22px 0', animation:'mf-rise .8s .5s ease both' }}>
      <div style={{ marginBottom:8 }}>
        <CvLabel theme="light">TU PATRÓN SEMANAL</CvLabel>
      </div>
      <div style={{ background:'#FFFBF2', border:'1px solid #EFE8D9', borderRadius:20, padding:'16px 18px' }}>
        <div className="sf-display" style={{ fontSize:16, fontWeight:800, color:'#0F2A1E', lineHeight:1.3 }}>
          Los <span style={{ color:'#D96A4F' }}>{S.peorDow.name.toLowerCase()}s</span> gastás {' '}
          <span style={{ color:'#D96A4F' }}>{S.peorDow.ratio.toFixed(1)}×</span> más que el promedio.
        </div>
        <div style={{ fontSize:12, color:'#6F7A73', marginTop:4 }}>
          Los <b style={{ color:'#2E7D5B' }}>{S.mejorDow.name.toLowerCase()}s</b> sos el más ahorrativo.
        </div>

        <div style={{ marginTop:12, display:'grid', gridTemplateColumns:'repeat(7, 1fr)', gap:6, alignItems:'flex-end', height:80 }}>
          {dows.map((d, i) => {
            const pct = d.avg > 0 ? (d.avg / maxAvg) : 0;
            const isPeor = d.name === S.peorDow.name;
            const isMejor = d.name === S.mejorDow.name && d.avg > 0;
            return (
              <div key={i} style={{ display:'flex', flexDirection:'column', justifyContent:'flex-end', height:'100%' }}>
                <div style={{
                  width:'100%', height:`${pct*100}%`, borderRadius:'4px 4px 2px 2px',
                  background: isPeor ? 'linear-gradient(180deg,#E88A70,#D96A4F)'
                           : isMejor ? 'linear-gradient(180deg,#8DD66A,#2E7D5B)'
                           : '#D9D2C4',
                  animation: `mf-grow-vert .6s ${0.5 + i*0.05}s cubic-bezier(.2,.9,.2,1) both`,
                  transformOrigin:'bottom',
                }}/>
              </div>
            );
          })}
        </div>
        <div style={{ marginTop:4, display:'grid', gridTemplateColumns:'repeat(7, 1fr)', gap:6 }}>
          {dows.map((d,i) => {
            const isPeor = d.name === S.peorDow.name;
            const isMejor = d.name === S.mejorDow.name && d.avg > 0;
            return (
              <div key={i} style={{ textAlign:'center', fontSize:10,
                fontWeight: (isPeor||isMejor)?800:600,
                color: isPeor?'#D96A4F':isMejor?'#2E7D5B':'#9AA39D' }}>
                {d.name}
              </div>
            );
          })}
        </div>

        <div style={{ marginTop:10, padding:'8px 10px', background:'#F6F1E4', borderRadius:10,
          fontSize:11, color:'#6F7A73' }}>
          💡 Si bajás el gasto de los {S.peorDow.name.toLowerCase()}s a tu promedio, ahorrás{' '}
          <b style={{ color:'#2E7D5B' }}>
            ${Math.round((S.peorDow.avg - S.globalAvg) * 4).toLocaleString('es-AR')}/mes
          </b>.
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// 6. SIMULADOR — qué pasa si recortás $X/día
// ─────────────────────────────────────────────────────────────
function SimuladorLt({ D, S }) {
  const [recorte, setRecorte] = useStateCv(3000);
  const ahorroMes = recorte * 30;
  const ahorroAno = recorte * 365;

  return (
    <div style={{ margin:'16px 22px 0', animation:'mf-rise .8s .6s ease both' }}>
      <div style={{ marginBottom:8 }}>
        <CvLabel theme="light">SIMULADOR · ¿qué pasa si gastás menos?</CvLabel>
      </div>
      <div style={{ background:'linear-gradient(135deg, #FFFBF2, #F6F1E4)',
        border:'1px solid #EFE8D9', borderRadius:20, padding:'16px 18px' }}>
        <div className="sf-display" style={{ fontSize:16, fontWeight:800, color:'#0F2A1E' }}>
          Si recortás <span style={{ color:'#2E7D5B' }}>${recorte.toLocaleString('es-AR')}</span> por día...
        </div>
        <div style={{ fontSize:12, color:'#6F7A73', marginTop:2 }}>
          (un café, un delivery, una app que no usás)
        </div>

        {/* Slider custom */}
        <div style={{ marginTop:14 }}>
          <input type="range" min="500" max="10000" step="500"
            value={recorte} onChange={e=>setRecorte(+e.target.value)}
            style={{ width:'100%', accentColor:'#2E7D5B' }}/>
          <div style={{ display:'flex', justifyContent:'space-between', fontSize:10, color:'#9AA39D', fontWeight:600 }}>
            <span>$500</span><span>$5.000</span><span>$10.000</span>
          </div>
        </div>

        {/* Resultados */}
        <div style={{ marginTop:14, display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
          <div style={{ padding:'12px 14px', background:'#FFFBF2',
            borderRadius:14, border:'1px solid #C7EE9C66',
            background:'linear-gradient(135deg, rgba(199,238,156,0.2), rgba(141,214,106,0.06))' }}>
            <div style={{ fontSize:9, letterSpacing:1.2, fontWeight:700, color:'#6F7A73' }}>EN UN MES</div>
            <div className="sf-display" style={{ fontSize:22, fontWeight:800, color:'#2E7D5B', letterSpacing:-0.6, marginTop:2 }}>
              +${ahorroMes.toLocaleString('es-AR')}
            </div>
          </div>
          <div style={{ padding:'12px 14px', background:'#0F2A1E',
            borderRadius:14, color:'#F6FBEF' }}>
            <div style={{ fontSize:9, letterSpacing:1.2, fontWeight:700, color:'#C7EE9C' }}>EN UN AÑO</div>
            <div className="sf-display" style={{ fontSize:22, fontWeight:800, color:'#F6FBEF', letterSpacing:-0.6, marginTop:2 }}>
              +${(ahorroAno/1000).toFixed(0)}k
            </div>
          </div>
        </div>
        <div style={{ marginTop:10, padding:'8px 10px', background:'#F3EFE0', borderRadius:10,
          fontSize:11, color:'#6F7A73', lineHeight:1.4 }}>
          💰 Con <b style={{ color:'#0F2A1E' }}>${ahorroAno.toLocaleString('es-AR')}</b> en un año podrías:{' '}
          <b style={{ color:'#0F2A1E' }}>
            {ahorroAno >= 1500000 ? 'irte de viaje 10 días' :
             ahorroAno >= 800000 ? 'comprar un celular nuevo' :
             ahorroAno >= 400000 ? 'pagarte 2 meses de alquiler' :
             'darte 30 cenas afuera'}
          </b>.
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// 7. COBERTURA DE FIJOS
// ─────────────────────────────────────────────────────────────
function CoberturaLt({ D, S }) {
  return (
    <div style={{ margin:'16px 22px 0', animation:'mf-rise .8s .7s ease both' }}>
      <div style={{ marginBottom:8 }}>
        <CvLabel theme="light">TU SUELDO EN DÍAS</CvLabel>
      </div>
      <div style={{ background:'#FFFBF2', border:'1px solid #EFE8D9', borderRadius:20, padding:'16px 18px' }}>
        <div className="sf-display" style={{ fontSize:15, fontWeight:800, color:'#0F2A1E', lineHeight:1.3 }}>
          Los primeros <span style={{ color:'#D96A4F' }}>{S.coberturaFijos} días</span> del mes pagás fijos.
          <br/>
          Los otros <span style={{ color:'#2E7D5B' }}>{S.diasLibres} días</span> son para vos.
        </div>

        {/* Barra 30 días */}
        <div style={{ marginTop:14, display:'flex', borderRadius:8, overflow:'hidden', height:28,
          border:'1px solid #EFE8D9' }}>
          <div style={{ width:`${(S.coberturaFijos/D.diasMes)*100}%`,
            background:'linear-gradient(90deg, #F2B58A, #D96A4F)',
            display:'flex', alignItems:'center', justifyContent:'center',
            fontSize:10, fontWeight:800, color:'#FFFBF2' }}>
            FIJOS · {S.coberturaFijos}d
          </div>
          <div style={{ flex:1,
            background:'linear-gradient(90deg, #8DD66A, #2E7D5B)',
            display:'flex', alignItems:'center', justifyContent:'center',
            fontSize:10, fontWeight:800, color:'#FFFBF2' }}>
            LIBRE · {S.diasLibres}d
          </div>
        </div>
        <div style={{ marginTop:10, padding:'8px 10px', background:'#F6F1E4', borderRadius:10,
          fontSize:11, color:'#6F7A73' }}>
          💡 De cada $100 que entran, <b style={{ color:'#0F2A1E' }}>${Math.round((D.fijosMes/D.ingresoMes)*100)}</b> se van a fijos.
          {(D.fijosMes/D.ingresoMes) > 0.5 && <> Intentá que esto baje del 50%.</>}
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// 8. ASESOR — tareas
// ─────────────────────────────────────────────────────────────
function AsesorLt({ D, S }) {
  const totalImpacto = D.tareas.reduce((s,t)=>s+t.impactRaw, 0);
  return (
    <div style={{ margin:'20px 22px 0', animation:'mf-rise .8s .8s ease both' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:8 }}>
        <div>
          <CvLabel theme="light">QUÉ HACER ESTA SEMANA</CvLabel>
          <div style={{ fontSize:13, color:'#0F2A1E', fontWeight:700, marginTop:4 }}>
            Haciendo esto, ganás <span style={{ color:'#2E7D5B' }}>+${totalImpacto.toLocaleString('es-AR')} por mes</span>
          </div>
        </div>
        <div style={{ padding:'4px 10px', borderRadius:999, background:'#0F2A1E',
          color:'#C7EE9C', fontSize:10, fontWeight:800, letterSpacing:1 }}>
          {D.tareas.length} IDEAS
        </div>
      </div>

      <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
        {D.tareas.map((t, i) => (
          <TareaCardLt key={t.id} t={t} delay={0.85 + i*0.08}/>
        ))}
      </div>

      <div style={{ marginTop:14, padding:'14px 16px', borderRadius:16,
        background:'linear-gradient(135deg, #0F2A1E, #143B2A)', color:'#F6FBEF',
        position:'relative', overflow:'hidden' }}>
        <div style={{ position:'absolute', top:-20, right:-20, fontSize:70, opacity:0.1 }}>🌱</div>
        <CvLabel theme="dark" color="#C7EE9C">AL CERRAR EL MES</CvLabel>
        <div className="sf-display" style={{ fontSize:19, fontWeight:800,
          marginTop:4, letterSpacing:-0.5, lineHeight:1.2 }}>
          Si seguís así, vas a guardar <span style={{ color:'#C7EE9C' }}>$480.000</span> más que el mes pasado.
        </div>
        <div style={{ fontSize:11, color:'rgba(246,251,239,0.6)', marginTop:6 }}>
          El mes pasado cerraste con $1.440.000. Este mes apuntás a $1.920.000.
        </div>
      </div>
    </div>
  );
}

function TareaCardLt({ t, delay }) {
  const clr = t.urgency==='alta' ? '#D96A4F' : t.urgency==='media' ? '#E8976A' : '#C9A23A';
  const bg  = t.urgency==='alta' ? '#F5C6B6' : t.urgency==='media' ? '#FADFC8' : '#F3E8D0';
  return (
    <div style={{
      background:'#FFFBF2', border:'1px solid #EFE8D9', borderRadius:16,
      padding:'14px 16px', position:'relative', overflow:'hidden',
      animation:`mf-rise .6s ${delay}s ease both`,
    }}>
      <div style={{ position:'absolute', left:0, top:0, bottom:0, width:4, background: clr, opacity:0.8 }}/>
      <div style={{ display:'flex', alignItems:'flex-start', gap:12, paddingLeft:6 }}>
        <div style={{ width:44, height:44, borderRadius:12,
          background:`linear-gradient(140deg, ${bg}, ${bg}88)`,
          border:`1px solid ${clr}44`,
          display:'grid', placeItems:'center', fontSize:20, flexShrink:0 }}>
          {t.emoji}
        </div>
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ fontSize:14, fontWeight:800, color:'#0F2A1E', letterSpacing:-0.2 }}>
            {t.title}
          </div>
          <div style={{ fontSize:12, color:'#6F7A73', marginTop:2, lineHeight:1.4 }}>
            {t.body}
          </div>
          <div style={{ marginTop:8, display:'flex', alignItems:'center', gap:8 }}>
            <div style={{ flex:1, display:'flex', alignItems:'center', gap:6, fontSize:11,
              color:'#2E7D5B', fontWeight:700 }}>
              <span style={{ fontSize:13 }}>💰</span> {t.impact}
            </div>
            <button style={{
              background:'#0F2A1E', color:'#F6FBEF', border:'none',
              padding:'8px 14px', borderRadius:999, cursor:'pointer',
              fontSize:12, fontWeight:700, fontFamily:'inherit',
            }}>{t.cta} →</button>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { ControlLight });
