// V2 — "Mentu, la mascota"
// Gamificación suave: mascota animada que reacciona al estado del mes,
// racha de días, nivel familiar, micro-celebraciones. Números aún grandes
// pero con más respiración visual y color. Máximo tono "juguetón y vivo".

const { useEffect: useEffect2, useState: useState2 } = React;

function Mentu({ mood = 'happy', size = 130 }) {
  // little stylized plant/coin creature — abstract, non-copyrighted
  const bodyColor = mood === 'happy' ? '#6FE09A' : '#F2B58A';
  return (
    <div style={{ width:size, height:size, position:'relative',
      animation:'mf-float-slow 4.5s ease-in-out infinite' }}>
      <svg viewBox="0 0 120 120" width={size} height={size}>
        {/* shadow */}
        <ellipse cx="60" cy="110" rx="26" ry="4" fill="rgba(15,42,30,0.15)"/>
        {/* coin body */}
        <circle cx="60" cy="62" r="38" fill={bodyColor}/>
        <circle cx="60" cy="62" r="38" fill="url(#mShine)"/>
        {/* inner ring */}
        <circle cx="60" cy="62" r="31" fill="none" stroke="rgba(15,42,30,0.12)" strokeWidth="2"/>
        {/* leaf on top */}
        <path d="M60 24c-6-12 8-18 14-10-2 8-8 12-14 10z" fill="#2E7D5B"/>
        <path d="M60 24c4-8 14-6 14-6" fill="none" stroke="#143B2A" strokeWidth="1.5" strokeLinecap="round"/>
        {/* eyes */}
        <g style={{ transformOrigin:'50px 58px', animation:'mf-blink 4s ease-in-out infinite' }}>
          <ellipse cx="50" cy="58" rx="3.5" ry="4.5" fill="#0F2A1E"/>
          <circle cx="51" cy="56.5" r="1.2" fill="#fff"/>
        </g>
        <g style={{ transformOrigin:'72px 58px', animation:'mf-blink 4s ease-in-out infinite', animationDelay:'.1s' }}>
          <ellipse cx="72" cy="58" rx="3.5" ry="4.5" fill="#0F2A1E"/>
          <circle cx="73" cy="56.5" r="1.2" fill="#fff"/>
        </g>
        {/* cheeks */}
        <circle cx="42" cy="68" r="4" fill="#F2B58A" opacity=".7"/>
        <circle cx="80" cy="68" r="4" fill="#F2B58A" opacity=".7"/>
        {/* smile */}
        <path d="M54 72 Q60 78 68 72" stroke="#0F2A1E" strokeWidth="2.2" strokeLinecap="round" fill="none"/>
        <defs>
          <radialGradient id="mShine" cx="0.3" cy="0.25" r="0.7">
            <stop offset="0" stopColor="#fff" stopOpacity=".35"/>
            <stop offset="1" stopColor="#fff" stopOpacity="0"/>
          </radialGradient>
        </defs>
      </svg>
      {/* floating sparkles */}
      <div style={{ position:'absolute', top:4, right:4, fontSize:12, animation:'mf-sparkle 2s ease-in-out infinite' }}>✦</div>
      <div style={{ position:'absolute', bottom:16, left:-2, fontSize:9, animation:'mf-sparkle 2.5s .6s ease-in-out infinite' }}>✦</div>
    </div>
  );
}

function StreakBadge({ days = 14 }) {
  return (
    <div style={{
      display:'inline-flex', alignItems:'center', gap:6,
      background:'linear-gradient(140deg, #FADFC8, #F2B58A)',
      borderRadius:999, padding:'6px 12px 6px 8px', fontSize:12, fontWeight:700, color:'#6B3A4F',
      boxShadow:'0 4px 12px -4px rgba(224,142,99,0.5)',
    }}>
      <span style={{ fontSize:14, animation:'mf-wiggle 2s ease-in-out infinite' }}>🔥</span>
      {days} días de racha
    </div>
  );
}

function LevelBar({ pct = 72, level = 4 }) {
  return (
    <div style={{ background:'#FFFBF2', borderRadius:14, padding:'10px 12px', border:'1px solid #EFE8D9' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline' }}>
        <div style={{ fontSize:11, fontWeight:700, color:'#0F2A1E' }}>Nivel familiar <span style={{ color:'#E08E63' }}>{level}</span></div>
        <div style={{ fontSize:10, color:'#6F7A73', fontWeight:600 }}>{pct}% hacia nivel {level+1}</div>
      </div>
      <div style={{ marginTop:6, height:8, background:'#F6EFE3', borderRadius:4, overflow:'hidden', position:'relative' }}>
        <div style={{
          height:'100%', width:`${pct}%`,
          background:'linear-gradient(90deg, #6FE09A, #2CAE6E)',
          borderRadius:4, transformOrigin:'left', animation:'mf-grow-bar 1.2s .4s cubic-bezier(.2,.9,.2,1) both'
        }}/>
        {/* shimmer */}
        <div style={{ position:'absolute', inset:0, overflow:'hidden' }}>
          <div style={{ position:'absolute', top:0, bottom:0, width:'40%',
            background:'linear-gradient(90deg, transparent, rgba(255,255,255,0.6), transparent)',
            animation:'mf-shine 2.8s 1.5s ease-in-out infinite' }}/>
        </div>
      </div>
    </div>
  );
}

function V2Mascota() {
  return (
    <div className="screen" style={{ background: 'linear-gradient(180deg, #FAF4EA 0%, #F6EFE3 50%, #EAF5EE 100%)' }}>
      <StatusBar color="#0F2A1E" />

      {/* floating confetti/deco */}
      <div style={{ position:'absolute', top:80, left:28, fontSize:14, animation:'mf-float 4s ease-in-out infinite' }}>✦</div>
      <div style={{ position:'absolute', top:60, right:60, fontSize:10, color:'#E08E63', animation:'mf-sparkle 3s 1s ease-in-out infinite' }}>✦</div>

      {/* header */}
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'2px 22px 0' }}>
        <div>
          <div style={{ fontSize:12, color:'#6F7A73', fontWeight:500 }}>Buenas tardes,</div>
          <div style={{ fontSize:24, fontWeight:800, color:'#0F2A1E', letterSpacing:-0.5 }}>Mario 👋</div>
        </div>
        <div style={{ display:'flex', gap:8 }}>
          <CircleBtn><BellIcon/></CircleBtn>
          <CircleBtn><SlidersIcon/></CircleBtn>
        </div>
      </div>

      {/* mascot hero */}
      <div style={{
        margin:'4px 22px 0', background:'#FFFBF2', borderRadius:26, padding:'14px 18px',
        border:'1px solid #EFE8D9', position:'relative', overflow:'hidden',
        animation:'mf-rise .9s .1s ease both',
      }}>
        <div style={{ position:'absolute', inset:0, pointerEvents:'none', opacity:.4,
          background:'radial-gradient(circle at 20% 20%, #DDEFE3, transparent 50%)' }}/>

        <div style={{ display:'flex', alignItems:'center', gap:12, position:'relative' }}>
          <Mentu size={92}/>
          <div style={{ flex:1 }}>
            <div style={{ fontSize:11, fontWeight:700, color:'#2E7D5B', letterSpacing:1 }}>MENTU DICE</div>
            <div className="serif" style={{ fontSize:19, fontWeight:600, color:'#0F2A1E', lineHeight:1.2, letterSpacing:-0.3, marginTop:3 }}>
              ¡Vas genial hoy!
            </div>
            <div style={{ fontSize:12, color:'#6F7A73', marginTop:4, lineHeight:1.35 }}>
              Gastaste 23% menos que un martes normal. Seguí así.
            </div>
            <div style={{ marginTop:8 }}><StreakBadge days={14}/></div>
          </div>
        </div>
      </div>

      {/* disponible — compacto con destaque */}
      <div style={{ padding:'14px 22px 0', display:'flex', alignItems:'flex-end', justifyContent:'space-between',
        animation:'mf-rise .9s .2s ease both' }}>
        <div>
          <div style={{ fontSize:10, letterSpacing:1.6, fontWeight:700, color:'#2E7D5B' }}>DISPONIBLE HOY</div>
          <div className="serif" style={{ fontSize:40, fontWeight:700, color:'#0F2A1E', lineHeight:1, letterSpacing:-1.4, marginTop:4 }}>
            <CountUp to={4455000} duration={1400} prefix="$"/>
          </div>
          <div style={{ fontSize:12, color:'#6F7A73', marginTop:4 }}>
            Cobro en <b style={{ color:'#0F2A1E' }}>27 días</b> · margen <span style={{ color:'#2CAE6E', fontWeight:700 }}>+$2.535k</span>
          </div>
        </div>
        <button style={{
          border:'none', background:'#0F2A1E', color:'#FFFBF2',
          width:56, height:56, borderRadius:999, fontSize:24, fontWeight:700,
          cursor:'pointer', animation:'mf-pulse 2.2s ease-in-out 1.8s infinite',
        }}>+</button>
      </div>

      {/* level + achievements */}
      <div style={{ padding:'14px 22px 0', animation:'mf-rise .9s .25s ease both' }}>
        <LevelBar pct={72} level={4}/>
      </div>

      {/* achievements row */}
      <div style={{ padding:'10px 22px 0', display:'flex', gap:8, overflow:'hidden' }}>
        <AchievementChip icon="🎯" label="Meta 50%" delay={400} color="#F2B58A"/>
        <AchievementChip icon="💚" label="7 sin café" delay={480} color="#6FE09A"/>
        <AchievementChip icon="⭐" label="Nivel 4" delay={560} color="#F1D690" unlocked/>
        <AchievementChip icon="🔒" label="?" delay={640} color="#E9E1D3" locked/>
      </div>

      {/* meta mini */}
      <div style={{ margin:'12px 22px 0', background:'#0F2A1E', color:'#FFFBF2',
        borderRadius:20, padding:'14px 16px', animation:'mf-rise .9s .35s ease both',
        position:'relative', overflow:'hidden',
      }}>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
          <div>
            <div style={{ fontSize:10, letterSpacing:1.4, fontWeight:700, color:'#9EE5BA' }}>META · VIAJE A BARILOCHE</div>
            <div className="serif" style={{ fontSize:22, fontWeight:700, marginTop:2, letterSpacing:-0.5 }}>
              $1.920k <span style={{ color:'rgba(255,255,255,0.5)', fontSize:14, fontWeight:500 }}>/ $3.000k</span>
            </div>
          </div>
          <div style={{ fontSize:30, animation:'mf-float 3s ease-in-out infinite' }}>🏔️</div>
        </div>
        <div style={{ marginTop:10, height:8, background:'rgba(255,255,255,0.12)', borderRadius:4, overflow:'hidden', position:'relative' }}>
          <div style={{ height:'100%', width:'64%', background:'linear-gradient(90deg,#6FE09A,#F2B58A)', borderRadius:4,
            transformOrigin:'left', animation:'mf-grow-bar 1.3s .5s cubic-bezier(.2,.9,.2,1) both' }}/>
        </div>
        <div style={{ marginTop:8, display:'flex', justifyContent:'space-between', fontSize:11, color:'rgba(255,255,255,0.65)' }}>
          <span>64% alcanzado</span>
          <span>faltan ~3 meses</span>
        </div>
      </div>

      <TabBar accent="#6FE09A" bg="transparent"/>
    </div>
  );
}

function AchievementChip({ icon, label, color='#FADFC8', locked=false, unlocked=false, delay=0 }) {
  return (
    <div style={{
      background: locked ? '#F6EFE3' : '#FFFBF2',
      border:`1px solid ${locked?'#E9E1D3':'#EFE8D9'}`,
      borderRadius:999, padding:'6px 10px 6px 6px', display:'flex', alignItems:'center', gap:6,
      fontSize:11, fontWeight:700, color: locked?'#9AA39D':'#0F2A1E',
      animation:`mf-rise .6s ${delay}ms ease both`,
      position:'relative',
    }}>
      <div style={{
        width:20, height:20, borderRadius:999, background:color, display:'grid', placeItems:'center', fontSize:11,
        animation: unlocked ? 'mf-sparkle 2s ease-in-out infinite' : 'none',
      }}>{icon}</div>
      {label}
    </div>
  );
}

window.V2Mascota = V2Mascota;
