// Shared pieces used across all home variants.
// Keeps variant files focused on their unique layouts.

const { useState, useEffect, useRef, useMemo } = React;

// ─────────────────────────────────────────────────────────────
// Status bar — iOS-style, inherits foreground color
// ─────────────────────────────────────────────────────────────
function StatusBar({ color = '#0F2A1E', time = '14:20' }) {
  return (
    <div style={{
      height: 54, display:'flex', alignItems:'center', justifyContent:'space-between',
      padding: '0 28px', color, fontWeight: 600, fontSize: 17, letterSpacing: 0.2,
      fontFamily: 'SF Pro Text, system-ui',
      position:'relative', zIndex: 2,
    }}>
      <div style={{ display:'flex', gap:6, alignItems:'center' }}>
        {time}
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" style={{ marginLeft:2, opacity:.75 }}>
          <path d="M12 4c-3 0-5 2-5 5v4l-2 2v1h14v-1l-2-2V9c0-3-2-5-5-5z" stroke={color} strokeWidth="1.6" strokeLinejoin="round"/>
          <path d="M5 4l14 16" stroke={color} strokeWidth="1.6" strokeLinecap="round"/>
        </svg>
      </div>
      <div style={{ display:'flex', gap:6, alignItems:'center' }}>
        {/* signal */}
        <svg width="18" height="12" viewBox="0 0 18 12" fill={color}>
          <rect x="0"  y="8" width="3" height="4" rx="1"/>
          <rect x="5"  y="5" width="3" height="7" rx="1"/>
          <rect x="10" y="2" width="3" height="10" rx="1"/>
          <rect x="15" y="0" width="3" height="12" rx="1" opacity=".35"/>
        </svg>
        {/* wifi */}
        <svg width="16" height="12" viewBox="0 0 16 12" fill="none">
          <path d="M8 10.5a1 1 0 100-2 1 1 0 000 2z" fill={color}/>
          <path d="M3.5 6.5c2.5-2.5 6.5-2.5 9 0" stroke={color} strokeWidth="1.6" strokeLinecap="round"/>
          <path d="M1 3.5c4-4 10-4 14 0" stroke={color} strokeWidth="1.6" strokeLinecap="round"/>
        </svg>
        {/* battery */}
        <div style={{
          width:26, height:12, border:`1.4px solid ${color}`, borderRadius:4, position:'relative',
          display:'flex', alignItems:'center', padding:1.5,
        }}>
          <div style={{ background:color, width:'80%', height:'100%', borderRadius:2 }}/>
          <div style={{ position:'absolute', right:-3, top:3, width:2, height:6, background:color, borderRadius:1 }}/>
          <div style={{ position:'absolute', left:0, right:6, top:0, bottom:0, display:'flex', alignItems:'center', justifyContent:'center',
            fontSize:8, fontWeight:700, color: '#fff', mixBlendMode:'difference'
          }}>83</div>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Tab bar — reuses the exact structure of the original screen
// but lets each variant tint it.
// ─────────────────────────────────────────────────────────────
function TabBar({ bg = '#F6EFE3', active = 'inicio', accent = '#6FE09A', ink = '#0E1A14', onPlusClick }) {
  const item = (key, label, icon, lines) => {
    const on = key === active;
    return (
      <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:4, flex:1, opacity: on ? 1 : 0.55 }}>
        <div style={{ width:22, height:22, display:'grid', placeItems:'center', color: ink }}>{icon}</div>
        <div style={{ fontSize:11, fontWeight: on ? 700 : 500, color: ink, lineHeight:1.1, textAlign:'center' }}>
          {lines ? lines.map((l,i)=> <div key={i}>{l}</div>) : label}
        </div>
      </div>
    );
  };
  return (
    <div style={{
      position:'absolute', left:0, right:0, bottom:0, height: 96,
      background: bg, borderTop: `1px solid rgba(14,26,20,0.06)`,
      display:'flex', alignItems:'flex-start', justifyContent:'space-between',
      padding: '14px 18px 0', zIndex:10,
    }}>
      {item('inicio', 'Inicio',
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M3 11l9-7 9 7v9a2 2 0 01-2 2h-4v-6h-6v6H5a2 2 0 01-2-2v-9z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" fill={active==='inicio'?'currentColor':'none'} fillOpacity=".08"/></svg>
      )}
      {item('gastos', 'Gastos',
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><rect x="5" y="3" width="14" height="18" rx="2" stroke="currentColor" strokeWidth="1.8"/><path d="M8 8h8M8 12h8M8 16h5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg>
      )}
      <div style={{ width:64, display:'flex', justifyContent:'center' }}>
        <button onClick={onPlusClick} style={{
          width:56, height:56, borderRadius:999, background: accent, color:'#0F2A1E',
          display:'grid', placeItems:'center', fontSize:28, fontWeight:700, marginTop:-18,
          boxShadow: '0 10px 20px rgba(0,0,0,0.18), 0 0 0 4px rgba(255,255,255,0.9)',
          animation: 'mf-breathe 3.2s ease-in-out infinite',
          border:'none', cursor: onPlusClick ? 'pointer' : 'default', fontFamily:'inherit',
        }}>+</button>
      </div>
      {item('fijos', null,
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><rect x="3" y="5" width="18" height="15" rx="2" stroke="currentColor" strokeWidth="1.8"/><path d="M3 9h18M8 3v4M16 3v4" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg>,
        ['Gastos','Fijos']
      )}
      {item('control', 'Control',
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M3 17l5-6 4 3 7-8" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/><path d="M14 6h5v5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Counting number — animated on mount
// ─────────────────────────────────────────────────────────────
function CountUp({ to, duration = 1200, format = n => n.toLocaleString('es-AR'), prefix = '', style, delay = 0 }) {
  const [v, setV] = useState(0);
  useEffect(() => {
    let raf, start;
    const id = setTimeout(() => {
      const step = (t) => {
        if (!start) start = t;
        const p = Math.min(1, (t - start) / duration);
        const e = 1 - Math.pow(1 - p, 3); // easeOutCubic
        setV(Math.round(to * e));
        if (p < 1) raf = requestAnimationFrame(step);
      };
      raf = requestAnimationFrame(step);
    }, delay);
    return () => { clearTimeout(id); cancelAnimationFrame(raf); };
  }, [to, duration, delay]);
  return <span style={style}>{prefix}{format(v)}</span>;
}

// ─────────────────────────────────────────────────────────────
// Avatar — initials with warm gradient background
// ─────────────────────────────────────────────────────────────
function Avatar({ name = 'M', color = '#E08E63', size = 28, ring = false, ringColor }) {
  const initials = name.split(' ').map(s => s[0]).slice(0,2).join('').toUpperCase();
  return (
    <div style={{
      width:size, height:size, borderRadius:999,
      background: `linear-gradient(140deg, ${color}, ${shade(color, -15)})`,
      color:'#fff', display:'grid', placeItems:'center',
      fontWeight:700, fontSize: size*0.42, letterSpacing: 0.2,
      boxShadow: ring ? `0 0 0 2px ${ringColor || '#fff'}` : 'none',
      flexShrink:0,
    }}>{initials}</div>
  );
}
function shade(hex, pct) {
  const c = hex.replace('#','');
  const num = parseInt(c, 16);
  let r = (num >> 16) + Math.round(2.55*pct);
  let g = ((num >> 8) & 0xff) + Math.round(2.55*pct);
  let b = (num & 0xff) + Math.round(2.55*pct);
  r = Math.max(0,Math.min(255,r));
  g = Math.max(0,Math.min(255,g));
  b = Math.max(0,Math.min(255,b));
  return '#' + (r*65536 + g*256 + b).toString(16).padStart(6,'0');
}

// ─────────────────────────────────────────────────────────────
// Money formatter
// ─────────────────────────────────────────────────────────────
const fmtMoney = (n, opts={}) => {
  const s = Math.abs(n).toLocaleString('es-AR');
  return (opts.sign && n>0 ? '+' : n<0 ? '-' : '') + '$' + s;
};

// Fake family members
const FAMILY = [
  { name: 'Mario',    color: '#2E7D5B' },
  { name: 'Lucía',    color: '#E08E63' },
  { name: 'Tomás',    color: '#6B3A4F' },
  { name: 'Sofía',    color: '#C9A23A' },
];

Object.assign(window, { StatusBar, TabBar, CountUp, Avatar, fmtMoney, FAMILY, shade });
