// Control screen — "asesor financiero integrado"
// Metáfora: el día es un presupuesto. Lo no gastado se acumula en el VAULT.
// Orden narrativo:
//   1. Hero del día (cupo, gastado, libre) con anillo horario
//   2. Vault de días ahorrados (racha de small wins)
//   3. Proyección mañana (si controlás hoy, arrancás con X)
//   4. Ritmo semanal (7 días, glyph luz/peso)
//   5. Asesor — 2-3 tareas accionables hoy

const { useState: useStateCt, useEffect: useEffectCt, useMemo: useMemoCt, useRef: useRefCt } = React;

// ─────────────────────────────────────────────────────────────
// Datos mock (coherentes con Gastos/Fijos)
// sueldo 2.2M, fijos 1.25M → libre 950k / 30 = 31.6k por día
// llevamos 22 días, hoy es día 22, hora 14:20
// ─────────────────────────────────────────────────────────────
const CONTROL_DATA = {
  cupoDiario: 31600,
  diaActual: 22,
  diasMes: 30,
  horaActual: 14,          // 14:20 → 14 + 20/60
  minActual: 20,
  gastoHoy: 12400,         // 3.200 café + 8.000 SUBE + 1.200 otros
  gastoHoyByCat: [
    { cat:'oci', amount: 3200 },
    { cat:'tra', amount: 8000 },
    { cat:'otr', amount: 1200 },
  ],
  // los 21 días previos: cuánto gastaron vs cupo (histórico)
  dias: [
    // valores en ARS
    26400, 30900, 15000, 42100, 28400, 31500, 18900, // semana 1
    22400, 29800, 35600, 14000, 27800, 31200, 19500, // semana 2
    24300, 33900, 41200, 28100, 22700, 37400, 29800, // semana 3
    // día 22 (hoy) in-progress = gastoHoy, no se cuenta aún
  ],
  // tareas del asesor
  tareas: [
    {
      id:'t1', type:'recortar', cat:'oci', emoji:'🎬',
      title:'Recortá Ocio esta semana',
      body:'Llevás $28.400 en ocio. Te pusiste $20.000 como techo.',
      impact:'+$8.400 al vault',
      cta:'Ver ocio',
      urgency:'media',
    },
    {
      id:'t2', type:'zombi', cat:'sus', emoji:'🧟',
      title:'Disney+ sin uso en 60 días',
      body:'Pagás $4.200/mes. Si lo pausás ahora, ahorrás $50.400/año.',
      impact:'+$4.200/mes',
      cta:'Pausar',
      urgency:'alta',
    },
    {
      id:'t3', type:'optimizar', cat:'ser', emoji:'⚡',
      title:'Luz subió 14%',
      body:'Edenor pasó de $28k a $32.5k. Podrías cambiar de plan.',
      impact:'−$3.200/mes',
      cta:'Comparar',
      urgency:'baja',
    },
  ],
};

// Derived
function summarizeControl(d) {
  const libreHoy = d.cupoDiario - d.gastoHoy;
  // Cuánto hora-proporcional deberías llevar gastado si gastaras uniforme
  const horaF = d.horaActual + d.minActual/60;
  const cupoHastaAhora = (horaF / 24) * d.cupoDiario;
  const estadoHoy = d.gastoHoy <= cupoHastaAhora ? 'adelante' : 'atrasado';
  const delta = cupoHastaAhora - d.gastoHoy; // positivo = vas ganando
  // Vault acumulado: sumatoria de (cupo - gastoDía) de días previos, cap a 0 abajo
  // para que sea un número motivador: sumamos solo los días "ganadores"
  const detalleDias = d.dias.map((g, i) => ({ dia: i+1, gasto: g, delta: d.cupoDiario - g }));
  const vault = detalleDias.reduce((s, x) => s + Math.max(0, x.delta), 0);
  const vaultNeto = detalleDias.reduce((s, x) => s + x.delta, 0);
  // racha: últimos N días consecutivos por debajo del cupo
  let racha = 0;
  for (let i = detalleDias.length - 1; i >= 0; i--) {
    if (detalleDias[i].gasto <= d.cupoDiario) racha++;
    else break;
  }
  // proyección mañana: si cerrás hoy con gastoMínimo (= solo lo gastado hasta ahora), vault + libre
  const manana = vault + Math.max(0, libreHoy);
  // semanal: últimos 7 días (incluyendo hoy como in-progress)
  const last7 = detalleDias.slice(-6);
  last7.push({ dia: d.diaActual, gasto: d.gastoHoy, delta: d.cupoDiario - d.gastoHoy, inProgress: true });
  // promedio diario del mes hasta ayer
  const promedio = detalleDias.reduce((s,x)=>s+x.gasto, 0) / detalleDias.length;
  // mejor día, peor día
  const mejor = detalleDias.reduce((a,b)=>b.gasto < a.gasto ? b : a);
  const peor  = detalleDias.reduce((a,b)=>b.gasto > a.gasto ? b : a);
  return { libreHoy, cupoHastaAhora, estadoHoy, delta, vault, vaultNeto, racha, manana, last7, promedio, mejor, peor, horaF };
}

// ─────────────────────────────────────────────────────────────
// CONTROL · LIGHT
// ─────────────────────────────────────────────────────────────
function ControlLight() {
  const D = CONTROL_DATA;
  const S = useMemoCt(() => summarizeControl(D), []);
  return (
    <div className="screen" style={{ background:'#EFF5E8', overflowY:'auto' }}>
      <StatusBar color="#0F2A1E"/>

      {/* ambient */}
      <div style={{ position:'absolute', top:-60, right:-60, width:240, height:240, borderRadius:'50%',
        background:'radial-gradient(closest-side, rgba(141,214,106,0.22), transparent 70%)',
        pointerEvents:'none', animation:'mf-float-slow 10s ease-in-out infinite' }}/>
      <div style={{ position:'absolute', top:720, left:-80, width:240, height:240, borderRadius:'50%',
        background:'radial-gradient(closest-side, rgba(242,181,138,0.14), transparent 70%)',
        pointerEvents:'none', animation:'mf-float-slow 14s ease-in-out infinite', animationDelay:'-4s' }}/>

      {/* header */}
      <div style={{ padding:'2px 22px 0', display:'flex', alignItems:'flex-start', justifyContent:'space-between',
        animation:'mf-rise .6s ease both' }}>
        <div>
          <div className="sf-display" style={{ fontSize:34, fontWeight:800, color:'#0F2A1E', letterSpacing:-1.2, lineHeight:1 }}>
            Control
          </div>
          <div style={{ fontSize:13, color:'#6F7A73', marginTop:6, maxWidth:280 }}>
            Tu asesor financiero, un día a la vez.
          </div>
        </div>
        <div style={{ display:'flex', alignItems:'center', gap:4, padding:'4px 10px',
          background:'#FFFBF2', border:'1px solid #EFE8D9', borderRadius:999,
          fontSize:11, fontWeight:700, color:'#0F2A1E' }}>
          <span style={{ fontSize:13 }}>🔥</span> {S.racha}
        </div>
      </div>

      {/* 1 · HERO diario */}
      <HeroDiaLt D={D} S={S}/>

      {/* 2 · VAULT */}
      <VaultLt D={D} S={S}/>

      {/* 3 · PROYECCIÓN MAÑANA */}
      <ProyeccionLt D={D} S={S}/>

      {/* 4 · RITMO SEMANAL */}
      <RitmoSemanalLt D={D} S={S}/>

      {/* 5 · ASESOR */}
      <AsesorLt D={D} S={S}/>

      <div style={{ height:120 }}/>
      <TabBar active="control" accent="#8DD66A" bg="#EFF5E8"/>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// HERO del día — anillo horario + cupo/gastado/libre
// Innovación: el anillo tiene TRES pistas concéntricas.
//   1. anillo horario exterior (líneas cada 1h → muestra dónde en el día estás)
//   2. anillo "gastado" (naranja) — proporción del cupo usado
//   3. anillo "debería" (línea punteada) — proporción esperada a esta hora
// si el relleno de "gastado" está dentro de "debería" → estás OK
// ─────────────────────────────────────────────────────────────
function HeroDiaLt({ D, S }) {
  const R = 90;
  const C = 2 * Math.PI * R;
  const gastoPct = Math.min(1, D.gastoHoy / D.cupoDiario);
  const horaPct = S.horaF / 24;
  const cupoExpPct = horaPct; // esperado a esta hora
  const estaOk = S.delta >= 0;

  return (
    <div style={{ margin:'16px 22px 0',
      background:'linear-gradient(135deg, #0F2A1E 0%, #143B2A 100%)',
      borderRadius:28, padding:'22px 20px 20px', color:'#F6FBEF',
      position:'relative', overflow:'hidden',
      boxShadow:'0 18px 40px -16px rgba(15,42,30,0.5)',
      animation:'mf-rise .8s .1s ease both' }}>

      {/* glows */}
      <div style={{ position:'absolute', top:-40, right:-40, width:220, height:220, borderRadius:'50%',
        background:`radial-gradient(closest-side, ${estaOk?'rgba(199,238,156,0.22)':'rgba(242,181,138,0.22)'}, transparent 70%)` }}/>

      {/* top meta */}
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', position:'relative' }}>
        <div style={{ fontSize:11, letterSpacing:1.6, fontWeight:700, color:'#C7EE9C' }}>HOY · MARTES 22</div>
        <div style={{ fontSize:10, fontWeight:700, color:'rgba(246,251,239,0.7)',
          padding:'3px 10px', borderRadius:999,
          background:`rgba(${estaOk?'199,238,156':'242,181,138'},0.15)`,
          border:`1px solid rgba(${estaOk?'199,238,156':'242,181,138'},0.35)`,
        }}>
          {estaOk ? '●' : '○'} {estaOk ? 'EN RITMO' : 'ATRASADO'}
        </div>
      </div>

      {/* ring + center */}
      <div style={{ display:'flex', alignItems:'center', gap:14, marginTop:14, position:'relative' }}>
        <div style={{ width:210, height:210, position:'relative', flexShrink:0 }}>
          <svg width="210" height="210" viewBox="0 0 210 210">
            <defs>
              <linearGradient id="ct-ring-spent-lt" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor={estaOk?'#C7EE9C':'#F2B58A'}/>
                <stop offset="100%" stopColor={estaOk?'#6FE09A':'#E8976A'}/>
              </linearGradient>
            </defs>
            {/* anillo horario exterior — 24 ticks */}
            {Array.from({length: 24}).map((_, i) => {
              const angle = (i / 24) * 2 * Math.PI - Math.PI/2;
              const r1 = 104, r2 = (i % 6 === 0) ? 98 : 101;
              const x1 = 105 + r1 * Math.cos(angle), y1 = 105 + r1 * Math.sin(angle);
              const x2 = 105 + r2 * Math.cos(angle), y2 = 105 + r2 * Math.sin(angle);
              return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2}
                stroke={i === Math.floor(S.horaF) ? '#C7EE9C' : 'rgba(246,251,239,0.25)'}
                strokeWidth={i === Math.floor(S.horaF) ? 2 : 1} strokeLinecap="round"/>;
            })}
            {/* aguja hora actual */}
            <g transform={`rotate(${horaPct * 360 - 90} 105 105)`}>
              <circle cx="200" cy="105" r="3.5" fill="#C7EE9C"
                style={{ animation:'mf-breathe 2.4s ease-in-out infinite', transformOrigin:'200px 105px' }}/>
            </g>

            {/* anillo base */}
            <circle cx="105" cy="105" r={R} fill="none" stroke="rgba(246,251,239,0.08)" strokeWidth="16"/>
            {/* "deberías" — punteado, referencia hora */}
            <circle cx="105" cy="105" r={R} fill="none"
              stroke="rgba(246,251,239,0.35)" strokeWidth="1.5"
              strokeDasharray="4 6"
              style={{ transform:'rotate(-90deg)', transformOrigin:'105px 105px' }}
              pathLength="1"
              strokeDashoffset={0}/>
            {/* arc "gastado" */}
            <g transform="rotate(-90 105 105)">
              <circle cx="105" cy="105" r={R} fill="none" stroke="url(#ct-ring-spent-lt)"
                strokeWidth="16" strokeLinecap="round"
                strokeDasharray={`${C * gastoPct} ${C}`}
                style={{ animation:'mf-fj-ring-paid 1.4s .3s cubic-bezier(.2,.9,.2,1) both',
                  filter:`drop-shadow(0 0 8px ${estaOk?'rgba(199,238,156,0.4)':'rgba(242,181,138,0.4)'})` }}/>
            </g>
            {/* marcador "debería llevar" en la circunferencia */}
            <g transform="rotate(-90 105 105)">
              <circle
                cx={105 + R * Math.cos((cupoExpPct) * 2 * Math.PI)}
                cy={105 + R * Math.sin((cupoExpPct) * 2 * Math.PI)}
                r="5" fill="#F6FBEF" stroke="#0F2A1E" strokeWidth="2"
                style={{ animation:'mf-breathe 2s ease-in-out infinite' }}/>
            </g>
          </svg>

          {/* center stack */}
          <div style={{ position:'absolute', inset:0, display:'flex', flexDirection:'column',
            alignItems:'center', justifyContent:'center', textAlign:'center' }}>
            <div style={{ fontSize:9, letterSpacing:1.4, fontWeight:700, color:'rgba(246,251,239,0.6)' }}>
              PODÉS GASTAR HOY
            </div>
            <div className="sf-display" style={{ fontSize:28, fontWeight:800, color:'#F6FBEF',
              letterSpacing:-1, lineHeight:1, marginTop:3,
              textShadow:'0 0 16px rgba(199,238,156,0.25)' }}>
              $<CountUp to={Math.max(0, S.libreHoy)} duration={1200}/>
            </div>
            <div style={{ marginTop:4, fontSize:10, color:'rgba(246,251,239,0.55)', fontWeight:600 }}>
              de $<CountUp to={D.cupoDiario} duration={1200}/>
            </div>
            <div style={{ marginTop:6, padding:'3px 10px', borderRadius:999,
              background: estaOk ? 'rgba(199,238,156,0.15)' : 'rgba(242,181,138,0.18)',
              border: `1px solid ${estaOk?'rgba(199,238,156,0.35)':'rgba(242,181,138,0.35)'}`,
              fontSize:10, fontWeight:700, color: estaOk?'#C7EE9C':'#F2B58A' }}>
              {estaOk ? `↑ ${((S.delta/D.cupoDiario)*100).toFixed(0)}% adelantado` : `↓ ${Math.abs((S.delta/D.cupoDiario)*100).toFixed(0)}% atrasado`}
            </div>
          </div>
        </div>

        {/* lado der — ritmo del día */}
        <div style={{ flex:1, display:'flex', flexDirection:'column', gap:8 }}>
          <div style={{ padding:'10px 12px', borderRadius:12,
            background:'rgba(246,251,239,0.05)', border:'1px solid rgba(246,251,239,0.08)' }}>
            <div style={{ fontSize:9, letterSpacing:1.4, fontWeight:700, color:'rgba(246,251,239,0.55)' }}>
              LLEVÁS GASTADO
            </div>
            <div className="sf-display" style={{ fontSize:18, fontWeight:800, color:'#F6FBEF', letterSpacing:-0.5, marginTop:2 }}>
              ${D.gastoHoy.toLocaleString('es-AR')}
            </div>
            <div style={{ fontSize:10, color:'rgba(246,251,239,0.5)', marginTop:1 }}>
              en {D.gastoHoyByCat.length} gastos
            </div>
          </div>

          <div style={{ padding:'10px 12px', borderRadius:12,
            background: estaOk ? 'linear-gradient(135deg, rgba(199,238,156,0.14), rgba(141,214,106,0.04))'
                               : 'linear-gradient(135deg, rgba(242,181,138,0.14), rgba(232,151,106,0.04))',
            border: `1px solid ${estaOk?'rgba(199,238,156,0.25)':'rgba(242,181,138,0.25)'}` }}>
            <div style={{ fontSize:9, letterSpacing:1.4, fontWeight:700, color:'rgba(246,251,239,0.55)' }}>
              DEBERÍAS LLEVAR
            </div>
            <div className="sf-display" style={{ fontSize:18, fontWeight:800, color:'#F6FBEF', letterSpacing:-0.5, marginTop:2 }}>
              ${Math.round(S.cupoHastaAhora).toLocaleString('es-AR')}
            </div>
            <div style={{ fontSize:10, color: estaOk?'#C7EE9C':'#F2B58A', fontWeight:700, marginTop:1 }}>
              {estaOk ? `te sobran $${Math.round(S.delta).toLocaleString('es-AR')}` : `te pasaste $${Math.abs(Math.round(S.delta)).toLocaleString('es-AR')}`}
            </div>
          </div>
        </div>
      </div>

      {/* bottom: barra hora actual */}
      <div style={{ marginTop:14, padding:'10px 12px', borderRadius:12,
        background:'rgba(246,251,239,0.05)', border:'1px solid rgba(246,251,239,0.08)',
        display:'flex', alignItems:'center', gap:10 }}>
        <div style={{ fontSize:11, fontWeight:700, color:'#C7EE9C' }}>⏱ {D.horaActual}:{String(D.minActual).padStart(2,'0')}</div>
        <div style={{ flex:1, height:6, borderRadius:3, background:'rgba(246,251,239,0.1)',
          overflow:'hidden', position:'relative' }}>
          {/* área "transcurrida" */}
          <div style={{ position:'absolute', inset:0, width:`${horaPct*100}%`,
            background:'linear-gradient(90deg, rgba(199,238,156,0.3), rgba(199,238,156,0.1))',
            animation:'mf-grow-bar 1s .6s ease both', transformOrigin:'left' }}/>
          {/* marcador gastado actual */}
          <div style={{ position:'absolute', top:-2, height:10, width:2,
            left:`${gastoPct*100}%`, background:'#F2B58A', borderRadius:2, boxShadow:'0 0 6px #F2B58A' }}/>
          {/* marcador "debería" */}
          <div style={{ position:'absolute', top:-2, height:10, width:2,
            left:`${cupoExpPct*100}%`, background:'#F6FBEF', opacity:0.5, borderRadius:2 }}/>
        </div>
        <div style={{ fontSize:10, fontWeight:700, color:'rgba(246,251,239,0.55)' }}>23:59</div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// VAULT — días ganados acumulados
// Metáfora: alcancía editorial con hoja + monedas apiladas (SVG simple)
// ─────────────────────────────────────────────────────────────
function VaultLt({ D, S }) {
  const diasGanadores = D.dias.filter(g => g <= D.cupoDiario).length;
  const diasPerdedores = D.dias.length - diasGanadores;
  return (
    <div style={{ margin:'16px 22px 0',
      background:'#FFFBF2', border:'1px solid #EFE8D9', borderRadius:24,
      padding:'18px 20px', position:'relative', overflow:'hidden',
      animation:'mf-rise .8s .2s ease both' }}>
      <div style={{ fontSize:10, letterSpacing:1.6, fontWeight:700, color:'#6F7A73' }}>
        VAULT · lo que ganaste este mes
      </div>

      <div style={{ display:'flex', alignItems:'flex-end', gap:16, marginTop:6 }}>
        <div style={{ flex:1 }}>
          <div className="sf-display" style={{ fontSize:38, fontWeight:800, color:'#0F2A1E',
            letterSpacing:-1.4, lineHeight:1 }}>
            +$<CountUp to={S.vault} duration={1400}/>
          </div>
          <div style={{ fontSize:12, color:'#2E7D5B', fontWeight:700, marginTop:4 }}>
            en {diasGanadores} día{diasGanadores!==1?'s':''} bajo el cupo
          </div>
          <div style={{ fontSize:11, color:'#6F7A73', marginTop:2 }}>
            promedio diario ${Math.round(S.promedio).toLocaleString('es-AR')} · cupo ${D.cupoDiario.toLocaleString('es-AR')}
          </div>
        </div>

        {/* alcancía-hoja SVG */}
        <VaultGlyph value={S.vault} color="#2E7D5B"/>
      </div>

      {/* mini stats horizontal */}
      <div style={{ marginTop:14, display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:8 }}>
        <MiniStatLt label="RACHA" value={`${S.racha}d`} emoji="🔥" tint="#E8976A"/>
        <MiniStatLt label="MEJOR" value={`$${(S.mejor.gasto/1000).toFixed(0)}k`} sub={`día ${S.mejor.dia}`} tint="#2E7D5B" emoji="⭐"/>
        <MiniStatLt label="PEOR" value={`$${(S.peor.gasto/1000).toFixed(0)}k`} sub={`día ${S.peor.dia}`} tint="#C03A2A" emoji="⚠"/>
      </div>

      {/* barra balanced wins vs losses */}
      <div style={{ marginTop:12 }}>
        <div style={{ display:'flex', justifyContent:'space-between', fontSize:10, fontWeight:700, letterSpacing:1.2 }}>
          <span style={{ color:'#2E7D5B' }}>{diasGanadores} BAJO CUPO</span>
          <span style={{ color:'#C03A2A' }}>{diasPerdedores} PASADO</span>
        </div>
        <div style={{ marginTop:6, height:8, borderRadius:4, background:'#EFE8D9', overflow:'hidden', display:'flex' }}>
          <div style={{ width:`${(diasGanadores/D.dias.length)*100}%`,
            background:'linear-gradient(90deg, #8DD66A, #2E7D5B)',
            animation:'mf-grow-bar 1s .5s cubic-bezier(.2,.9,.2,1) both', transformOrigin:'left' }}/>
          <div style={{ width:`${(diasPerdedores/D.dias.length)*100}%`,
            background:'linear-gradient(90deg, #E8976A, #D96A4F)',
            animation:'mf-grow-bar 1s .7s cubic-bezier(.2,.9,.2,1) both', transformOrigin:'left' }}/>
        </div>
      </div>
    </div>
  );
}

function VaultGlyph({ value, color='#2E7D5B' }) {
  // alcancía simple estilo editorial
  return (
    <svg width="92" height="80" viewBox="0 0 92 80" style={{ animation:'mf-bob 4s ease-in-out infinite' }}>
      <defs>
        <linearGradient id="vault-coin-lt" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#F2B58A"/><stop offset="100%" stopColor="#E8976A"/>
        </linearGradient>
      </defs>
      {/* stacked coins */}
      {[2,1,0].map(i => (
        <g key={i} transform={`translate(0 ${i*6})`}>
          <ellipse cx="22" cy={56 - i*4} rx="16" ry="5" fill="url(#vault-coin-lt)" opacity={0.85 - i*0.1}/>
          <ellipse cx="22" cy={56 - i*4} rx="16" ry="5" fill="none" stroke="#D57B4F" strokeWidth="0.8"/>
        </g>
      ))}
      {/* leaf/piggy shape */}
      <path d="M46 60 C 46 36, 62 24, 78 34 C 86 40, 88 56, 76 64 C 64 72, 50 70, 46 60 Z"
        fill={color} opacity="0.9"/>
      <path d="M46 60 C 46 36, 62 24, 78 34 C 86 40, 88 56, 76 64 C 64 72, 50 70, 46 60 Z"
        fill="none" stroke="#0F2A1E" strokeWidth="1.5"/>
      {/* slot */}
      <rect x="60" y="30" width="14" height="3" rx="1.5" fill="#0F2A1E"/>
      {/* eye */}
      <circle cx="72" cy="46" r="1.5" fill="#0F2A1E"/>
      {/* glint */}
      <circle cx="68" cy="40" r="3" fill="#F6FBEF" opacity="0.25"/>
    </svg>
  );
}

function MiniStatLt({ label, value, sub, emoji, tint }) {
  return (
    <div style={{ padding:'10px 10px', background:'#F6F1E4', borderRadius:12,
      border:'1px solid #EFE8D9' }}>
      <div style={{ display:'flex', alignItems:'center', gap:4 }}>
        <span style={{ fontSize:11 }}>{emoji}</span>
        <span style={{ fontSize:9, letterSpacing:1.2, fontWeight:700, color:'#9AA39D' }}>{label}</span>
      </div>
      <div style={{ fontSize:15, fontWeight:800, color: tint || '#0F2A1E', marginTop:2, letterSpacing:-0.3 }}>
        {value}
      </div>
      {sub && <div style={{ fontSize:10, color:'#9AA39D', marginTop:1 }}>{sub}</div>}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// PROYECCIÓN MAÑANA — si controlás hoy, mañana arrancás con X
// Visual: "flecha del tiempo" — hoy → mañana con delta
// ─────────────────────────────────────────────────────────────
function ProyeccionLt({ D, S }) {
  const libreEscenarioA = Math.max(0, S.libreHoy); // escenario ideal: no gastás más hoy
  const escenarioB = Math.max(0, S.libreHoy - 8000); // escenario moderado
  const mananaOptimo = S.vault + libreEscenarioA;
  const mananaMod = S.vault + escenarioB;

  return (
    <div style={{ margin:'16px 22px 0', animation:'mf-rise .8s .3s ease both' }}>
      <div style={{ fontSize:10, letterSpacing:1.6, fontWeight:700, color:'#6F7A73', marginBottom:8 }}>
        MIRANDO A MAÑANA
      </div>

      <div style={{
        background:'linear-gradient(135deg, #C7EE9C22 0%, #8DD66A11 100%)',
        border:'1px solid #C7EE9C66', borderRadius:20, padding:'16px 18px',
        position:'relative', overflow:'hidden',
      }}>
        {/* decoración flecha */}
        <svg width="100%" height="40" viewBox="0 0 320 40" preserveAspectRatio="none"
          style={{ position:'absolute', top:16, left:0, right:0, opacity:0.3, pointerEvents:'none' }}>
          <path d="M10 20 Q 160 5 310 20" stroke="#2E7D5B" strokeWidth="1.5"
            strokeDasharray="4 4" fill="none"/>
        </svg>

        <div style={{ display:'flex', alignItems:'stretch', gap:12, position:'relative' }}>
          {/* columna HOY */}
          <div style={{ flex:1, padding:'10px 12px', background:'#FFFBF2',
            borderRadius:14, border:'1px solid #EFE8D9' }}>
            <div style={{ fontSize:9, letterSpacing:1.2, fontWeight:700, color:'#9AA39D' }}>SI HOY</div>
            <div style={{ fontSize:14, fontWeight:700, color:'#0F2A1E', marginTop:4 }}>
              No gastás más
            </div>
            <div style={{ fontSize:11, color:'#6F7A73', marginTop:1 }}>
              cerrás con <b style={{ color:'#2E7D5B' }}>+${libreEscenarioA.toLocaleString('es-AR')}</b>
            </div>
          </div>

          {/* flecha + delta */}
          <div style={{ width:40, display:'flex', flexDirection:'column',
            alignItems:'center', justifyContent:'center' }}>
            <svg width="28" height="20" viewBox="0 0 28 20">
              <path d="M2 10 L22 10 M16 4 L22 10 L16 16" stroke="#2E7D5B" strokeWidth="2"
                strokeLinecap="round" strokeLinejoin="round" fill="none"/>
            </svg>
          </div>

          {/* columna MAÑANA */}
          <div style={{ flex:1.2, padding:'10px 12px', borderRadius:14,
            background:'linear-gradient(135deg, #0F2A1E, #143B2A)', color:'#F6FBEF' }}>
            <div style={{ fontSize:9, letterSpacing:1.2, fontWeight:700, color:'rgba(199,238,156,0.85)' }}>
              MAÑANA ARRANCÁS CON
            </div>
            <div className="sf-display" style={{ fontSize:22, fontWeight:800, color:'#F6FBEF',
              letterSpacing:-0.8, marginTop:4, lineHeight:1 }}>
              ${mananaOptimo.toLocaleString('es-AR')}
            </div>
            <div style={{ fontSize:10, color:'#C7EE9C', fontWeight:700, marginTop:3 }}>
              vault nuevo
            </div>
          </div>
        </div>

        {/* escenarios comparados (barras) */}
        <div style={{ marginTop:12, padding:'10px 12px', background:'#FFFBF2', borderRadius:12,
          border:'1px dashed #D9D2C4' }}>
          <div style={{ fontSize:9, letterSpacing:1.2, fontWeight:700, color:'#9AA39D', marginBottom:6 }}>
            SEGÚN QUÉ HAGAS HOY
          </div>
          <ProyRow label="Ideal (no gastás más)" value={mananaOptimo} color="#2E7D5B" max={mananaOptimo}/>
          <ProyRow label="Moderado (un café extra)" value={mananaMod} color="#E8976A" max={mananaOptimo}/>
          <ProyRow label="Sin control" value={S.vault} color="#D96A4F" max={mananaOptimo}/>
        </div>
      </div>
    </div>
  );
}

function ProyRow({ label, value, color, max }) {
  const pct = (value / max) * 100;
  return (
    <div style={{ marginTop:6 }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', fontSize:11 }}>
        <span style={{ color:'#0F2A1E', fontWeight:600 }}>{label}</span>
        <span style={{ color, fontWeight:800, letterSpacing:-0.3, fontSize:13,
          fontFamily:'SF Pro Display, system-ui' }}>${value.toLocaleString('es-AR')}</span>
      </div>
      <div style={{ marginTop:3, height:6, borderRadius:3, background:'#EFE8D9', overflow:'hidden' }}>
        <div style={{ width:`${pct}%`, height:'100%', background:color, borderRadius:3,
          animation:'mf-grow-bar .9s .4s cubic-bezier(.2,.9,.2,1) both', transformOrigin:'left' }}/>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// RITMO SEMANAL — 7 glyphs
// Cada día = columna vertical; peso relativo al cupo.
// Color: verde si <=cupo, naranja si >cupo, azul/gris si hoy (in-progress)
// ─────────────────────────────────────────────────────────────
function RitmoSemanalLt({ D, S }) {
  const dayLabels = ['L','M','M','J','V','S','D'];
  // map cupo-relative: gasto/cupo, cap at 1.8
  const items = S.last7;
  const maxDisplay = Math.max(D.cupoDiario * 1.4, ...items.map(i => i.gasto));
  const todayIdx = items.findIndex(i => i.inProgress);

  return (
    <div style={{ margin:'16px 22px 0', animation:'mf-rise .8s .4s ease both' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', marginBottom:8 }}>
        <div style={{ fontSize:10, letterSpacing:1.6, fontWeight:700, color:'#6F7A73' }}>
          RITMO SEMANAL
        </div>
        <div style={{ fontSize:11, color:'#6F7A73', fontWeight:600 }}>
          últimos 7 días
        </div>
      </div>
      <div style={{
        background:'#FFFBF2', border:'1px solid #EFE8D9', borderRadius:20,
        padding:'16px 18px 14px',
      }}>
        {/* bars */}
        <div style={{ display:'grid', gridTemplateColumns:`repeat(${items.length}, 1fr)`, gap:8,
          alignItems:'flex-end', height:120, position:'relative' }}>
          {/* cupo line */}
          <div style={{ position:'absolute', left:0, right:0,
            bottom: `${(D.cupoDiario/maxDisplay)*100}%`,
            height:1, background:'#D9D2C4', zIndex:1, pointerEvents:'none' }}>
            <span style={{ position:'absolute', right:0, top:-14, fontSize:9, fontWeight:700,
              color:'#9AA39D', background:'#FFFBF2', padding:'0 4px' }}>CUPO</span>
          </div>
          {items.map((d, i) => {
            const pct = Math.min(1, d.gasto / maxDisplay);
            const over = d.gasto > D.cupoDiario && !d.inProgress;
            const color = d.inProgress ? '#6B9AD6' : over ? '#D96A4F' : '#2E7D5B';
            const gradient = d.inProgress
              ? 'linear-gradient(180deg, #8FB8E0, #6B9AD6)'
              : over
              ? 'linear-gradient(180deg, #E88A70, #C03A2A)'
              : 'linear-gradient(180deg, #8DD66A, #2E7D5B)';
            return (
              <div key={i} style={{ position:'relative', height:'100%',
                display:'flex', flexDirection:'column', justifyContent:'flex-end', zIndex:2 }}>
                <div title={`Día ${d.dia}: $${d.gasto.toLocaleString('es-AR')}`}
                  style={{
                    width:'100%', height:`${pct*100}%`, borderRadius:'6px 6px 2px 2px',
                    background: gradient,
                    animation: `mf-grow-vert .7s ${0.4 + i*0.06}s cubic-bezier(.2,.9,.2,1) both`,
                    transformOrigin:'bottom',
                    boxShadow: d.inProgress ? '0 0 12px rgba(107,154,214,0.5)' : 'none',
                    position:'relative',
                  }}>
                  {d.inProgress && (
                    <div style={{ position:'absolute', inset:0,
                      background:'repeating-linear-gradient(45deg, transparent 0 6px, rgba(246,251,239,0.2) 6px 8px)',
                      borderRadius:'inherit' }}/>
                  )}
                </div>
              </div>
            );
          })}
        </div>
        {/* x axis */}
        <div style={{ marginTop:6, display:'grid', gridTemplateColumns:`repeat(${items.length}, 1fr)`, gap:8 }}>
          {items.map((d, i) => {
            const isToday = d.inProgress;
            return (
              <div key={i} style={{ textAlign:'center' }}>
                <div style={{ fontSize:10, fontWeight: isToday ? 800 : 600,
                  color: isToday ? '#0F2A1E' : '#9AA39D' }}>{d.dia}</div>
              </div>
            );
          })}
        </div>

        {/* legend */}
        <div style={{ marginTop:12, display:'flex', gap:10, fontSize:10, color:'#6F7A73',
          fontWeight:600, alignItems:'center', flexWrap:'wrap' }}>
          <span style={{ display:'flex', alignItems:'center', gap:4 }}>
            <span style={{ width:8, height:8, borderRadius:4, background:'#2E7D5B' }}/> bajo cupo
          </span>
          <span style={{ display:'flex', alignItems:'center', gap:4 }}>
            <span style={{ width:8, height:8, borderRadius:4, background:'#D96A4F' }}/> pasado
          </span>
          <span style={{ display:'flex', alignItems:'center', gap:4 }}>
            <span style={{ width:8, height:8, borderRadius:4, background:'#6B9AD6' }}/> hoy
          </span>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// ASESOR — tareas accionables
// Cada tarea: chip urgencia, título, body, impacto, CTA
// ─────────────────────────────────────────────────────────────
function AsesorLt({ D, S }) {
  return (
    <div style={{ margin:'20px 22px 0', animation:'mf-rise .8s .5s ease both' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:8 }}>
        <div>
          <div style={{ fontSize:10, letterSpacing:1.6, fontWeight:700, color:'#6F7A73' }}>
            ASESOR · tareas para hoy
          </div>
          <div style={{ fontSize:13, color:'#0F2A1E', fontWeight:700, marginTop:4 }}>
            Si hacés esto hoy, ganás <span style={{ color:'#2E7D5B' }}>+$15.800/mes</span>
          </div>
        </div>
        <div style={{ padding:'4px 10px', borderRadius:999, background:'#0F2A1E',
          color:'#C7EE9C', fontSize:10, fontWeight:800, letterSpacing:1 }}>
          {D.tareas.length} TAREAS
        </div>
      </div>

      <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
        {D.tareas.map((t, i) => (
          <TareaCardLt key={t.id} t={t} delay={0.55 + i*0.08}/>
        ))}
      </div>

      {/* footer motivacional */}
      <div style={{ marginTop:14, padding:'14px 16px', borderRadius:16,
        background:'linear-gradient(135deg, #0F2A1E, #143B2A)', color:'#F6FBEF',
        position:'relative', overflow:'hidden' }}>
        <div style={{ position:'absolute', top:-20, right:-20, fontSize:70, opacity:0.1 }}>🌱</div>
        <div style={{ fontSize:10, letterSpacing:1.4, fontWeight:700, color:'#C7EE9C' }}>
          AL CERRAR EL MES
        </div>
        <div className="sf-display" style={{ fontSize:20, fontWeight:800,
          marginTop:4, letterSpacing:-0.5, lineHeight:1.2 }}>
          Si seguís a este ritmo, ahorrás <span style={{ color:'#C7EE9C' }}>$480k</span> más que el mes pasado.
        </div>
        <div style={{ fontSize:11, color:'rgba(246,251,239,0.6)', marginTop:6 }}>
          Marzo cerraste con $1.440k ahorrados. Abril proyecta $1.920k.
        </div>
      </div>
    </div>
  );
}

function TareaCardLt({ t, delay }) {
  const urgencyColor = t.urgency==='alta' ? '#D96A4F' : t.urgency==='media' ? '#E8976A' : '#C9A23A';
  const urgencyBg    = t.urgency==='alta' ? '#F5C6B6' : t.urgency==='media' ? '#FADFC8' : '#F3E8D0';
  return (
    <div style={{
      background:'#FFFBF2', border:'1px solid #EFE8D9', borderRadius:16,
      padding:'14px 16px', position:'relative', overflow:'hidden',
      animation:`mf-rise .6s ${delay}s ease both`,
    }}>
      {/* urgency stripe */}
      <div style={{ position:'absolute', left:0, top:0, bottom:0, width:4,
        background: urgencyColor, opacity:0.8 }}/>
      <div style={{ display:'flex', alignItems:'flex-start', gap:12, paddingLeft:6 }}>
        <div style={{ width:44, height:44, borderRadius:12,
          background:`linear-gradient(140deg, ${urgencyBg}, ${urgencyBg}88)`,
          border:`1px solid ${urgencyColor}44`,
          display:'grid', placeItems:'center', fontSize:20, flexShrink:0 }}>
          {t.emoji}
        </div>
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ display:'flex', alignItems:'center', gap:6, marginBottom:2 }}>
            <span style={{ fontSize:9, letterSpacing:1, fontWeight:700,
              color: urgencyColor,
              padding:'2px 8px', borderRadius:999,
              background: urgencyBg, border:`1px solid ${urgencyColor}55` }}>
              {t.urgency === 'alta' ? '● ALTA' : t.urgency === 'media' ? '◐ MEDIA' : '○ BAJA'}
            </span>
          </div>
          <div style={{ fontSize:14, fontWeight:800, color:'#0F2A1E', letterSpacing:-0.2 }}>
            {t.title}
          </div>
          <div style={{ fontSize:12, color:'#6F7A73', marginTop:2, lineHeight:1.4 }}>
            {t.body}
          </div>
          <div style={{ marginTop:8, display:'flex', alignItems:'center', gap:8 }}>
            <div style={{ flex:1, display:'flex', alignItems:'center', gap:6, fontSize:11,
              color:'#2E7D5B', fontWeight:700 }}>
              <span style={{ fontSize:13 }}>💰</span> {t.impact}
            </div>
            <button style={{
              background:'#0F2A1E', color:'#F6FBEF', border:'none',
              padding:'8px 14px', borderRadius:999, cursor:'pointer',
              fontSize:12, fontWeight:700, fontFamily:'inherit',
              display:'flex', alignItems:'center', gap:4,
            }}>{t.cta} →</button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// CONTROL · DARK
// ─────────────────────────────────────────────────────────────
function ControlDark() {
  const D = CONTROL_DATA;
  const S = useMemoCt(() => summarizeControl(D), []);
  return (
    <div className="screen" style={{ background:'#0A1410', overflowY:'auto' }}>
      <StatusBar color="#F6FBEF"/>

      <div style={{ position:'absolute', top:-70, right:-50, width:260, height:260, borderRadius:'50%',
        background:'radial-gradient(closest-side, rgba(111,224,154,0.22), transparent 70%)',
        pointerEvents:'none', animation:'mf-float-slow 9s ease-in-out infinite' }}/>
      <div style={{ position:'absolute', top:820, left:-70, width:220, height:220, borderRadius:'50%',
        background:'radial-gradient(closest-side, rgba(242,181,138,0.14), transparent 70%)',
        pointerEvents:'none', animation:'mf-float-slow 12s ease-in-out infinite', animationDelay:'-3s' }}/>

      <div style={{ padding:'2px 22px 0', display:'flex', alignItems:'flex-start', justifyContent:'space-between',
        animation:'mf-rise .6s ease both' }}>
        <div>
          <div className="sf-display" style={{ fontSize:34, fontWeight:800, color:'#F6FBEF', letterSpacing:-1.2, lineHeight:1 }}>
            Control
          </div>
          <div style={{ fontSize:13, color:'#8FA094', marginTop:6, maxWidth:280 }}>
            Tu asesor financiero, un día a la vez.
          </div>
        </div>
        <div style={{ display:'flex', alignItems:'center', gap:4, padding:'4px 10px',
          background:'#13221B', border:'1px solid #1F332A', borderRadius:999,
          fontSize:11, fontWeight:700, color:'#F6FBEF' }}>
          <span style={{ fontSize:13 }}>🔥</span> {S.racha}
        </div>
      </div>

      <HeroDiaDk D={D} S={S}/>
      <VaultDk D={D} S={S}/>
      <ProyeccionDk D={D} S={S}/>
      <RitmoSemanalDk D={D} S={S}/>
      <AsesorDk D={D} S={S}/>

      <div style={{ height:120 }}/>
      <TabBarGxDk active="control"/>
    </div>
  );
}

function HeroDiaDk({ D, S }) {
  const R = 90;
  const C = 2 * Math.PI * R;
  const gastoPct = Math.min(1, D.gastoHoy / D.cupoDiario);
  const horaPct = S.horaF / 24;
  const cupoExpPct = horaPct;
  const estaOk = S.delta >= 0;

  return (
    <div style={{ margin:'16px 22px 0',
      background:'linear-gradient(135deg, #13221B 0%, #0E1A15 100%)',
      border:'1px solid #1F332A',
      borderRadius:28, padding:'22px 20px 20px', color:'#F6FBEF',
      position:'relative', overflow:'hidden',
      boxShadow:'0 18px 40px -16px rgba(0,0,0,0.6), inset 0 1px 0 rgba(246,251,239,0.04)',
      animation:'mf-rise .8s .1s ease both' }}>

      <div style={{ position:'absolute', top:-40, right:-40, width:220, height:220, borderRadius:'50%',
        background:`radial-gradient(closest-side, ${estaOk?'rgba(199,238,156,0.3)':'rgba(242,181,138,0.28)'}, transparent 70%)` }}/>

      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', position:'relative' }}>
        <div style={{ fontSize:11, letterSpacing:1.6, fontWeight:700, color:'#C7EE9C' }}>HOY · MARTES 22</div>
        <div style={{ fontSize:10, fontWeight:700, color:'rgba(246,251,239,0.75)',
          padding:'3px 10px', borderRadius:999,
          background:`rgba(${estaOk?'199,238,156':'242,181,138'},0.15)`,
          border:`1px solid rgba(${estaOk?'199,238,156':'242,181,138'},0.4)`,
        }}>
          {estaOk ? '●' : '○'} {estaOk ? 'EN RITMO' : 'ATRASADO'}
        </div>
      </div>

      <div style={{ display:'flex', alignItems:'center', gap:14, marginTop:14, position:'relative' }}>
        <div style={{ width:210, height:210, position:'relative', flexShrink:0 }}>
          <svg width="210" height="210" viewBox="0 0 210 210">
            <defs>
              <linearGradient id="ct-ring-spent-dk" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor={estaOk?'#C7EE9C':'#F2B58A'}/>
                <stop offset="100%" stopColor={estaOk?'#6FE09A':'#E8976A'}/>
              </linearGradient>
            </defs>
            {Array.from({length: 24}).map((_, i) => {
              const angle = (i / 24) * 2 * Math.PI - Math.PI/2;
              const r1 = 104, r2 = (i % 6 === 0) ? 98 : 101;
              const x1 = 105 + r1 * Math.cos(angle), y1 = 105 + r1 * Math.sin(angle);
              const x2 = 105 + r2 * Math.cos(angle), y2 = 105 + r2 * Math.sin(angle);
              return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2}
                stroke={i === Math.floor(S.horaF) ? '#C7EE9C' : 'rgba(246,251,239,0.28)'}
                strokeWidth={i === Math.floor(S.horaF) ? 2 : 1} strokeLinecap="round"/>;
            })}
            <g transform={`rotate(${horaPct * 360 - 90} 105 105)`}>
              <circle cx="200" cy="105" r="3.5" fill="#C7EE9C"
                style={{ animation:'mf-breathe 2.4s ease-in-out infinite', filter:'drop-shadow(0 0 6px #C7EE9C)' }}/>
            </g>
            <circle cx="105" cy="105" r={R} fill="none" stroke="rgba(246,251,239,0.06)" strokeWidth="16"/>
            <g transform="rotate(-90 105 105)">
              <circle cx="105" cy="105" r={R} fill="none" stroke="url(#ct-ring-spent-dk)"
                strokeWidth="16" strokeLinecap="round"
                strokeDasharray={`${C * gastoPct} ${C}`}
                style={{ animation:'mf-fj-ring-paid 1.4s .3s cubic-bezier(.2,.9,.2,1) both',
                  filter:`drop-shadow(0 0 10px ${estaOk?'rgba(199,238,156,0.6)':'rgba(242,181,138,0.5)'})` }}/>
            </g>
            <g transform="rotate(-90 105 105)">
              <circle
                cx={105 + R * Math.cos((cupoExpPct) * 2 * Math.PI)}
                cy={105 + R * Math.sin((cupoExpPct) * 2 * Math.PI)}
                r="5" fill="#F6FBEF" stroke="#0A1410" strokeWidth="2"
                style={{ animation:'mf-breathe 2s ease-in-out infinite' }}/>
            </g>
          </svg>

          <div style={{ position:'absolute', inset:0, display:'flex', flexDirection:'column',
            alignItems:'center', justifyContent:'center', textAlign:'center' }}>
            <div style={{ fontSize:9, letterSpacing:1.4, fontWeight:700, color:'rgba(246,251,239,0.55)' }}>
              PODÉS GASTAR HOY
            </div>
            <div className="sf-display" style={{ fontSize:28, fontWeight:800, color:'#F6FBEF',
              letterSpacing:-1, lineHeight:1, marginTop:3,
              textShadow:'0 0 18px rgba(199,238,156,0.35)' }}>
              $<CountUp to={Math.max(0, S.libreHoy)} duration={1200}/>
            </div>
            <div style={{ marginTop:4, fontSize:10, color:'rgba(246,251,239,0.5)', fontWeight:600 }}>
              de $<CountUp to={D.cupoDiario} duration={1200}/>
            </div>
            <div style={{ marginTop:6, padding:'3px 10px', borderRadius:999,
              background: estaOk ? 'rgba(199,238,156,0.18)' : 'rgba(242,181,138,0.22)',
              border: `1px solid ${estaOk?'rgba(199,238,156,0.4)':'rgba(242,181,138,0.4)'}`,
              fontSize:10, fontWeight:700, color: estaOk?'#C7EE9C':'#F2B58A' }}>
              {estaOk ? `↑ ${((S.delta/D.cupoDiario)*100).toFixed(0)}% adelantado` : `↓ ${Math.abs((S.delta/D.cupoDiario)*100).toFixed(0)}% atrasado`}
            </div>
          </div>
        </div>

        <div style={{ flex:1, display:'flex', flexDirection:'column', gap:8 }}>
          <div style={{ padding:'10px 12px', borderRadius:12,
            background:'rgba(246,251,239,0.03)', border:'1px solid rgba(246,251,239,0.07)' }}>
            <div style={{ fontSize:9, letterSpacing:1.4, fontWeight:700, color:'rgba(246,251,239,0.5)' }}>
              LLEVÁS GASTADO
            </div>
            <div className="sf-display" style={{ fontSize:18, fontWeight:800, color:'#F6FBEF', letterSpacing:-0.5, marginTop:2 }}>
              ${D.gastoHoy.toLocaleString('es-AR')}
            </div>
            <div style={{ fontSize:10, color:'rgba(246,251,239,0.45)', marginTop:1 }}>
              en {D.gastoHoyByCat.length} gastos
            </div>
          </div>

          <div style={{ padding:'10px 12px', borderRadius:12,
            background: estaOk ? 'linear-gradient(135deg, rgba(199,238,156,0.18), rgba(141,214,106,0.04))'
                               : 'linear-gradient(135deg, rgba(242,181,138,0.18), rgba(232,151,106,0.04))',
            border: `1px solid ${estaOk?'rgba(199,238,156,0.3)':'rgba(242,181,138,0.3)'}` }}>
            <div style={{ fontSize:9, letterSpacing:1.4, fontWeight:700, color:'rgba(246,251,239,0.55)' }}>
              DEBERÍAS LLEVAR
            </div>
            <div className="sf-display" style={{ fontSize:18, fontWeight:800, color:'#F6FBEF', letterSpacing:-0.5, marginTop:2 }}>
              ${Math.round(S.cupoHastaAhora).toLocaleString('es-AR')}
            </div>
            <div style={{ fontSize:10, color: estaOk?'#C7EE9C':'#F2B58A', fontWeight:700, marginTop:1 }}>
              {estaOk ? `te sobran $${Math.round(S.delta).toLocaleString('es-AR')}` : `te pasaste $${Math.abs(Math.round(S.delta)).toLocaleString('es-AR')}`}
            </div>
          </div>
        </div>
      </div>

      <div style={{ marginTop:14, padding:'10px 12px', borderRadius:12,
        background:'rgba(246,251,239,0.03)', border:'1px solid rgba(246,251,239,0.07)',
        display:'flex', alignItems:'center', gap:10 }}>
        <div style={{ fontSize:11, fontWeight:700, color:'#C7EE9C' }}>⏱ {D.horaActual}:{String(D.minActual).padStart(2,'0')}</div>
        <div style={{ flex:1, height:6, borderRadius:3, background:'rgba(246,251,239,0.08)',
          overflow:'hidden', position:'relative' }}>
          <div style={{ position:'absolute', inset:0, width:`${horaPct*100}%`,
            background:'linear-gradient(90deg, rgba(199,238,156,0.4), rgba(199,238,156,0.1))',
            animation:'mf-grow-bar 1s .6s ease both', transformOrigin:'left' }}/>
          <div style={{ position:'absolute', top:-2, height:10, width:2,
            left:`${gastoPct*100}%`, background:'#F2B58A', borderRadius:2, boxShadow:'0 0 8px #F2B58A' }}/>
          <div style={{ position:'absolute', top:-2, height:10, width:2,
            left:`${cupoExpPct*100}%`, background:'#F6FBEF', opacity:0.55, borderRadius:2 }}/>
        </div>
        <div style={{ fontSize:10, fontWeight:700, color:'rgba(246,251,239,0.5)' }}>23:59</div>
      </div>
    </div>
  );
}

function VaultDk({ D, S }) {
  const diasGanadores = D.dias.filter(g => g <= D.cupoDiario).length;
  const diasPerdedores = D.dias.length - diasGanadores;
  return (
    <div style={{ margin:'16px 22px 0',
      background:'#13221B', border:'1px solid #1F332A', borderRadius:24,
      padding:'18px 20px', position:'relative', overflow:'hidden',
      animation:'mf-rise .8s .2s ease both' }}>
      <div style={{ fontSize:10, letterSpacing:1.6, fontWeight:700, color:'#8FA094' }}>
        VAULT · lo que ganaste este mes
      </div>

      <div style={{ display:'flex', alignItems:'flex-end', gap:16, marginTop:6 }}>
        <div style={{ flex:1 }}>
          <div className="sf-display" style={{ fontSize:38, fontWeight:800, color:'#F6FBEF',
            letterSpacing:-1.4, lineHeight:1, textShadow:'0 0 18px rgba(199,238,156,0.25)' }}>
            +$<CountUp to={S.vault} duration={1400}/>
          </div>
          <div style={{ fontSize:12, color:'#C7EE9C', fontWeight:700, marginTop:4 }}>
            en {diasGanadores} día{diasGanadores!==1?'s':''} bajo el cupo
          </div>
          <div style={{ fontSize:11, color:'#8FA094', marginTop:2 }}>
            promedio diario ${Math.round(S.promedio).toLocaleString('es-AR')} · cupo ${D.cupoDiario.toLocaleString('es-AR')}
          </div>
        </div>
        <VaultGlyphDk/>
      </div>

      <div style={{ marginTop:14, display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:8 }}>
        <MiniStatDk label="RACHA" value={`${S.racha}d`} emoji="🔥" tint="#F2B58A"/>
        <MiniStatDk label="MEJOR" value={`$${(S.mejor.gasto/1000).toFixed(0)}k`} sub={`día ${S.mejor.dia}`} tint="#9EE0B2" emoji="⭐"/>
        <MiniStatDk label="PEOR" value={`$${(S.peor.gasto/1000).toFixed(0)}k`} sub={`día ${S.peor.dia}`} tint="#E88A70" emoji="⚠"/>
      </div>

      <div style={{ marginTop:12 }}>
        <div style={{ display:'flex', justifyContent:'space-between', fontSize:10, fontWeight:700, letterSpacing:1.2 }}>
          <span style={{ color:'#9EE0B2' }}>{diasGanadores} BAJO CUPO</span>
          <span style={{ color:'#E88A70' }}>{diasPerdedores} PASADO</span>
        </div>
        <div style={{ marginTop:6, height:8, borderRadius:4, background:'#0A1410', overflow:'hidden', display:'flex' }}>
          <div style={{ width:`${(diasGanadores/D.dias.length)*100}%`,
            background:'linear-gradient(90deg, #C7EE9C, #6FE09A)',
            animation:'mf-grow-bar 1s .5s cubic-bezier(.2,.9,.2,1) both', transformOrigin:'left' }}/>
          <div style={{ width:`${(diasPerdedores/D.dias.length)*100}%`,
            background:'linear-gradient(90deg, #F2B58A, #D96A4F)',
            animation:'mf-grow-bar 1s .7s cubic-bezier(.2,.9,.2,1) both', transformOrigin:'left' }}/>
        </div>
      </div>
    </div>
  );
}

function VaultGlyphDk() {
  return (
    <svg width="92" height="80" viewBox="0 0 92 80" style={{ animation:'mf-bob 4s ease-in-out infinite' }}>
      <defs>
        <linearGradient id="vault-coin-dk" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#F2B58A"/><stop offset="100%" stopColor="#E8976A"/>
        </linearGradient>
        <linearGradient id="vault-leaf-dk" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#C7EE9C"/><stop offset="100%" stopColor="#6FE09A"/>
        </linearGradient>
      </defs>
      {[2,1,0].map(i => (
        <g key={i}>
          <ellipse cx="22" cy={56 - i*4} rx="16" ry="5" fill="url(#vault-coin-dk)" opacity={0.85 - i*0.1}/>
        </g>
      ))}
      <path d="M46 60 C 46 36, 62 24, 78 34 C 86 40, 88 56, 76 64 C 64 72, 50 70, 46 60 Z"
        fill="url(#vault-leaf-dk)" opacity="0.95"/>
      <path d="M46 60 C 46 36, 62 24, 78 34 C 86 40, 88 56, 76 64 C 64 72, 50 70, 46 60 Z"
        fill="none" stroke="#0A1410" strokeWidth="1.2" opacity="0.5"/>
      <rect x="60" y="30" width="14" height="3" rx="1.5" fill="#0A1410" opacity="0.75"/>
      <circle cx="72" cy="46" r="1.5" fill="#0A1410"/>
      <circle cx="68" cy="40" r="3" fill="#F6FBEF" opacity="0.35"/>
    </svg>
  );
}

function MiniStatDk({ label, value, sub, emoji, tint }) {
  return (
    <div style={{ padding:'10px 10px', background:'#0E1A15', borderRadius:12, border:'1px solid #1F332A' }}>
      <div style={{ display:'flex', alignItems:'center', gap:4 }}>
        <span style={{ fontSize:11 }}>{emoji}</span>
        <span style={{ fontSize:9, letterSpacing:1.2, fontWeight:700, color:'#6A7A70' }}>{label}</span>
      </div>
      <div style={{ fontSize:15, fontWeight:800, color: tint || '#F6FBEF', marginTop:2, letterSpacing:-0.3 }}>
        {value}
      </div>
      {sub && <div style={{ fontSize:10, color:'#6A7A70', marginTop:1 }}>{sub}</div>}
    </div>
  );
}

function ProyeccionDk({ D, S }) {
  const libreEscenarioA = Math.max(0, S.libreHoy);
  const escenarioB = Math.max(0, S.libreHoy - 8000);
  const mananaOptimo = S.vault + libreEscenarioA;
  const mananaMod = S.vault + escenarioB;

  return (
    <div style={{ margin:'16px 22px 0', animation:'mf-rise .8s .3s ease both' }}>
      <div style={{ fontSize:10, letterSpacing:1.6, fontWeight:700, color:'#8FA094', marginBottom:8 }}>
        MIRANDO A MAÑANA
      </div>

      <div style={{
        background:'linear-gradient(135deg, rgba(199,238,156,0.08) 0%, rgba(141,214,106,0.02) 100%)',
        border:'1px solid rgba(199,238,156,0.22)', borderRadius:20, padding:'16px 18px',
        position:'relative', overflow:'hidden',
      }}>
        <svg width="100%" height="40" viewBox="0 0 320 40" preserveAspectRatio="none"
          style={{ position:'absolute', top:16, left:0, right:0, opacity:0.3, pointerEvents:'none' }}>
          <path d="M10 20 Q 160 5 310 20" stroke="#C7EE9C" strokeWidth="1.5"
            strokeDasharray="4 4" fill="none"/>
        </svg>

        <div style={{ display:'flex', alignItems:'stretch', gap:12, position:'relative' }}>
          <div style={{ flex:1, padding:'10px 12px', background:'#0E1A15',
            borderRadius:14, border:'1px solid #1F332A' }}>
            <div style={{ fontSize:9, letterSpacing:1.2, fontWeight:700, color:'#6A7A70' }}>SI HOY</div>
            <div style={{ fontSize:14, fontWeight:700, color:'#F6FBEF', marginTop:4 }}>
              No gastás más
            </div>
            <div style={{ fontSize:11, color:'#8FA094', marginTop:1 }}>
              cerrás con <b style={{ color:'#9EE0B2' }}>+${libreEscenarioA.toLocaleString('es-AR')}</b>
            </div>
          </div>

          <div style={{ width:40, display:'flex', flexDirection:'column',
            alignItems:'center', justifyContent:'center' }}>
            <svg width="28" height="20" viewBox="0 0 28 20">
              <path d="M2 10 L22 10 M16 4 L22 10 L16 16" stroke="#C7EE9C" strokeWidth="2"
                strokeLinecap="round" strokeLinejoin="round" fill="none"/>
            </svg>
          </div>

          <div style={{ flex:1.2, padding:'10px 12px', borderRadius:14,
            background:'linear-gradient(135deg, #C7EE9C, #6FE09A)', color:'#0A1410' }}>
            <div style={{ fontSize:9, letterSpacing:1.2, fontWeight:700, color:'rgba(10,20,16,0.65)' }}>
              MAÑANA ARRANCÁS CON
            </div>
            <div className="sf-display" style={{ fontSize:22, fontWeight:800, color:'#0A1410',
              letterSpacing:-0.8, marginTop:4, lineHeight:1 }}>
              ${mananaOptimo.toLocaleString('es-AR')}
            </div>
            <div style={{ fontSize:10, color:'rgba(10,20,16,0.65)', fontWeight:700, marginTop:3 }}>
              vault nuevo
            </div>
          </div>
        </div>

        <div style={{ marginTop:12, padding:'10px 12px', background:'#0E1A15', borderRadius:12,
          border:'1px dashed #1F332A' }}>
          <div style={{ fontSize:9, letterSpacing:1.2, fontWeight:700, color:'#6A7A70', marginBottom:6 }}>
            SEGÚN QUÉ HAGAS HOY
          </div>
          <ProyRowDk label="Ideal (no gastás más)" value={mananaOptimo} color="#9EE0B2" max={mananaOptimo}/>
          <ProyRowDk label="Moderado (un café extra)" value={mananaMod} color="#F2B58A" max={mananaOptimo}/>
          <ProyRowDk label="Sin control" value={S.vault} color="#E88A70" max={mananaOptimo}/>
        </div>
      </div>
    </div>
  );
}

function ProyRowDk({ label, value, color, max }) {
  const pct = (value / max) * 100;
  return (
    <div style={{ marginTop:6 }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', fontSize:11 }}>
        <span style={{ color:'#F6FBEF', fontWeight:600 }}>{label}</span>
        <span style={{ color, fontWeight:800, letterSpacing:-0.3, fontSize:13,
          fontFamily:'SF Pro Display, system-ui' }}>${value.toLocaleString('es-AR')}</span>
      </div>
      <div style={{ marginTop:3, height:6, borderRadius:3, background:'#1F332A', overflow:'hidden' }}>
        <div style={{ width:`${pct}%`, height:'100%', background:color, borderRadius:3,
          animation:'mf-grow-bar .9s .4s cubic-bezier(.2,.9,.2,1) both', transformOrigin:'left',
          boxShadow:`0 0 8px ${color}` }}/>
      </div>
    </div>
  );
}

function RitmoSemanalDk({ D, S }) {
  const items = S.last7;
  const maxDisplay = Math.max(D.cupoDiario * 1.4, ...items.map(i => i.gasto));

  return (
    <div style={{ margin:'16px 22px 0', animation:'mf-rise .8s .4s ease both' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', marginBottom:8 }}>
        <div style={{ fontSize:10, letterSpacing:1.6, fontWeight:700, color:'#8FA094' }}>
          RITMO SEMANAL
        </div>
        <div style={{ fontSize:11, color:'#8FA094', fontWeight:600 }}>
          últimos 7 días
        </div>
      </div>
      <div style={{
        background:'#13221B', border:'1px solid #1F332A', borderRadius:20,
        padding:'16px 18px 14px',
      }}>
        <div style={{ display:'grid', gridTemplateColumns:`repeat(${items.length}, 1fr)`, gap:8,
          alignItems:'flex-end', height:120, position:'relative' }}>
          <div style={{ position:'absolute', left:0, right:0,
            bottom: `${(D.cupoDiario/maxDisplay)*100}%`,
            height:1, background:'rgba(246,251,239,0.18)', zIndex:1, pointerEvents:'none' }}>
            <span style={{ position:'absolute', right:0, top:-14, fontSize:9, fontWeight:700,
              color:'#8FA094', background:'#13221B', padding:'0 4px' }}>CUPO</span>
          </div>
          {items.map((d, i) => {
            const pct = Math.min(1, d.gasto / maxDisplay);
            const over = d.gasto > D.cupoDiario && !d.inProgress;
            const color = d.inProgress ? '#8FB8E0' : over ? '#E88A70' : '#9EE0B2';
            const gradient = d.inProgress
              ? 'linear-gradient(180deg, #AFCDE8, #6B9AD6)'
              : over
              ? 'linear-gradient(180deg, #F2B58A, #D96A4F)'
              : 'linear-gradient(180deg, #C7EE9C, #6FE09A)';
            return (
              <div key={i} style={{ position:'relative', height:'100%',
                display:'flex', flexDirection:'column', justifyContent:'flex-end', zIndex:2 }}>
                <div title={`Día ${d.dia}: $${d.gasto.toLocaleString('es-AR')}`}
                  style={{
                    width:'100%', height:`${pct*100}%`, borderRadius:'6px 6px 2px 2px',
                    background: gradient,
                    animation: `mf-grow-vert .7s ${0.4 + i*0.06}s cubic-bezier(.2,.9,.2,1) both`,
                    transformOrigin:'bottom',
                    boxShadow: d.inProgress ? '0 0 14px rgba(111,154,214,0.6)' : `0 0 8px ${color}33`,
                    position:'relative',
                  }}>
                  {d.inProgress && (
                    <div style={{ position:'absolute', inset:0,
                      background:'repeating-linear-gradient(45deg, transparent 0 6px, rgba(246,251,239,0.22) 6px 8px)',
                      borderRadius:'inherit' }}/>
                  )}
                </div>
              </div>
            );
          })}
        </div>
        <div style={{ marginTop:6, display:'grid', gridTemplateColumns:`repeat(${items.length}, 1fr)`, gap:8 }}>
          {items.map((d, i) => {
            const isToday = d.inProgress;
            return (
              <div key={i} style={{ textAlign:'center' }}>
                <div style={{ fontSize:10, fontWeight: isToday ? 800 : 600,
                  color: isToday ? '#F6FBEF' : '#6A7A70' }}>{d.dia}</div>
              </div>
            );
          })}
        </div>

        <div style={{ marginTop:12, display:'flex', gap:10, fontSize:10, color:'#8FA094',
          fontWeight:600, alignItems:'center', flexWrap:'wrap' }}>
          <span style={{ display:'flex', alignItems:'center', gap:4 }}>
            <span style={{ width:8, height:8, borderRadius:4, background:'#9EE0B2' }}/> bajo cupo
          </span>
          <span style={{ display:'flex', alignItems:'center', gap:4 }}>
            <span style={{ width:8, height:8, borderRadius:4, background:'#E88A70' }}/> pasado
          </span>
          <span style={{ display:'flex', alignItems:'center', gap:4 }}>
            <span style={{ width:8, height:8, borderRadius:4, background:'#8FB8E0' }}/> hoy
          </span>
        </div>
      </div>
    </div>
  );
}

function AsesorDk({ D, S }) {
  return (
    <div style={{ margin:'20px 22px 0', animation:'mf-rise .8s .5s ease both' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:8 }}>
        <div>
          <div style={{ fontSize:10, letterSpacing:1.6, fontWeight:700, color:'#8FA094' }}>
            ASESOR · tareas para hoy
          </div>
          <div style={{ fontSize:13, color:'#F6FBEF', fontWeight:700, marginTop:4 }}>
            Si hacés esto hoy, ganás <span style={{ color:'#9EE0B2' }}>+$15.800/mes</span>
          </div>
        </div>
        <div style={{ padding:'4px 10px', borderRadius:999, background:'linear-gradient(140deg,#C7EE9C,#8DD66A)',
          color:'#0A1410', fontSize:10, fontWeight:800, letterSpacing:1 }}>
          {D.tareas.length} TAREAS
        </div>
      </div>

      <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
        {D.tareas.map((t, i) => (
          <TareaCardDk key={t.id} t={t} delay={0.55 + i*0.08}/>
        ))}
      </div>

      <div style={{ marginTop:14, padding:'14px 16px', borderRadius:16,
        background:'linear-gradient(135deg, #13221B, #0E1A15)',
        border:'1px solid #1F332A', color:'#F6FBEF',
        position:'relative', overflow:'hidden' }}>
        <div style={{ position:'absolute', top:-20, right:-20, fontSize:70, opacity:0.15 }}>🌱</div>
        <div style={{ fontSize:10, letterSpacing:1.4, fontWeight:700, color:'#C7EE9C' }}>
          AL CERRAR EL MES
        </div>
        <div className="sf-display" style={{ fontSize:20, fontWeight:800,
          marginTop:4, letterSpacing:-0.5, lineHeight:1.2 }}>
          Si seguís a este ritmo, ahorrás <span style={{ color:'#C7EE9C' }}>$480k</span> más que el mes pasado.
        </div>
        <div style={{ fontSize:11, color:'#8FA094', marginTop:6 }}>
          Marzo cerraste con $1.440k ahorrados. Abril proyecta $1.920k.
        </div>
      </div>
    </div>
  );
}

function TareaCardDk({ t, delay }) {
  const urgencyColor = t.urgency==='alta' ? '#E88A70' : t.urgency==='media' ? '#F2B58A' : '#F1D690';
  const urgencyBg    = t.urgency==='alta' ? '#4A201A' : t.urgency==='media' ? '#3A2A22' : '#352F1E';
  return (
    <div style={{
      background:'#13221B', border:'1px solid #1F332A', borderRadius:16,
      padding:'14px 16px', position:'relative', overflow:'hidden',
      animation:`mf-rise .6s ${delay}s ease both`,
    }}>
      <div style={{ position:'absolute', left:0, top:0, bottom:0, width:4,
        background: urgencyColor, opacity:0.85, boxShadow:`0 0 8px ${urgencyColor}` }}/>
      <div style={{ display:'flex', alignItems:'flex-start', gap:12, paddingLeft:6 }}>
        <div style={{ width:44, height:44, borderRadius:12,
          background:`linear-gradient(140deg, ${urgencyBg}, ${urgencyBg}cc)`,
          border:`1px solid ${urgencyColor}55`,
          display:'grid', placeItems:'center', fontSize:20, flexShrink:0 }}>
          {t.emoji}
        </div>
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ display:'flex', alignItems:'center', gap:6, marginBottom:2 }}>
            <span style={{ fontSize:9, letterSpacing:1, fontWeight:700,
              color: urgencyColor,
              padding:'2px 8px', borderRadius:999,
              background: urgencyBg, border:`1px solid ${urgencyColor}55` }}>
              {t.urgency === 'alta' ? '● ALTA' : t.urgency === 'media' ? '◐ MEDIA' : '○ BAJA'}
            </span>
          </div>
          <div style={{ fontSize:14, fontWeight:800, color:'#F6FBEF', letterSpacing:-0.2 }}>
            {t.title}
          </div>
          <div style={{ fontSize:12, color:'#8FA094', marginTop:2, lineHeight:1.4 }}>
            {t.body}
          </div>
          <div style={{ marginTop:8, display:'flex', alignItems:'center', gap:8 }}>
            <div style={{ flex:1, display:'flex', alignItems:'center', gap:6, fontSize:11,
              color:'#9EE0B2', fontWeight:700 }}>
              <span style={{ fontSize:13 }}>💰</span> {t.impact}
            </div>
            <button style={{
              background:'linear-gradient(140deg,#C7EE9C,#8DD66A)', color:'#0A1410', border:'none',
              padding:'8px 14px', borderRadius:999, cursor:'pointer',
              fontSize:12, fontWeight:700, fontFamily:'inherit',
              display:'flex', alignItems:'center', gap:4,
            }}>{t.cta} →</button>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { ControlLight, ControlDark });
