// V1 Core — versión consolidada con cherry-picks del equipo
// - Base: estructura V1 (cuaderno cálido, saludo animado, hero oscuro)
// - Suma: card de META (V2) con barra brillante y emoji flotante
// - Suma: atribución "quién gastó" (V3) en la actividad
// - Suma: gráfico "DÓNDE VA EL DINERO" (V5) horizontal estilo editorial
// - Suma: cards "VS MES PASADO" + "RACHA" (V6)
// - Suma: calendario del mes (V6) con heatmap de días
// Tipografía: SF Pro (sistema iOS), sin serif.

const { useEffect: useEffect1, useState: useState1, useRef: useRef1 } = React;

// ─────────────────────────────────────────────────────────────
// Greeting
// ─────────────────────────────────────────────────────────────
function GreetingHeaderV1({ name = 'Mario', hour = 15 }) {
  const g = hour < 6  ? { t:'Buenas noches,',  icon:<MoonIconV1/>,  tint:'#6B3A4F' }
         : hour < 12  ? { t:'Buen día,',       icon:<SunIconV1/>,   tint:'#F2B58A' }
         : hour < 19  ? { t:'Buenas tardes,',  icon:<SunLowIconV1/>,tint:'#E08E63' }
         :              { t:'Buenas noches,',  icon:<MoonIconV1/>,  tint:'#6B3A4F' };
  return (
    <div style={{ padding:'2px 22px 0', animation:'mf-rise .7s ease both' }}>
      <div style={{ display:'flex', alignItems:'center', gap:8, color:'#5A5148', fontSize:14, fontWeight:500 }}>
        <div style={{ width:22, height:22, display:'grid', placeItems:'center', animation:'mf-float-slow 5s ease-in-out infinite' }}>{g.icon}</div>
        {g.t}
      </div>
      <div className="sf-display" style={{
        fontSize:34, lineHeight:1.05, fontWeight:800, color:'#0F2A1E', marginTop:2, letterSpacing:-1.2,
      }}>
        Hola, {name}
      </div>
    </div>
  );
}
const SunIconV1    = () => <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="4" fill="#F2B58A"/><g stroke="#F2B58A" strokeWidth="1.8" strokeLinecap="round"><path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.5 5.5l1.4 1.4M17.1 17.1l1.4 1.4M5.5 18.5l1.4-1.4M17.1 6.9l1.4-1.4"/></g></svg>;
const SunLowIconV1 = () => <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="14" r="4" fill="#E08E63"/><g stroke="#E08E63" strokeWidth="1.8" strokeLinecap="round"><path d="M4 18h16M12 7v2M6 9l1.4 1.4M18 9l-1.4 1.4"/></g></svg>;
const MoonIconV1   = () => <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M20 14.5A8 8 0 019.5 4a8 8 0 1010.5 10.5z" fill="#6B3A4F"/></svg>;

// ─────────────────────────────────────────────────────────────
// Sparkline (hero)
// ─────────────────────────────────────────────────────────────
function SparklineV1({ data, color='#6FE09A', fill='rgba(111,224,154,0.18)', w=320, h=56, delay=400 }) {
  const max = Math.max(...data), min = Math.min(...data);
  const pad = 4;
  const pts = data.map((v,i)=>{
    const x = pad + (i/(data.length-1))*(w-2*pad);
    const y = pad + (1-(v-min)/(max-min||1))*(h-2*pad);
    return [x,y];
  });
  const d = pts.map((p,i)=>(i===0?'M':'L')+p[0].toFixed(1)+' '+p[1].toFixed(1)).join(' ');
  const area = d + ` L ${w-pad} ${h-pad} L ${pad} ${h-pad} Z`;
  const ref = useRef1();
  useEffect1(()=>{
    if (!ref.current) return;
    const len = ref.current.getTotalLength();
    ref.current.style.strokeDasharray = len;
    ref.current.style.strokeDashoffset = len;
    ref.current.style.animation = `mf-draw 1.4s ${delay}ms ease forwards`;
  },[data,delay]);
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} style={{ display:'block' }}>
      <path d={area} fill={fill} style={{ animation:`mf-fade .8s ${delay+600}ms both` }}/>
      <path ref={ref} d={d} fill="none" stroke={color} strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"/>
      <circle cx={pts[pts.length-1][0]} cy={pts[pts.length-1][1]} r="4" fill={color}
        style={{ animation:`mf-fade .4s ${delay+1200}ms both, mf-breathe 2s ${delay+1400}ms ease-in-out infinite` }}/>
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────
// Circle buttons / icons (shared with original V1)
// ─────────────────────────────────────────────────────────────
function CircleBtnV1({ children }) {
  return <button style={{
    width:38, height:38, border:'none', borderRadius:999, background:'#FFFBF2',
    display:'grid', placeItems:'center', cursor:'pointer', position:'relative',
    boxShadow:'0 2px 6px rgba(15,42,30,0.08)',
  }}>{children}
    <span style={{ position:'absolute', top:8, right:10, width:7, height:7, borderRadius:4, background:'#E08E63', boxShadow:'0 0 0 2px #FFFBF2' }}/>
  </button>;
}
const BellIconV1 = () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M18 16v-5a6 6 0 10-12 0v5l-2 2h16l-2-2z" stroke="#0F2A1E" strokeWidth="1.8" strokeLinejoin="round"/><path d="M10 20a2 2 0 004 0" stroke="#0F2A1E" strokeWidth="1.8" strokeLinecap="round"/></svg>;
const SlidersIconV1 = () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M4 6h10M4 12h6M4 18h14" stroke="#0F2A1E" strokeWidth="1.8" strokeLinecap="round"/><circle cx="17" cy="6" r="2" stroke="#0F2A1E" strokeWidth="1.8"/><circle cx="13" cy="12" r="2" stroke="#0F2A1E" strokeWidth="1.8"/><circle cx="19" cy="18" r="2" stroke="#0F2A1E" strokeWidth="1.8"/></svg>;

// ─────────────────────────────────────────────────────────────
// META CARD (ported from V2, polished)
// ─────────────────────────────────────────────────────────────
function MetaCard({ title='Viaje a Bariloche', emoji='🏔️', current=1920000, goal=3000000, months=3 }) {
  const pct = Math.round((current/goal)*100);
  return (
    <div style={{ margin:'12px 22px 0', background:'#0F2A1E', color:'#FFFBF2',
      borderRadius:20, padding:'14px 16px', animation:'mf-rise .9s .3s ease both',
      position:'relative', overflow:'hidden',
    }}>
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
        <div>
          <div style={{ fontSize:10, letterSpacing:1.4, fontWeight:700, color:'#9EE5BA' }}>META · {title.toUpperCase()}</div>
          <div className="sf-display" style={{ fontSize:22, fontWeight:800, marginTop:2, letterSpacing:-0.6 }}>
            ${(current/1000).toLocaleString('es-AR')}k <span style={{ color:'rgba(255,255,255,0.5)', fontSize:14, fontWeight:500 }}>/ ${(goal/1000).toLocaleString('es-AR')}k</span>
          </div>
        </div>
        <div style={{ fontSize:30, animation:'mf-float 3s ease-in-out infinite' }}>{emoji}</div>
      </div>
      <div style={{ marginTop:10, height:8, background:'rgba(255,255,255,0.12)', borderRadius:4, overflow:'hidden', position:'relative' }}>
        <div style={{
          height:'100%', width:`${pct}%`,
          background:'linear-gradient(90deg,#6FE09A,#F2B58A)', borderRadius:4,
          transformOrigin:'left', animation:'mf-grow-bar 1.3s .5s cubic-bezier(.2,.9,.2,1) both',
        }}/>
        <div style={{ position:'absolute', inset:0, overflow:'hidden' }}>
          <div style={{ position:'absolute', top:0, bottom:0, width:'40%',
            background:'linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent)',
            animation:'mf-shine 3.2s 1.8s ease-in-out infinite' }}/>
        </div>
      </div>
      <div style={{ marginTop:8, display:'flex', justifyContent:'space-between', fontSize:11, color:'rgba(255,255,255,0.65)' }}>
        <span>{pct}% alcanzado</span>
        <span>faltan ~{months} meses</span>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Dónde va el dinero (ported from V5)
// ─────────────────────────────────────────────────────────────
function CategoryBreakdown() {
  const items = [
    { label:'Casa',       pct:42, color:'#0F2A1E' },
    { label:'Comida',     pct:26, color:'#E08E63' },
    { label:'Transporte', pct:14, color:'#2E7D5B' },
    { label:'Ocio',       pct:10, color:'#F1D690' },
    { label:'Otros',      pct: 8, color:'#9AA39D' },
  ];
  return (
    <div style={{ margin:'14px 22px 0', background:'#FFFBF2', border:'1px solid #EFE8D9',
      borderRadius:18, padding:'14px 14px 12px', animation:'mf-rise .9s .4s ease both' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:10 }}>
        <div style={{ fontSize:10, letterSpacing:1.6, fontWeight:700, color:'#6F7A73' }}>DÓNDE VA EL DINERO</div>
        <div style={{ fontSize:11, color:'#0F2A1E', fontWeight:600 }}>abril</div>
      </div>
      <div style={{ display:'flex', height:14, borderRadius:7, overflow:'hidden', background:'#F6EFE3' }}>
        {items.map((it,i)=>(
          <div key={i} style={{
            width:`${it.pct}%`, background: it.color,
            transformOrigin:'left', animation:`mf-grow-bar .9s ${0.55+i*0.1}s cubic-bezier(.2,.9,.2,1) both`
          }}/>
        ))}
      </div>
      <div style={{ marginTop:10, display:'flex', flexWrap:'wrap', gap:'6px 12px' }}>
        {items.map((it,i)=>(
          <div key={i} style={{ display:'flex', alignItems:'center', gap:6, fontSize:11, color:'#0F2A1E', fontWeight:600,
            animation:`mf-fade .6s ${0.8+i*0.08}s both` }}>
            <span style={{ width:8, height:8, borderRadius:4, background:it.color }}/>
            {it.label} <span style={{ color:'#6F7A73', fontWeight:500 }}>{it.pct}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// VS mes pasado + RACHA (ported from V6)
// ─────────────────────────────────────────────────────────────
function CompareAndStreak() {
  return (
    <div style={{ padding:'14px 22px 0', display:'grid', gridTemplateColumns:'1fr 1fr', gap:10,
      animation:'mf-rise .9s .5s ease both' }}>
      <div style={{ background:'#FFFBF2', borderRadius:16, padding:'12px', border:'1px solid #EFE8D9' }}>
        <div style={{ fontSize:9, color:'#6F7A73', fontWeight:700, letterSpacing:1.2 }}>VS MARZO</div>
        <div className="sf-display" style={{ fontSize:20, fontWeight:800, letterSpacing:-0.4, marginTop:2, color:'#0F2A1E' }}>+$320k</div>
        <div style={{ fontSize:10, color:'#2CAE6E', fontWeight:700 }}>▲ 18% mejor</div>
        <div style={{ display:'flex', gap:6, marginTop:8, alignItems:'flex-end', height:22 }}>
          <div style={{ flex:1, height:'60%', background:'#E9E1D3', borderRadius:3, transformOrigin:'bottom', animation:'mf-grow-bar .8s .6s ease both' }}/>
          <div style={{ flex:1, height:'100%', background:'#2E7D5B', borderRadius:3, transformOrigin:'bottom', animation:'mf-grow-bar .8s .8s ease both' }}/>
        </div>
      </div>
      <div style={{ background:'#FFFBF2', borderRadius:16, padding:'12px', border:'1px solid #EFE8D9', position:'relative', overflow:'hidden' }}>
        <div style={{ fontSize:9, color:'#6F7A73', fontWeight:700, letterSpacing:1.2 }}>RACHA</div>
        <div className="sf-display" style={{ fontSize:20, fontWeight:800, letterSpacing:-0.4, marginTop:2, color:'#0F2A1E' }}>14 días</div>
        <div style={{ fontSize:10, color:'#6B3A4F', fontWeight:600 }}>sin excesos</div>
        <div style={{ position:'absolute', right:8, bottom:6, fontSize:28, animation:'mf-wiggle 2s ease-in-out infinite' }}>🔥</div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Calendario del mes (ported from V6)
// ─────────────────────────────────────────────────────────────
function MonthCalendar() {
  const today = 22, days = 30;
  const mood = {};
  for (let i=1;i<=today;i++) {
    const r = Math.sin(i*1.7)*Math.cos(i*0.9);
    mood[i] = r > 0.3 ? 'amber' : r < -0.55 ? 'red' : 'green';
  }
  return (
    <div style={{ margin:'14px 22px 0', background:'#FFFBF2', border:'1px solid #EFE8D9',
      borderRadius:18, padding:'14px', animation:'mf-rise .9s .6s ease both' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:10 }}>
        <div style={{ fontSize:10, letterSpacing:1.6, fontWeight:700, color:'#6F7A73' }}>TU MES EN UN VISTAZO</div>
        <div style={{ display:'flex', gap:8, fontSize:9, color:'#6F7A73', fontWeight:600 }}>
          <LegendDot color="#6FE09A" label="bien"/>
          <LegendDot color="#F2B58A" label="alerta"/>
          <LegendDot color="#D96A4F" label="exceso"/>
        </div>
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(7, 1fr)', gap:5 }}>
        {['L','M','M','J','V','S','D'].map((d,i)=>(
          <div key={i} style={{ fontSize:9, textAlign:'center', color:'#9AA39D', fontWeight:700, letterSpacing:1, paddingBottom:2 }}>{d}</div>
        ))}
        {[0,1,2].map(i => <div key={'o'+i}/>)}
        {Array.from({length: days}, (_, idx) => {
          const n = idx+1;
          const m = mood[n];
          const bg = m==='green' ? '#DDEFE3' : m==='amber' ? '#FADFC8' : m==='red' ? '#F5C6B6' : 'transparent';
          const border = n > today ? '1px dashed #E9E1D3' : 'none';
          const color = m==='green' ? '#2E7D5B' : m==='amber' ? '#6B3A4F' : m==='red' ? '#A3452A' : '#9AA39D';
          const isToday = n === today;
          return (
            <div key={n} style={{
              aspectRatio:'1', borderRadius:8, background: isToday ? '#0F2A1E' : bg,
              color: isToday ? '#FFFBF2' : color,
              display:'grid', placeItems:'center', fontSize:11, fontWeight:700,
              border, position:'relative',
              animation:`mf-fade .45s ${0.65 + n*0.012}s both`,
              boxShadow: isToday ? '0 6px 14px -4px rgba(15,42,30,0.4)' : 'none',
            }}>
              {n}
              {isToday && <div style={{ position:'absolute', bottom:2, width:4, height:4, borderRadius:2, background:'#6FE09A', animation:'mf-breathe 1.6s ease-in-out infinite' }}/>}
            </div>
          );
        })}
      </div>
    </div>
  );
}
function LegendDot({ color, label }) {
  return <div style={{ display:'flex', alignItems:'center', gap:4 }}>
    <span style={{ width:7, height:7, borderRadius:4, background:color }}/>{label}
  </div>;
}

// ─────────────────────────────────────────────────────────────
// Hero stats — 3 mini columns bajo el monto
// ─────────────────────────────────────────────────────────────
function HeroStat({ label, value, sub, accent }) {
  return (
    <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:2, padding:'0 4px' }}>
      <div style={{ fontSize:9, letterSpacing:1.4, fontWeight:700,
        color: accent ? '#C7EE9C' : 'rgba(255,255,255,0.55)' }}>{label.toUpperCase()}</div>
      <div className="sf-display" style={{ fontSize:15, fontWeight:800, letterSpacing:-0.4,
        color: accent ? '#C7EE9C' : '#F6FBEF',
        textShadow: accent ? '0 0 12px rgba(199,238,156,0.5)' : 'none' }}>{value}</div>
      <div style={{ fontSize:10, color:'rgba(255,255,255,0.5)', fontWeight:600 }}>{sub}</div>
    </div>
  );
}

// Mini metric card (used for AHORRO + FIJOS row)
// ─────────────────────────────────────────────────────────────
function MiniCardV1({ label, value, sub, chart, delay=0 }) {
  return (
    <div style={{
      background:'#FFFBF2', borderRadius:18, padding:'14px 14px', border:'1px solid #EFE8D9',
      animation:`mf-rise .8s ${delay}ms ease both`, position:'relative', overflow:'hidden',
    }}>
      <div style={{ fontSize:10, letterSpacing:1.4, fontWeight:700, color:'#6F7A73' }}>{label}</div>
      <div className="sf-display" style={{ fontSize:22, fontWeight:800, color:'#0F2A1E', marginTop:4, letterSpacing:-0.5 }}>{value}</div>
      <div style={{ fontSize:11, color:'#9AA39D', marginTop:2 }}>{sub}</div>
      <div style={{ position:'absolute', right:10, bottom:10, opacity:.9 }}>{chart}</div>
    </div>
  );
}
function MiniBarsV1({ values, color }) {
  return <div style={{ display:'flex', alignItems:'flex-end', gap:2, height:22 }}>
    {values.map((v,i)=>(
      <div key={i} style={{ width:5, height: 22*v, background:color, borderRadius:2,
        transformOrigin:'bottom', animation:`mf-grow-bar .6s ${0.4+i*0.08}s ease both` }}/>
    ))}
  </div>;
}

// Shortcut card — lleva al detalle (Gastos / Fijos)
function ShortcutCardLt({ label, value, sub, trend, trendColor='#0F2A1E', chart, delay=0 }) {
  return (
    <div style={{
      background:'#FFFBF2', borderRadius:18, padding:'14px', border:'1px solid #EFE8D9',
      animation:`mf-rise .8s ${delay}ms ease both`, position:'relative', overflow:'hidden',
      cursor:'pointer',
    }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start' }}>
        <div style={{ fontSize:10, letterSpacing:1.4, fontWeight:700, color:'#6F7A73' }}>{label}</div>
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" style={{ opacity:.4 }}>
          <path d="M9 6l6 6-6 6" stroke="#0F2A1E" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      </div>
      <div className="sf-display" style={{ fontSize:22, fontWeight:800, color:'#0F2A1E', marginTop:4, letterSpacing:-0.5 }}>{value}</div>
      <div style={{ fontSize:11, color:'#9AA39D', marginTop:1 }}>{sub}</div>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-end', marginTop:8 }}>
        <div style={{ fontSize:10.5, fontWeight:700, color:trendColor }}>{trend}</div>
        <div>{chart}</div>
      </div>
    </div>
  );
}
function PagoDotsLt({ paid, total }) {
  return <div style={{ display:'flex', gap:3 }}>
    {Array.from({length:total}).map((_,i)=>(
      <div key={i} style={{
        width:6, height:6, borderRadius:3,
        background: i<paid ? '#2CAE6E' : '#EFE8D9',
        animation:`mf-fade .4s ${0.4+i*0.04}s both`,
      }}/>
    ))}
  </div>;
}

// ─────────────────────────────────────────────────────────────
// Activity row — con atribución "quién gastó" (merge de V3)
// ─────────────────────────────────────────────────────────────
function ActivityRowV1({ icon, title, cat, who, amount, delay=0 }) {
  return (
    <div style={{
      background:'#FFFBF2', borderRadius:16, padding:'12px 14px',
      display:'flex', alignItems:'center', gap:12, border:'1px solid #EFE8D9',
      animation:`mf-slide-in .6s ${delay}ms ease both`,
    }}>
      <div style={{ position:'relative', flexShrink:0 }}>
        <div style={{ width:38, height:38, borderRadius:12, background:'#FADFC8', display:'grid', placeItems:'center', fontSize:18 }}>{icon}</div>
        {/* avatar overlay — who paid */}
        <div style={{ position:'absolute', bottom:-3, right:-3 }}>
          <Avatar name={who.name} color={who.color} size={18} ring ringColor="#FFFBF2"/>
        </div>
      </div>
      <div style={{ flex:1, minWidth:0 }}>
        <div style={{ fontSize:14, fontWeight:700, color:'#0F2A1E' }}>{title}</div>
        <div style={{ fontSize:12, color:'#6F7A73' }}>
          {who.name} · {cat}
        </div>
      </div>
      <div style={{ fontSize:14, fontWeight:800, color: amount<0?'#0F2A1E':'#2CAE6E' }}>
        {fmtMoney(amount, { sign:true })}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// THE SCREEN
// ─────────────────────────────────────────────────────────────
function V1Cuaderno() {
  return (
    <div className="screen" style={{ background:'#EFF5E8' }}>
      <StatusBar color="#0E3A26"/>

      {/* living, warm blobs — greener + a touch of peach */}
      <div style={{ position:'absolute', top:-70, right:-50, width:240, height:240, borderRadius:'50%',
        background:'radial-gradient(closest-side, rgba(177,227,130,0.55), transparent 70%)',
        animation:'mf-float-slow 9s ease-in-out infinite', pointerEvents:'none' }}/>
      <div style={{ position:'absolute', top:440, left:-80, width:240, height:240, borderRadius:'50%',
        background:'radial-gradient(closest-side, rgba(247,181,138,0.32), transparent 70%)',
        animation:'mf-float-slow 11s ease-in-out infinite', animationDelay:'-3s', pointerEvents:'none' }}/>
      <div style={{ position:'absolute', top:1000, right:-60, width:260, height:260, borderRadius:'50%',
        background:'radial-gradient(closest-side, rgba(134,206,128,0.35), transparent 70%)',
        animation:'mf-float-slow 13s ease-in-out infinite', animationDelay:'-6s', pointerEvents:'none' }}/>

      {/* header */}
      <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', paddingRight:22, paddingTop:2 }}>
        <GreetingHeaderV1 name="Mario" hour={15}/>
        <div style={{ display:'flex', gap:8, marginTop:14 }}>
          <CircleBtnV1><BellIconV1/></CircleBtnV1>
          <CircleBtnV1><SlidersIconV1/></CircleBtnV1>
        </div>
      </div>

      {/* family strip */}
      <div style={{ padding:'12px 22px 0', display:'flex', alignItems:'center', gap:10, animation:'mf-rise .8s .1s ease both' }}>
        <div style={{ display:'flex' }}>
          {FAMILY.map((f,i) => (
            <div key={i} style={{ marginLeft: i===0?0:-8, animation:`mf-rise .5s ${0.15+i*0.08}s ease both` }}>
              <Avatar name={f.name} color={f.color} size={26} ring ringColor="#F6EFE3"/>
            </div>
          ))}
        </div>
        <div style={{ fontSize:12, color:'#6F7A73' }}>Familia López · <b style={{ color:'#0F2A1E' }}>4</b></div>
        <div style={{ marginLeft:'auto', fontSize:11, fontWeight:600, color:'#0F2A1E',
          background:'#FFFBF2', border:'1px solid #EFE8D9', padding:'5px 10px', borderRadius:999,
          display:'flex', alignItems:'center', gap:6 }}>
          <span style={{ width:6, height:6, borderRadius:3, background:'#E08E63',
            display:'inline-block', animation:'mf-breathe 1.8s ease-in-out infinite' }}/>
          27 días al cobro
        </div>
      </div>

      {/* hero card — DISPONIBLE HOY */}
      <div style={{ margin:'12px 22px 0',
        background:'linear-gradient(150deg, #0A2E1E 0%, #0E3A26 35%, #1B6B42 75%, #2DA15E 100%)',
        borderRadius:28,
        padding:'22px 22px 24px', color:'#F6FBEF', position:'relative', overflow:'hidden',
        animation:'mf-rise .9s .15s ease both',
        boxShadow:'0 28px 50px -22px rgba(14,58,38,0.65), inset 0 1px 0 rgba(199,238,156,0.18)',
        border:'1px solid rgba(199,238,156,0.12)',
      }}>
        {/* animated aurora blobs */}
        <div style={{ position:'absolute', inset:0, pointerEvents:'none', overflow:'hidden', borderRadius:28 }}>
          <div style={{ position:'absolute', top:-40, right:-40, width:200, height:200, borderRadius:'50%',
            background:'radial-gradient(closest-side, rgba(199,238,156,0.35), transparent 70%)',
            filter:'blur(6px)',
            animation:'mf-aurora-a 9s ease-in-out infinite' }}/>
          <div style={{ position:'absolute', bottom:-50, left:-30, width:180, height:180, borderRadius:'50%',
            background:'radial-gradient(closest-side, rgba(247,181,138,0.28), transparent 70%)',
            filter:'blur(6px)',
            animation:'mf-aurora-b 11s ease-in-out infinite' }}/>
          <div style={{ position:'absolute', top:60, left:'40%', width:140, height:140, borderRadius:'50%',
            background:'radial-gradient(closest-side, rgba(141,214,106,0.22), transparent 70%)',
            filter:'blur(8px)',
            animation:'mf-aurora-c 13s ease-in-out infinite' }}/>
          <div style={{ position:'absolute', top:0, left:0, width:'45%', height:'100%',
            background:'linear-gradient(120deg, transparent, rgba(255,255,255,0.1), transparent)',
            animation:'mf-shine 4.2s 1s ease-in-out infinite' }}/>
          {/* floating coin particles */}
          {[0,1,2,3,4].map(i => (
            <div key={i} style={{
              position:'absolute',
              left:`${15 + i*18}%`,
              top:'100%',
              width:6, height:6, borderRadius:'50%',
              background: i%2 ? 'rgba(199,238,156,0.55)' : 'rgba(247,181,138,0.5)',
              boxShadow:'0 0 8px rgba(199,238,156,0.6)',
              animation:`mf-coin-rise ${6+i*0.8}s ${i*0.6}s linear infinite`,
            }}/>
          ))}
        </div>

        {/* top row */}
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', position:'relative', zIndex:2 }}>
          <div style={{ display:'flex', alignItems:'center', gap:8 }}>
            <span style={{ display:'inline-flex', width:10, height:10, borderRadius:5,
              background:'#C7EE9C', boxShadow:'0 0 10px #C7EE9C',
              animation:'mf-breathe 1.8s ease-in-out infinite' }}/>
            <div style={{ fontSize:11, letterSpacing:1.8, fontWeight:800, color:'#C7EE9C' }}>DISPONIBLE HOY</div>
          </div>
          <div style={{ fontSize:10, color:'rgba(255,255,255,0.7)', fontWeight:600,
            padding:'4px 9px', borderRadius:999,
            background:'rgba(255,255,255,0.08)', border:'1px solid rgba(255,255,255,0.12)' }}>
            Abril · día 22/30
          </div>
        </div>

        {/* big amount */}
        <div className="sf-display" style={{ fontSize:52, fontWeight:800, lineHeight:1, marginTop:14,
          letterSpacing:-2.4, position:'relative', zIndex:2,
          textShadow:'0 2px 20px rgba(199,238,156,0.25)' }}>
          <CountUp to={4455000} duration={1600} prefix="$"/>
        </div>

        {/* margin line */}
        <div style={{ marginTop:10, fontSize:13, color:'rgba(255,255,255,0.78)', position:'relative', zIndex:2,
          display:'flex', alignItems:'center', gap:8, flexWrap:'wrap' }}>
          <span>Margen del mes</span>
          <span style={{ color:'#C7EE9C', fontWeight:800 }}>+$2.535.000</span>
          <span style={{ padding:'2px 9px', borderRadius:999,
            background:'linear-gradient(135deg, rgba(199,238,156,0.28), rgba(141,214,106,0.2))',
            color:'#E7FFD2', fontSize:11, fontWeight:800,
            border:'1px solid rgba(199,238,156,0.3)',
            boxShadow:'0 4px 12px -4px rgba(199,238,156,0.4)' }}>▲ +18%</span>
        </div>

        {/* sparkline with glow */}
        <div style={{ marginTop:18, marginLeft:-4, position:'relative', zIndex:2,
          filter:'drop-shadow(0 4px 12px rgba(199,238,156,0.3))' }}>
          <SparklineV1 data={[22,28,26,33,31,38,36,42,40,47,52,58]} w={320} h={58} color="#C7EE9C" fill="rgba(199,238,156,0.28)"/>
          {/* traveling dot at end */}
          <div style={{ position:'absolute', right:10, top:8, width:10, height:10, borderRadius:5,
            background:'#C7EE9C', boxShadow:'0 0 14px #C7EE9C, 0 0 4px #fff',
            animation:'mf-breathe 1.6s ease-in-out infinite' }}/>
        </div>

        {/* micro stats row */}
        <div style={{ marginTop:16, display:'grid', gridTemplateColumns:'1fr 1px 1fr 1px 1fr', gap:0,
          position:'relative', zIndex:2,
          padding:'12px 4px 0', borderTop:'1px solid rgba(255,255,255,0.12)' }}>
          <HeroStat label="Hoy" value="$31.600" sub="disponible"/>
          <div style={{ background:'rgba(255,255,255,0.1)' }}/>
          <HeroStat label="Gastado" value="$12.400" sub="3 movs"/>
          <div style={{ background:'rgba(255,255,255,0.1)' }}/>
          <HeroStat label="Alcancía" value="+$84k" sub="ahorrado" accent/>
        </div>
      </div>

      {/* metric cards — ahora son atajos a Gastos y Fijos */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10, padding:'12px 22px 0' }}>
        <ShortcutCardLt
          label="GASTOS" value="$1.545.000" sub="este mes · 47 movs"
          trend="+12% vs marzo" trendColor="#C25A3E"
          chart={<MiniBarsV1 values={[0.4,0.55,0.7,0.6,0.85,0.72,0.9]} color="#0F2A1E"/>}
          delay={200}
        />
        <ShortcutCardLt
          label="FIJOS" value="$920.000" sub="7 de 12 pagados"
          trend="3 próximos" trendColor="#0F2A1E"
          chart={<PagoDotsLt paid={7} total={12}/>}
          delay={260}
        />
      </div>

      {/* META CARD */}
      <MetaCard/>

      {/* ACTIVITY */}
      <div style={{ padding:'14px 22px 0', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <div style={{ fontSize:11, letterSpacing:1.6, fontWeight:700, color:'#6F7A73' }}>ACTIVIDAD</div>
        <div style={{ fontSize:13, fontWeight:600, color:'#0F2A1E' }}>Ver todos</div>
      </div>
      <div style={{ margin:'8px 22px 0', display:'flex', flexDirection:'column', gap:6 }}>
        <ActivityRowV1 icon="🍹" title="Fernet con coca" cat="Gastos generales" who={FAMILY[0]} amount={-25000} delay={400}/>
        <ActivityRowV1 icon="🛒" title="Supermercado" cat="Casa" who={FAMILY[1]} amount={-42300} delay={460}/>
        <ActivityRowV1 icon="🚌" title="SUBE" cat="Transporte" who={FAMILY[2]} amount={-8000} delay={520}/>
      </div>

      {/* bottom spacer so tab bar doesn't cover content */}
      <div style={{ height:120 }}/>

      <TabBar accent="#8DD66A" bg="#EFF5E8"/>
    </div>
  );
}

// Keep legacy exports used elsewhere in the canvas
window.V1Cuaderno = V1Cuaderno;
window.CircleBtn = CircleBtnV1;
window.BellIcon = BellIconV1;
window.SlidersIcon = SlidersIconV1;
