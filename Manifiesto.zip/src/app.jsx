// Main app — wires up the design canvas with all variants

const { useState: useStateApp, useEffect: useEffectApp } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "animations": "full",
  "density": "aireado",
  "hideAmounts": false,
  "hour": "tarde",
  "dataset": "normal"
}/*EDITMODE-END*/;

function App() {
  const [tweaks, setTweaks] = useStateApp(TWEAK_DEFAULTS);
  const [editOpen, setEditOpen] = useStateApp(false);
  const [addSheet, setAddSheet] = useStateApp(null); // 'light' | 'dark' | null

  useEffectApp(() => {
    const onMsg = (e) => {
      const d = e.data || {};
      if (d.type === '__activate_edit_mode') setEditOpen(true);
      if (d.type === '__deactivate_edit_mode') setEditOpen(false);
    };
    window.addEventListener('message', onMsg);
    window.parent.postMessage({ type:'__edit_mode_available' }, '*');
    return () => window.removeEventListener('message', onMsg);
  }, []);

  // when tweaks change, persist
  useEffectApp(() => {
    window.parent.postMessage({ type:'__edit_mode_set_keys', edits: tweaks }, '*');
  }, [tweaks]);

  // apply animation intensity globally
  useEffectApp(() => {
    const root = document.documentElement;
    if (tweaks.animations === 'off') {
      root.style.setProperty('--anim-mult', '0');
      document.body.style.setProperty('animation-play-state','paused');
      const style = document.getElementById('mf-anim-override') || Object.assign(document.createElement('style'), { id:'mf-anim-override' });
      style.textContent = `*, *::before, *::after { animation-duration: 0.01ms !important; animation-iteration-count: 1 !important; transition-duration: 0.01ms !important; }`;
      if (!style.parentNode) document.head.appendChild(style);
    } else {
      const style = document.getElementById('mf-anim-override');
      if (style) style.remove();
    }
  }, [tweaks.animations]);

  const explorations = [
    { id: 'v2', label: 'V2 · Mentu (mascota)',        render: () => <V2Mascota/> },
    { id: 'v3', label: 'V3 · Feed familiar',          render: () => <V3Feed/> },
    { id: 'v4', label: 'V4 · La meta es el héroe',    render: () => <V4Meta/> },
    { id: 'v5', label: 'V5 · Editorial minimal',      render: () => <V5Editorial/> },
    { id: 'v6', label: 'V6 · Calendario del mes',     render: () => <V6Calendario/> },
  ];

  return (
    <TweakCtx.Provider value={tweaks}>
      <DesignCanvas>
        <DCSection id="final" title="Home · V1 Core consolidada" subtitle="Greeting + hero Disponible + atajos a Gastos/Fijos + meta + actividad. Se removieron nota del día y dónde va el dinero (ahora exclusivo en Gastos).">
          <DCArtboard id="orig" label="Actual — referencia" width={390} height={844}>
            <OriginalScreen/>
          </DCArtboard>
          <DCArtboard id="v1core" label="V1 Core · Consolidada ★" width={430} height={1280}>
            <V1Cuaderno/>
          </DCArtboard>
          <DCArtboard id="v1dark" label="V1 Core · Dark Mode 🌙" width={430} height={1280}>
            <V1Dark/>
          </DCArtboard>
        </DCSection>

        <DCSection id="gastos" title="Gastos · historial y detalle" subtitle="Hero con total + peso por categoría (movido desde Home), insights promedio/día y racha de registro, calendario, filtros smart y movimientos con swipe.">
          <DCArtboard id="gastos-actual" label="Actual — referencia" width={390} height={960}>
            <GastosOriginal/>
          </DCArtboard>
          <DCArtboard id="gastos-lt" label="Gastos · V1 Core (light) ★" width={430} height={1720}>
            <GastosLight/>
          </DCArtboard>
          <DCArtboard id="gastos-dk" label="Gastos · V1 Core (dark) 🌙" width={430} height={1720}>
            <GastosDark/>
          </DCArtboard>
        </DCSection>

        <DCSection id="fijos" title="Fijos · anti-Excel" subtitle="Ciclo orbital con estado de pagos, alertas (zombis, subas), próximos a vencer, categorías expandibles, sparklines 3m. + Modal Agregar Fijo con preview de impacto.">
          <DCArtboard id="fijos-lt" label="Fijos · V1 Core (light) ★" width={430} height={2200}>
            <FijosLight/>
          </DCArtboard>
          <DCArtboard id="fijos-dk" label="Fijos · V1 Core (dark) 🌙" width={430} height={2200}>
            <FijosDark/>
          </DCArtboard>
          <DCArtboard id="add-expense-lt" label="Agregar gasto · light" width={430} height={900}>
            <AddExpenseShowcase mode="light"/>
          </DCArtboard>
          <DCArtboard id="add-expense-dk" label="Agregar gasto · dark" width={430} height={900}>
            <AddExpenseShowcase mode="dark"/>
          </DCArtboard>
          <DCArtboard id="add-fijo-lt" label="Agregar fijo · light · step 1" width={430} height={1100}>
            <AddFijoShowcase mode="light" step={1}/>
          </DCArtboard>
          <DCArtboard id="add-fijo-lt2" label="Agregar fijo · light · step 2 (preview)" width={430} height={1100}>
            <AddFijoShowcase mode="light" step={2}/>
          </DCArtboard>
          <DCArtboard id="add-fijo-dk" label="Agregar fijo · dark · step 1" width={430} height={1100}>
            <AddFijoShowcase mode="dark" step={1}/>
          </DCArtboard>
          <DCArtboard id="add-fijo-dk2" label="Agregar fijo · dark · step 2 (preview)" width={430} height={1100}>
            <AddFijoShowcase mode="dark" step={2}/>
          </DCArtboard>
        </DCSection>

        <DCSection id="control" title="Control · asesor financiero" subtitle="Score 0–100, hasta cuándo te alcanza, alcancía/no-spend, ritmo semanal, VS mes pasado (comparación histórica), patrón por día, simulador, cobertura de fijos y tareas del asesor.">
          <DCArtboard id="control-lt" label="Control v2 · light ★" width={430} height={3200}>
            <ControlLight/>
          </DCArtboard>
          <DCArtboard id="control-dk" label="Control v2 · dark 🌙" width={430} height={3200}>
            <ControlDark/>
          </DCArtboard>
        </DCSection>

        <DCSection id="explor" title="Exploraciones previas" subtitle="Las otras direcciones — mantenidas como archivo">
          {explorations.map(v => (
            <DCArtboard key={v.id} id={v.id} label={v.label} width={390} height={844}>
              {v.render()}
            </DCArtboard>
          ))}
        </DCSection>
      </DesignCanvas>

      {editOpen && <TweaksPanel tweaks={tweaks} setTweaks={setTweaks} onClose={()=>setEditOpen(false)}/>}
    </TweakCtx.Provider>
  );
}

const TweakCtx = React.createContext(TWEAK_DEFAULTS);
window.TweakCtx = TweakCtx;

// Render the original home for reference
function OriginalScreen() {
  return (
    <div className="screen" style={{ background:'#F1EADC' }}>
      <StatusBar color="#0F2A1E"/>
      <div style={{ padding:'0 22px', display:'flex', justifyContent:'space-between', alignItems:'flex-start' }}>
        <div style={{ fontSize:32, fontWeight:800, color:'#0F2A1E', marginTop:4 }}>Hola, Mario</div>
        <div style={{ display:'flex', gap:8, marginTop:10 }}>
          <div style={{ width:38, height:38, borderRadius:999, background:'#FFFBF2', display:'grid', placeItems:'center', position:'relative' }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M18 16v-5a6 6 0 10-12 0v5l-2 2h16l-2-2z" stroke="#0F2A1E" strokeWidth="1.8"/></svg>
            <span style={{ position:'absolute', top:8, right:10, width:7, height:7, borderRadius:4, background:'#E08E63' }}/>
          </div>
          <div style={{ width:38, height:38, borderRadius:999, background:'#FFFBF2', display:'grid', placeItems:'center' }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M4 6h10M4 12h6M4 18h14" stroke="#0F2A1E" strokeWidth="1.8"/></svg>
          </div>
        </div>
      </div>
      <div style={{ padding:'10px 22px 0' }}>
        <div style={{ display:'inline-flex', alignItems:'center', gap:6, background:'#EDE3D1', padding:'6px 12px', borderRadius:999, fontSize:12, color:'#0F2A1E' }}>
          <span>⏱</span> Cobro en 27 días
        </div>
      </div>
      <div style={{ margin:'14px 22px 0', background:'#0F2A1E', borderRadius:24, padding:'18px 20px', color:'#FFFBF2' }}>
        <div style={{ fontSize:11, fontWeight:700, color:'#6FE09A', letterSpacing:1.4 }}>DISPONIBLE HOY</div>
        <div style={{ fontSize:44, fontWeight:800, letterSpacing:-1.5, marginTop:6 }}>$4.455.000</div>
        <div style={{ fontSize:13, color:'rgba(255,255,255,0.65)', marginTop:6 }}>Margen del mes <span style={{ color:'#6FE09A', fontWeight:700 }}>+$2.535.000</span></div>
        <button style={{ marginTop:12, border:'none', background:'#6FE09A', color:'#0F2A1E', padding:'12px 18px', borderRadius:999, fontWeight:700, fontSize:14 }}>+ Registrar gasto</button>
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10, padding:'12px 22px 0' }}>
        <div style={{ background:'#FFFBF2', borderRadius:16, padding:'14px' }}>
          <div style={{ fontSize:10, fontWeight:700, color:'#6F7A73', letterSpacing:1.4 }}>AHORRO</div>
          <div style={{ fontSize:22, fontWeight:800, color:'#0F2A1E', marginTop:4 }}>$1.920.000</div>
          <div style={{ fontSize:11, color:'#9AA39D' }}>del mes</div>
        </div>
        <div style={{ background:'#FFFBF2', borderRadius:16, padding:'14px' }}>
          <div style={{ fontSize:10, fontWeight:700, color:'#6F7A73', letterSpacing:1.4 }}>FIJOS</div>
          <div style={{ fontSize:22, fontWeight:800, color:'#0F2A1E', marginTop:4 }}>$0</div>
          <div style={{ fontSize:11, color:'#9AA39D' }}>del mes</div>
        </div>
      </div>
      <div style={{ padding:'14px 22px 0', display:'flex', justifyContent:'space-between' }}>
        <div style={{ fontSize:10, fontWeight:700, color:'#6F7A73', letterSpacing:1.4 }}>RECIENTE</div>
        <div style={{ fontSize:13, fontWeight:600, color:'#0F2A1E' }}>Ver todos</div>
      </div>
      <div style={{ margin:'8px 22px 0', background:'#FFFBF2', borderRadius:16, padding:'12px 14px', display:'flex', alignItems:'center', gap:12 }}>
        <div style={{ width:38, height:38, borderRadius:12, background:'#EDE3D1', display:'grid', placeItems:'center', fontSize:18 }}>📁</div>
        <div style={{ flex:1 }}>
          <div style={{ fontSize:14, fontWeight:700, color:'#0F2A1E' }}>Fernet con coca</div>
          <div style={{ fontSize:12, color:'#9AA39D' }}>Gastos generales</div>
        </div>
        <div style={{ fontSize:14, fontWeight:700, color:'#0F2A1E' }}>-$25.000</div>
      </div>
      <TabBar accent="#6FE09A" bg="#F1EADC"/>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
