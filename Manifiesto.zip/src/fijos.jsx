// Fijos screen — Light & Dark
// Anti-Excel vista: pagos recurrentes, cuotas, suscripciones, deudas, servicios.
// Hero = "ring del ciclo" orbital mostrando % cubierto + días al cobro + próximo a vencer.
// Cada item: nombre, categoría, vencimiento, estado, sparkline 3m, quién paga.

const { useState: useStateFj, useEffect: useEffectFj, useMemo: useMemoFj } = React;

// ─────────────────────────────────────────────────────────────
// Data
// ─────────────────────────────────────────────────────────────
const FIJOS_CATS = [
  { id: 'servicios',  label: 'Servicios',       emoji: '⚡', color: '#E8976A' },
  { id: 'vivienda',   label: 'Vivienda',        emoji: '🏠', color: '#8DB46A' },
  { id: 'subs',       label: 'Suscripciones',   emoji: '🎬', color: '#C9A6E0' },
  { id: 'seguros',    label: 'Seguros',         emoji: '🛡️', color: '#F2B58A' },
  { id: 'cuotas',     label: 'Cuotas',          emoji: '💳', color: '#6B9AD6' },
  { id: 'impuestos',  label: 'Impuestos',       emoji: '📄', color: '#C7A96A' },
  { id: 'deudas',     label: 'Deudas',          emoji: '⚠️', color: '#D96A4F' },
];

// day-of-month when item is due, for the current month (abril).
// status: paid | pending | overdue
// hist: últimos 3 meses (monto); sparkline usa esto
const FIJOS_ITEMS = [
  {
    id:'f1', name:'Alquiler',            cat:'vivienda',  amount: 420000, day: 5,
    status:'paid',    freq:'Mensual',     who:0, method:'Débito',
    hist:[400000, 400000, 420000],  note:'sube con IPC',
  },
  {
    id:'f2', name:'Expensas',            cat:'vivienda',  amount:  95000, day: 10,
    status:'paid',    freq:'Mensual',     who:0, method:'Débito',
    hist:[88000, 90000, 95000],
  },
  {
    id:'f3', name:'Edenor (luz)',        cat:'servicios', amount:  32500, day: 18,
    status:'pending', freq:'Bimestral',   who:0, method:'Tarjeta',
    hist:[18000, 28000, 32500], delta:+14,
  },
  {
    id:'f4', name:'Metrogas',            cat:'servicios', amount:  18400, day: 22,
    status:'pending', freq:'Bimestral',   who:0, method:'Débito',
    hist:[24000, 21000, 18400],
  },
  {
    id:'f5', name:'AySA (agua)',         cat:'servicios', amount:   8900, day: 28,
    status:'pending', freq:'Mensual',     who:0, method:'Débito',
    hist:[8900, 8900, 8900],
  },
  {
    id:'f6', name:'Internet Telecentro', cat:'servicios', amount:  24500, day: 15,
    status:'paid',    freq:'Mensual',     who:0, method:'Tarjeta',
    hist:[20000, 22000, 24500], delta:+11,
  },
  {
    id:'f7', name:'Netflix',             cat:'subs',      amount:   8900, day: 7,
    status:'paid',    freq:'Mensual',     who:1, method:'Tarjeta',
    hist:[6800, 8900, 8900],
  },
  {
    id:'f8', name:'Spotify Familiar',    cat:'subs',      amount:   5500, day: 12,
    status:'paid',    freq:'Mensual',     who:0, method:'Tarjeta',
    hist:[5500, 5500, 5500],
  },
  {
    id:'f9', name:'Disney+',             cat:'subs',      amount:   4200, day: 20,
    status:'pending', freq:'Mensual',     who:1, method:'Tarjeta',
    hist:[4200, 4200, 4200], zombi:true,
  },
  {
    id:'f10', name:'iCloud 200GB',       cat:'subs',      amount:   1300, day: 3,
    status:'paid',    freq:'Mensual',     who:0, method:'Tarjeta',
    hist:[900, 1300, 1300], zombi:true,
  },
  {
    id:'f11', name:'Gym Smartfit',       cat:'subs',      amount:  14000, day: 25,
    status:'pending', freq:'Mensual',     who:0, method:'Tarjeta',
    hist:[14000, 14000, 14000],
  },
  {
    id:'f12', name:'Seguro auto',        cat:'seguros',   amount:  38000, day: 14,
    status:'paid',    freq:'Mensual',     who:0, method:'Tarjeta',
    hist:[34000, 36000, 38000],
  },
  {
    id:'f13', name:'Prepaga Swiss Medical', cat:'seguros', amount: 185000, day: 8,
    status:'paid',    freq:'Mensual',     who:0, method:'Débito',
    hist:[160000, 172000, 185000], delta:+8,
  },
  {
    id:'f14', name:'Cuota iPhone',       cat:'cuotas',    amount:  52000, day: 20,
    status:'pending', freq:'12 cuotas',  cuotaIdx:5, cuotaTot:12, who:0, method:'Tarjeta',
    hist:[52000, 52000, 52000],
  },
  {
    id:'f15', name:'Préstamo Banco',     cat:'cuotas',    amount:  78000, day: 25,
    status:'pending', freq:'36 cuotas',  cuotaIdx:12, cuotaTot:36, who:0, method:'Débito',
    hist:[78000, 78000, 78000],
  },
  {
    id:'f16', name:'ABL (Impuesto)',     cat:'impuestos', amount:  22000, day: 15,
    status:'paid',    freq:'Mensual',    who:0, method:'Débito',
    hist:[20000, 21000, 22000],
  },
  {
    id:'f17', name:'Deuda mamá',         cat:'deudas',    amount:  50000, day: 30,
    status:'overdue', freq:'Única',      who:0, saldo: 200000, method:'Efectivo',
    hist:[50000, 50000, 50000],
  },
];

// quién paga: 0 Mario, 1 Lucía, 2 Tomás, 3 Sofía (FAMILY)
// hoy = día 22 (mismo que gastos)
const HOY_FJ = 22;
const DAYS_MONTH_FJ = 30;

function summarizeFijos(items) {
  const total   = items.reduce((s,i)=>s+i.amount, 0);
  const paid    = items.filter(i=>i.status==='paid');
  const pending = items.filter(i=>i.status==='pending');
  const overdue = items.filter(i=>i.status==='overdue');
  const paidAmt = paid.reduce((s,i)=>s+i.amount, 0);
  const pctPaid = Math.round((paidAmt / total) * 100);
  const upcoming = pending
    .filter(i => i.day >= HOY_FJ)
    .sort((a,b)=>a.day-b.day)
    .slice(0, 3);
  const zombis = items.filter(i => i.zombi);
  const daysToPay = upcoming[0] ? upcoming[0].day - HOY_FJ : null;
  return { total, paid, pending, overdue, paidAmt, pctPaid, upcoming, zombis, daysToPay };
}

function groupByCat(items) {
  const out = {};
  items.forEach(i => { (out[i.cat] = out[i.cat] || []).push(i); });
  return FIJOS_CATS
    .filter(c => out[c.id])
    .map(c => ({ ...c, items: out[c.id], total: out[c.id].reduce((s,i)=>s+i.amount, 0) }));
}

// ─────────────────────────────────────────────────────────────
// FIJOS · LIGHT
// ─────────────────────────────────────────────────────────────
function FijosLight() {
  const [tab, setTab] = useStateFj('todos'); // todos | pendientes | pagados | zombis
  const [sheetOpen, setSheetOpen] = useStateFj(false);

  const items = useMemoFj(() => {
    if (tab === 'pendientes') return FIJOS_ITEMS.filter(i => i.status === 'pending' || i.status === 'overdue');
    if (tab === 'pagados')    return FIJOS_ITEMS.filter(i => i.status === 'paid');
    if (tab === 'zombis')     return FIJOS_ITEMS.filter(i => i.zombi);
    return FIJOS_ITEMS;
  }, [tab]);

  const sum = useMemoFj(() => summarizeFijos(FIJOS_ITEMS), []); // summary siempre del total
  const grouped = useMemoFj(() => groupByCat(items), [items]);

  return (
    <div className="screen" style={{ background:'#EFF5E8', overflowY:'auto' }}>
      <StatusBar color="#0F2A1E"/>

      {/* ambient */}
      <div style={{ position:'absolute', top:-60, right:-60, width:240, height:240, borderRadius:'50%',
        background:'radial-gradient(closest-side, rgba(141,212,106,0.25), transparent 70%)',
        pointerEvents:'none', animation:'mf-float-slow 10s ease-in-out infinite' }}/>
      <div style={{ position:'absolute', top:500, left:-80, width:220, height:220, borderRadius:'50%',
        background:'radial-gradient(closest-side, rgba(232,151,106,0.18), transparent 70%)',
        pointerEvents:'none', animation:'mf-float-slow 13s ease-in-out infinite', animationDelay:'-3s' }}/>

      {/* header */}
      <div style={{ padding:'2px 22px 0', display:'flex', alignItems:'flex-start', justifyContent:'space-between',
        animation:'mf-rise .6s ease both' }}>
        <div>
          <div className="sf-display" style={{ fontSize:34, fontWeight:800, color:'#0F2A1E', letterSpacing:-1.2, lineHeight:1 }}>
            Fijos
          </div>
          <div style={{ fontSize:13, color:'#6F7A73', marginTop:6, maxWidth:260 }}>
            Todo lo recurrente en un solo lugar
          </div>
        </div>
        <CircleBtnFjLt onClick={()=>setSheetOpen(true)} aria-label="Agregar fijo">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M12 5v14M5 12h14" stroke="#0F2A1E" strokeWidth="2.2" strokeLinecap="round"/></svg>
        </CircleBtnFjLt>
      </div>

      {/* HERO: ring del ciclo */}
      <CicloRingLt sum={sum}/>

      {/* alertas smart */}
      <SmartAlertsLt sum={sum} items={FIJOS_ITEMS}/>

      {/* upcoming (próximos 3) */}
      <UpcomingStripLt upcoming={sum.upcoming}/>

      {/* tabs */}
      <FjTabsLt tab={tab} setTab={setTab} sum={sum}/>

      {/* lista agrupada por categoría */}
      <div style={{ margin:'6px 22px 0', display:'flex', flexDirection:'column', gap:16 }}>
        {grouped.map((g, gi) => (
          <CatGroupLt key={g.id} group={g} delay={0.3 + gi*0.06}/>
        ))}
      </div>

      {/* bottom spacer */}
      <div style={{ height:120 }}/>

      <TabBar active="fijos" accent="#8DD66A" bg="#EFF5E8" onPlusClick={()=>setSheetOpen(true)}/>

      {/* modal agregar fijo */}
      {sheetOpen && <AddFijoSheet mode="light" onClose={()=>setSheetOpen(false)}/>}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// HERO · Ciclo ring (Light)
// Concept: dona SVG con arcs segmentados por estado (paid, pending, overdue).
// Centro: monto total + % cubierto. Debajo: días al próximo pago, sueldo libre.
// ─────────────────────────────────────────────────────────────
function CicloRingLt({ sum }) {
  const { total, paidAmt, pctPaid, pending, overdue, daysToPay } = sum;
  const R = 82;
  const C = 2 * Math.PI * R;
  const paidPct = paidAmt / total;
  const pendingAmt = pending.reduce((s,i)=>s+i.amount, 0);
  const overdueAmt = overdue.reduce((s,i)=>s+i.amount, 0);
  const pendingPct = pendingAmt / total;
  const overduePct = overdueAmt / total;

  // simulated "sueldo" para proyectar qué queda libre
  const sueldo = 2200000;
  const libre = sueldo - total;
  const pctFijos = Math.round((total / sueldo) * 100);

  return (
    <div style={{ margin:'14px 22px 0', background:'linear-gradient(135deg, #0F2A1E 0%, #143B2A 100%)',
      borderRadius:28, padding:'22px 22px 20px', color:'#F6FBEF', position:'relative', overflow:'hidden',
      boxShadow:'0 18px 40px -16px rgba(15,42,30,0.5)',
      animation:'mf-rise .8s .1s ease both' }}>

      {/* decorative grid */}
      <div style={{ position:'absolute', inset:0, pointerEvents:'none', opacity:0.5 }}>
        <div style={{ position:'absolute', top:-40, right:-40, width:200, height:200, borderRadius:'50%',
          background:'radial-gradient(closest-side, rgba(199,238,156,0.18), transparent 70%)' }}/>
        <div style={{ position:'absolute', bottom:-60, left:-40, width:180, height:180, borderRadius:'50%',
          background:'radial-gradient(closest-side, rgba(232,151,106,0.14), transparent 70%)' }}/>
      </div>

      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', position:'relative' }}>
        <div style={{ fontSize:11, letterSpacing:1.6, fontWeight:700, color:'#C7EE9C' }}>CICLO DE ABRIL</div>
        <div style={{ fontSize:10, color:'rgba(246,251,239,0.65)', fontWeight:600, padding:'3px 8px',
          background:'rgba(246,251,239,0.08)', borderRadius:999, border:'1px solid rgba(246,251,239,0.12)' }}>
          día {HOY_FJ} · {DAYS_MONTH_FJ - HOY_FJ}d restantes
        </div>
      </div>

      {/* ring + center stack */}
      <div style={{ display:'flex', alignItems:'center', gap:18, marginTop:14, position:'relative' }}>
        <div style={{ width:200, height:200, position:'relative', flexShrink:0 }}>
          <svg width="200" height="200" viewBox="0 0 200 200">
            <defs>
              <linearGradient id="fj-grad-paid" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#C7EE9C"/>
                <stop offset="100%" stopColor="#6FE09A"/>
              </linearGradient>
              <linearGradient id="fj-grad-pending" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#F2B58A"/>
                <stop offset="100%" stopColor="#E8976A"/>
              </linearGradient>
              <linearGradient id="fj-grad-overdue" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#D96A4F"/>
                <stop offset="100%" stopColor="#B84F35"/>
              </linearGradient>
            </defs>
            {/* base ring */}
            <circle cx="100" cy="100" r={R} fill="none" stroke="rgba(246,251,239,0.08)" strokeWidth="18"/>

            {/* arcs: paid | pending | overdue */}
            <g transform="rotate(-90 100 100)">
              <circle cx="100" cy="100" r={R} fill="none" stroke="url(#fj-grad-paid)"
                strokeWidth="18" strokeLinecap="round"
                strokeDasharray={`${C*paidPct} ${C}`}
                style={{ animation:'mf-fj-ring-paid 1.4s .3s cubic-bezier(.2,.9,.2,1) both',
                  transformOrigin:'100px 100px' }}/>
              <circle cx="100" cy="100" r={R} fill="none" stroke="url(#fj-grad-pending)"
                strokeWidth="18" strokeLinecap="round"
                strokeDasharray={`${C*pendingPct} ${C}`}
                strokeDashoffset={-C*paidPct}
                style={{ animation:'mf-fj-ring-pending 1.4s .6s cubic-bezier(.2,.9,.2,1) both' }}/>
              <circle cx="100" cy="100" r={R} fill="none" stroke="url(#fj-grad-overdue)"
                strokeWidth="18" strokeLinecap="round"
                strokeDasharray={`${C*overduePct} ${C}`}
                strokeDashoffset={-C*(paidPct + pendingPct)}
                style={{ animation:'mf-fj-ring-overdue 1.4s .9s cubic-bezier(.2,.9,.2,1) both' }}/>
            </g>

            {/* tick marks for days */}
            {Array.from({length: 12}).map((_,i) => {
              const angle = (i / 12) * 2 * Math.PI - Math.PI / 2;
              const x1 = 100 + (R - 14) * Math.cos(angle);
              const y1 = 100 + (R - 14) * Math.sin(angle);
              const x2 = 100 + (R - 10) * Math.cos(angle);
              const y2 = 100 + (R - 10) * Math.sin(angle);
              return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2}
                stroke="rgba(246,251,239,0.2)" strokeWidth="1" strokeLinecap="round"/>;
            })}
          </svg>

          {/* center content */}
          <div style={{ position:'absolute', inset:0, display:'flex', flexDirection:'column',
            alignItems:'center', justifyContent:'center', textAlign:'center' }}>
            <div style={{ fontSize:9, letterSpacing:1.4, fontWeight:700, color:'rgba(246,251,239,0.6)' }}>
              FIJOS · ABRIL
            </div>
            <div className="sf-display" style={{ fontSize:26, fontWeight:800, color:'#F6FBEF',
              letterSpacing:-1, lineHeight:1, marginTop:3 }}>
              <CountUp to={total} duration={1200} prefix="$"/>
            </div>
            <div style={{ marginTop:4, fontSize:11, color:'#C7EE9C', fontWeight:700 }}>
              <CountUp to={pctPaid} duration={1200} format={n=>n}/>% cubierto
            </div>
          </div>
        </div>

        {/* side: stats tiles */}
        <div style={{ flex:1, display:'flex', flexDirection:'column', gap:8 }}>
          <SideTileLt
            tint="#C7EE9C" icon="✓"
            value={`$${(paidAmt/1000).toFixed(0)}k`}
            label={`${sum.paid.length} pagados`}
          />
          <SideTileLt
            tint="#F2B58A" icon="◷"
            value={daysToPay != null ? `en ${daysToPay}d` : '—'}
            label={`${sum.pending.length} pendientes`}
            highlight
          />
          {overdueAmt > 0 && (
            <SideTileLt
              tint="#E88A70" icon="!"
              value={`$${(overdueAmt/1000).toFixed(0)}k`}
              label={`${overdue.length} vencido`}
              danger
            />
          )}
        </div>
      </div>

      {/* footer: sueldo libre proyectado */}
      <div style={{ marginTop:16, padding:'12px 14px', borderRadius:14,
        background:'rgba(246,251,239,0.06)', border:'1px solid rgba(246,251,239,0.08)',
        display:'flex', alignItems:'center', justifyContent:'space-between' }}>
        <div>
          <div style={{ fontSize:9, letterSpacing:1.4, fontWeight:700, color:'rgba(246,251,239,0.55)' }}>
            QUEDA LIBRE (tras fijos)
          </div>
          <div className="sf-display" style={{ fontSize:20, fontWeight:800, color:'#F6FBEF',
            letterSpacing:-0.5, marginTop:2 }}>
            ${libre.toLocaleString('es-AR')}
          </div>
        </div>
        <div style={{ flex:'0 0 auto', textAlign:'right' }}>
          <div style={{ fontSize:9, letterSpacing:1.4, fontWeight:700, color:'rgba(246,251,239,0.55)' }}>
            DE TU SUELDO
          </div>
          <div style={{ fontSize:14, fontWeight:700, color:'#F2B58A', marginTop:4 }}>
            {pctFijos}% en fijos
          </div>
          {/* mini stacked bar */}
          <div style={{ marginTop:4, width:90, height:5, background:'rgba(246,251,239,0.12)', borderRadius:3, overflow:'hidden', display:'flex' }}>
            <div style={{ width:`${pctFijos}%`, background:'linear-gradient(90deg, #F2B58A, #E8976A)',
              animation:'mf-grow-bar 1s .8s cubic-bezier(.2,.9,.2,1) both', transformOrigin:'left' }}/>
          </div>
        </div>
      </div>
    </div>
  );
}

function SideTileLt({ tint, icon, value, label, highlight, danger }) {
  return (
    <div style={{
      padding:'10px 12px', borderRadius:12,
      background: highlight
        ? 'linear-gradient(135deg, rgba(242,181,138,0.18), rgba(232,151,106,0.08))'
        : danger
        ? 'linear-gradient(135deg, rgba(217,106,79,0.22), rgba(184,79,53,0.1))'
        : 'rgba(246,251,239,0.06)',
      border: `1px solid ${highlight ? 'rgba(242,181,138,0.3)' : danger ? 'rgba(217,106,79,0.35)' : 'rgba(246,251,239,0.08)'}`,
      display:'flex', alignItems:'center', gap:10,
      animation:'mf-rise .6s .4s ease both',
    }}>
      <div style={{ width:28, height:28, borderRadius:8, background:`${tint}20`,
        display:'grid', placeItems:'center', color:tint, fontSize:14, fontWeight:800,
        border:`1px solid ${tint}44`, flexShrink:0 }}>
        {icon}
      </div>
      <div style={{ minWidth:0 }}>
        <div style={{ fontSize:14, fontWeight:800, color:'#F6FBEF', letterSpacing:-0.3, lineHeight:1 }}>{value}</div>
        <div style={{ fontSize:10, color:'rgba(246,251,239,0.55)', fontWeight:600, marginTop:2 }}>{label}</div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Smart alerts (light) — "subió X%", "zombi", "categoría dominante"
// ─────────────────────────────────────────────────────────────
function SmartAlertsLt({ sum, items }) {
  const subidas = items.filter(i => i.delta && i.delta > 5).slice(0, 2);
  const zombis = sum.zombis;
  const alerts = [];
  if (zombis.length > 0) {
    alerts.push({
      id:'zombi', type:'zombi',
      icon:'🧟',
      title: `${zombis.length} suscripción${zombis.length>1?'es':''} zombi`,
      body: 'Sin uso en 60 días. Podés revisar.',
      action:'Ver',
      tint:'#C9A6E0',
    });
  }
  if (subidas.length > 0) {
    const s = subidas[0];
    alerts.push({
      id:'subida', type:'subida',
      icon:'📈',
      title: `${s.name} subió ${s.delta}%`,
      body: `vs. promedio últimos 3 meses`,
      action:'Comparar',
      tint:'#F2B58A',
    });
  }
  if (alerts.length === 0) return null;

  return (
    <div style={{ padding:'14px 22px 0', display:'flex', gap:10, overflowX:'auto',
      animation:'mf-rise .8s .25s ease both', scrollbarWidth:'none' }}>
      {alerts.map((a, i) => (
        <div key={a.id} style={{
          flexShrink:0, minWidth:250,
          background: `linear-gradient(135deg, ${a.tint}18, ${a.tint}08)`,
          border: `1px solid ${a.tint}40`,
          borderRadius:16, padding:'12px 14px',
          display:'flex', alignItems:'center', gap:12,
          animation: `mf-rise .6s ${0.3 + i*0.08}s ease both`,
        }}>
          <div style={{ width:36, height:36, borderRadius:10, background:`${a.tint}25`,
            display:'grid', placeItems:'center', fontSize:18, flexShrink:0 }}>{a.icon}</div>
          <div style={{ flex:1, minWidth:0 }}>
            <div style={{ fontSize:13, fontWeight:700, color:'#0F2A1E', lineHeight:1.2 }}>{a.title}</div>
            <div style={{ fontSize:11, color:'#6F7A73', marginTop:2 }}>{a.body}</div>
          </div>
          <button style={{
            background:'transparent', border:'none', color:'#0F2A1E',
            fontSize:11, fontWeight:700, cursor:'pointer',
            padding:'6px 10px', borderRadius:999, flexShrink:0,
            border:'1px solid rgba(15,42,30,0.12)', fontFamily:'inherit',
          }}>{a.action}</button>
        </div>
      ))}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Upcoming strip: próximos 3 pagos (light)
// ─────────────────────────────────────────────────────────────
function UpcomingStripLt({ upcoming }) {
  if (upcoming.length === 0) return null;
  return (
    <div style={{ padding:'14px 22px 0', animation:'mf-rise .8s .3s ease both' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', marginBottom:8 }}>
        <div style={{ fontSize:10, letterSpacing:1.6, fontWeight:700, color:'#6F7A73' }}>
          PRÓXIMOS A VENCER
        </div>
        <div style={{ fontSize:11, color:'#6F7A73', fontWeight:600 }}>
          en los próximos {Math.max(...upcoming.map(u=>u.day-HOY_FJ))} días
        </div>
      </div>
      <div style={{ display:'flex', gap:8 }}>
        {upcoming.map((it, i) => {
          const cat = FIJOS_CATS.find(c=>c.id===it.cat);
          const dias = it.day - HOY_FJ;
          const urgent = dias <= 2;
          return (
            <div key={it.id} style={{
              flex:1, padding:'12px', borderRadius:14,
              background: urgent ? 'linear-gradient(135deg, #FADFC8, #F5C6B6)' : '#FFFBF2',
              border: urgent ? '1px solid #F2B58A' : '1px solid #EFE8D9',
              animation: `mf-rise .6s ${0.4 + i*0.08}s ease both`,
              position:'relative', overflow:'hidden',
            }}>
              <div style={{ fontSize:9, fontWeight:700, letterSpacing:1.2,
                color: urgent ? '#A3452A' : '#6F7A73' }}>
                {dias === 0 ? 'HOY' : dias === 1 ? 'MAÑANA' : `EN ${dias}D`}
              </div>
              <div style={{ fontSize:13, fontWeight:700, color:'#0F2A1E', marginTop:2,
                whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{it.name}</div>
              <div style={{ fontSize:14, fontWeight:800, color:'#0F2A1E', letterSpacing:-0.3, marginTop:4,
                fontFamily:'SF Pro Display, system-ui' }}>
                ${it.amount.toLocaleString('es-AR')}
              </div>
              <div style={{ position:'absolute', top:8, right:8, width:20, height:20, borderRadius:6,
                background:`${cat.color}22`, border:`1px solid ${cat.color}40`,
                display:'grid', placeItems:'center', fontSize:11 }}>
                {cat.emoji}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Tabs (light)
// ─────────────────────────────────────────────────────────────
function FjTabsLt({ tab, setTab, sum }) {
  const tabs = [
    { id:'todos',     label:'Todos',      count: FIJOS_ITEMS.length },
    { id:'pendientes',label:'Pendientes', count: sum.pending.length + sum.overdue.length, dot:'#E8976A' },
    { id:'pagados',   label:'Pagados',    count: sum.paid.length, dot:'#8DD66A' },
    { id:'zombis',    label:'Zombi',      count: sum.zombis.length, dot:'#C9A6E0' },
  ];
  return (
    <div style={{ padding:'16px 22px 0', display:'flex', gap:6, overflowX:'auto', scrollbarWidth:'none',
      animation:'mf-rise .8s .35s ease both' }}>
      {tabs.map(t => {
        const on = tab === t.id;
        return (
          <button key={t.id} onClick={()=>setTab(t.id)} style={{
            flexShrink:0, padding:'8px 14px', borderRadius:999, cursor:'pointer',
            background: on ? '#0F2A1E' : '#FFFBF2',
            color: on ? '#F6FBEF' : '#0F2A1E',
            border: on ? 'none' : '1px solid #EFE8D9',
            fontSize:13, fontWeight:700, fontFamily:'inherit',
            display:'flex', alignItems:'center', gap:6,
            transition:'transform .15s ease',
          }}>
            {t.dot && <span style={{ width:6, height:6, borderRadius:3, background:t.dot, display:'block' }}/>}
            {t.label}
            <span style={{ fontSize:11, fontWeight:700,
              color: on ? 'rgba(246,251,239,0.55)' : '#9AA39D',
              padding:'1px 6px', borderRadius:999,
              background: on ? 'rgba(246,251,239,0.1)' : '#EFF5E8' }}>{t.count}</span>
          </button>
        );
      })}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Category group (light)
// ─────────────────────────────────────────────────────────────
function CatGroupLt({ group, delay=0 }) {
  const [expanded, setExpanded] = useStateFj(true);
  return (
    <div style={{ animation:`mf-rise .6s ${delay}s ease both` }}>
      <button onClick={()=>setExpanded(e=>!e)} style={{
        width:'100%', background:'transparent', border:'none', cursor:'pointer',
        padding:'0 2px 8px', display:'flex', alignItems:'center', justifyContent:'space-between',
        fontFamily:'inherit',
      }}>
        <div style={{ display:'flex', alignItems:'center', gap:10 }}>
          <div style={{ width:32, height:32, borderRadius:10,
            background:`linear-gradient(135deg, ${group.color}28, ${group.color}12)`,
            display:'grid', placeItems:'center', fontSize:16,
            border:`1px solid ${group.color}40` }}>
            {group.emoji}
          </div>
          <div style={{ textAlign:'left' }}>
            <div style={{ fontSize:14, fontWeight:700, color:'#0F2A1E' }}>{group.label}</div>
            <div style={{ fontSize:11, color:'#6F7A73' }}>
              {group.items.length} ítem{group.items.length!==1?'s':''}
            </div>
          </div>
        </div>
        <div style={{ display:'flex', alignItems:'center', gap:8 }}>
          <div style={{ fontSize:14, fontWeight:800, color:'#0F2A1E', letterSpacing:-0.3 }}>
            ${group.total.toLocaleString('es-AR')}
          </div>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" style={{
            transform: expanded ? 'rotate(180deg)' : 'rotate(0)', transition:'transform .2s ease',
          }}>
            <path d="M6 9l6 6 6-6" stroke="#6F7A73" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>
      </button>
      {expanded && (
        <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
          {group.items.map((it, i) => (
            <FijoRowLt key={it.id} item={it} delay={delay + 0.1 + i*0.04}/>
          ))}
        </div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Fijo Row (light) — tap to expand details
// ─────────────────────────────────────────────────────────────
function FijoRowLt({ item, delay=0 }) {
  const cat = FIJOS_CATS.find(c=>c.id===item.cat);
  const who = FAMILY[item.who];
  const [open, setOpen] = useStateFj(false);

  const statusColor = item.status==='paid' ? '#2E7D5B'
                    : item.status==='overdue' ? '#C03A2A' : '#A3452A';
  const statusBg    = item.status==='paid' ? '#DDEFE3'
                    : item.status==='overdue' ? '#F5C6B6' : '#FADFC8';
  const statusLabel = item.status==='paid' ? 'Pagado'
                    : item.status==='overdue' ? 'Vencido' : 'Pendiente';

  const diasVenc = item.day - HOY_FJ;
  const vencLabel = item.status === 'paid'
    ? `Pagó día ${item.day}`
    : diasVenc < 0
    ? `Vencido hace ${Math.abs(diasVenc)}d`
    : diasVenc === 0
    ? 'Vence hoy'
    : `Vence en ${diasVenc}d`;

  return (
    <div onClick={()=>setOpen(o=>!o)} style={{
      background:'#FFFBF2', borderRadius:16, padding:'12px 14px',
      border:'1px solid #EFE8D9', cursor:'pointer',
      animation:`mf-rise .5s ${delay}s ease both`,
      transition:'transform .15s ease, box-shadow .15s ease',
      boxShadow: open ? '0 8px 20px -8px rgba(15,42,30,0.2)' : 'none',
    }}>
      <div style={{ display:'flex', alignItems:'center', gap:12 }}>
        <div style={{ position:'relative', width:40, height:40, flexShrink:0 }}>
          <div style={{ width:40, height:40, borderRadius:12,
            background:`linear-gradient(140deg, ${cat.color}22, ${cat.color}11)`,
            display:'grid', placeItems:'center', fontSize:18,
            border:`1px solid ${cat.color}33` }}>
            {cat.emoji}
          </div>
          {item.zombi && (
            <div style={{ position:'absolute', top:-4, right:-4, width:16, height:16, borderRadius:999,
              background:'#C9A6E0', border:'2px solid #FFFBF2',
              display:'grid', placeItems:'center', fontSize:9 }}>🧟</div>
          )}
        </div>
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ display:'flex', alignItems:'baseline', gap:8 }}>
            <div style={{ fontSize:14, fontWeight:700, color:'#0F2A1E', whiteSpace:'nowrap',
              overflow:'hidden', textOverflow:'ellipsis' }}>{item.name}</div>
            {item.delta && item.delta > 5 && (
              <span style={{ fontSize:9, fontWeight:700, color:'#A3452A',
                padding:'1px 6px', background:'#FADFC8', borderRadius:999,
                border:'1px solid #F2B58A66' }}>
                +{item.delta}%
              </span>
            )}
          </div>
          <div style={{ display:'flex', alignItems:'center', gap:6, marginTop:3,
            fontSize:11, color:'#6F7A73' }}>
            <span style={{ padding:'1px 7px', borderRadius:999, background:statusBg, color:statusColor,
              fontWeight:700, fontSize:10 }}>{statusLabel}</span>
            <span>·</span>
            <span>{vencLabel}</span>
            {item.cuotaIdx && (
              <>
                <span>·</span>
                <span>cuota {item.cuotaIdx}/{item.cuotaTot}</span>
              </>
            )}
          </div>
        </div>
        <div style={{ textAlign:'right', flexShrink:0 }}>
          <div className="sf-display" style={{ fontSize:16, fontWeight:800, color:'#0F2A1E', letterSpacing:-0.4 }}>
            ${item.amount.toLocaleString('es-AR')}
          </div>
          {/* sparkline */}
          <div style={{ marginTop:4, display:'flex', justifyContent:'flex-end' }}>
            <SparklineLt hist={item.hist} color={cat.color}/>
          </div>
        </div>
      </div>

      {open && (
        <div style={{ marginTop:12, paddingTop:12, borderTop:'1px dashed #E9E1D3',
          animation:'mf-fade .25s ease both' }}>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
            <DetailTileLt label="FRECUENCIA" value={item.freq}/>
            <DetailTileLt label="MÉTODO"     value={item.method}/>
            <DetailTileLt label="PAGA"       value={who.name} accent={who.color}/>
            <DetailTileLt label="CATEGORÍA"  value={cat.label}/>
          </div>
          <div style={{ marginTop:10, display:'flex', gap:6 }}>
            {item.status !== 'paid' && (
              <button style={{ flex:2, background:'#0F2A1E', color:'#F6FBEF', border:'none',
                padding:'10px', borderRadius:12, fontSize:13, fontWeight:700, cursor:'pointer',
                fontFamily:'inherit' }}>
                ✓ Registrar pago
              </button>
            )}
            <button style={{
              flex: item.status === 'paid' ? 2 : 1,
              background:'#EFF5E8', color:'#0F2A1E', border:'1px solid #D9D2C4',
              padding:'10px', borderRadius:12, fontSize:13, fontWeight:700, cursor:'pointer',
              fontFamily:'inherit' }}>
              Editar
            </button>
            <button style={{ flex:1, background:'#FFFBF2', color:'#6F7A73', border:'1px solid #E9E1D3',
              padding:'10px', borderRadius:12, fontSize:13, fontWeight:600, cursor:'pointer',
              fontFamily:'inherit' }}>
              Pausar
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function DetailTileLt({ label, value, accent }) {
  return (
    <div style={{ padding:'8px 10px', background:'#F6F1E4', borderRadius:10 }}>
      <div style={{ fontSize:9, letterSpacing:1.2, fontWeight:700, color:'#9AA39D' }}>{label}</div>
      <div style={{ fontSize:12, fontWeight:700, color: accent || '#0F2A1E', marginTop:2 }}>{value}</div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Sparkline — 3 months of history
// ─────────────────────────────────────────────────────────────
function SparklineLt({ hist, color }) {
  const max = Math.max(...hist);
  const min = Math.min(...hist);
  const range = max - min || 1;
  const W = 52, H = 18;
  const pts = hist.map((v, i) => {
    const x = (i / (hist.length - 1)) * W;
    const y = H - ((v - min) / range) * H;
    return [x, y];
  });
  const path = pts.map((p,i) => `${i===0?'M':'L'}${p[0].toFixed(1)} ${p[1].toFixed(1)}`).join(' ');
  return (
    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{ display:'block' }}>
      <path d={path} fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      <circle cx={pts[pts.length-1][0]} cy={pts[pts.length-1][1]} r="2" fill={color}/>
    </svg>
  );
}

function CircleBtnFjLt({ children, onClick, ...rest }) {
  return <button onClick={onClick} {...rest} style={{
    width:38, height:38, border:'none', borderRadius:999, background:'#FFFBF2',
    display:'grid', placeItems:'center', cursor:'pointer',
    boxShadow:'0 2px 6px rgba(15,42,30,0.08)', fontFamily:'inherit',
  }}>{children}</button>;
}

// ─────────────────────────────────────────────────────────────
// FIJOS · DARK (mirror)
// ─────────────────────────────────────────────────────────────
function FijosDark() {
  const [tab, setTab] = useStateFj('todos');
  const [sheetOpen, setSheetOpen] = useStateFj(false);
  const items = useMemoFj(() => {
    if (tab === 'pendientes') return FIJOS_ITEMS.filter(i => i.status === 'pending' || i.status === 'overdue');
    if (tab === 'pagados')    return FIJOS_ITEMS.filter(i => i.status === 'paid');
    if (tab === 'zombis')     return FIJOS_ITEMS.filter(i => i.zombi);
    return FIJOS_ITEMS;
  }, [tab]);
  const sum = useMemoFj(() => summarizeFijos(FIJOS_ITEMS), []);
  const grouped = useMemoFj(() => groupByCat(items), [items]);

  return (
    <div className="screen" style={{ background:'#0A1410', overflowY:'auto' }}>
      <StatusBar color="#F6FBEF"/>

      <div style={{ position:'absolute', top:-70, right:-50, width:260, height:260, borderRadius:'50%',
        background:'radial-gradient(closest-side, rgba(111,224,154,0.22), transparent 70%)',
        animation:'mf-float-slow 9s ease-in-out infinite', pointerEvents:'none' }}/>
      <div style={{ position:'absolute', top:700, left:-70, width:220, height:220, borderRadius:'50%',
        background:'radial-gradient(closest-side, rgba(232,151,106,0.18), transparent 70%)',
        animation:'mf-float-slow 11s ease-in-out infinite', animationDelay:'-3s', pointerEvents:'none' }}/>

      <div style={{ padding:'2px 22px 0', display:'flex', alignItems:'flex-start', justifyContent:'space-between',
        animation:'mf-rise .6s ease both' }}>
        <div>
          <div className="sf-display" style={{ fontSize:34, fontWeight:800, color:'#F6FBEF', letterSpacing:-1.2, lineHeight:1 }}>
            Fijos
          </div>
          <div style={{ fontSize:13, color:'#8FA094', marginTop:6, maxWidth:260 }}>
            Todo lo recurrente en un solo lugar
          </div>
        </div>
        <CircleBtnFjDk onClick={()=>setSheetOpen(true)} aria-label="Agregar fijo">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M12 5v14M5 12h14" stroke="#F6FBEF" strokeWidth="2.2" strokeLinecap="round"/></svg>
        </CircleBtnFjDk>
      </div>

      <CicloRingDk sum={sum}/>

      <SmartAlertsDk sum={sum} items={FIJOS_ITEMS}/>

      <UpcomingStripDk upcoming={sum.upcoming}/>

      <FjTabsDk tab={tab} setTab={setTab} sum={sum}/>

      <div style={{ margin:'6px 22px 0', display:'flex', flexDirection:'column', gap:16 }}>
        {grouped.map((g, gi) => (
          <CatGroupDk key={g.id} group={g} delay={0.3 + gi*0.06}/>
        ))}
      </div>

      <div style={{ height:120 }}/>

      <TabBarGxDk active="fijos" onPlusClick={()=>setSheetOpen(true)}/>

      {sheetOpen && <AddFijoSheet mode="dark" onClose={()=>setSheetOpen(false)}/>}
    </div>
  );
}

// CicloRingDk — same logic, dark shell
function CicloRingDk({ sum }) {
  const { total, paidAmt, pctPaid, pending, overdue, daysToPay } = sum;
  const R = 82;
  const C = 2 * Math.PI * R;
  const paidPct = paidAmt / total;
  const pendingAmt = pending.reduce((s,i)=>s+i.amount, 0);
  const overdueAmt = overdue.reduce((s,i)=>s+i.amount, 0);
  const pendingPct = pendingAmt / total;
  const overduePct = overdueAmt / total;
  const sueldo = 2200000;
  const libre = sueldo - total;
  const pctFijos = Math.round((total / sueldo) * 100);

  return (
    <div style={{ margin:'14px 22px 0',
      background:'linear-gradient(135deg, #13221B 0%, #0E1A15 100%)',
      borderRadius:28, padding:'22px 22px 20px', color:'#F6FBEF', position:'relative', overflow:'hidden',
      border:'1px solid #1F332A',
      boxShadow:'0 18px 40px -16px rgba(0,0,0,0.6), inset 0 1px 0 rgba(246,251,239,0.04)',
      animation:'mf-rise .8s .1s ease both' }}>

      <div style={{ position:'absolute', inset:0, pointerEvents:'none', opacity:0.7 }}>
        <div style={{ position:'absolute', top:-40, right:-40, width:200, height:200, borderRadius:'50%',
          background:'radial-gradient(closest-side, rgba(199,238,156,0.25), transparent 70%)' }}/>
        <div style={{ position:'absolute', bottom:-60, left:-40, width:180, height:180, borderRadius:'50%',
          background:'radial-gradient(closest-side, rgba(232,151,106,0.18), transparent 70%)' }}/>
      </div>

      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', position:'relative' }}>
        <div style={{ fontSize:11, letterSpacing:1.6, fontWeight:700, color:'#C7EE9C' }}>CICLO DE ABRIL</div>
        <div style={{ fontSize:10, color:'rgba(246,251,239,0.65)', fontWeight:600, padding:'3px 8px',
          background:'rgba(246,251,239,0.06)', borderRadius:999, border:'1px solid rgba(246,251,239,0.1)' }}>
          día {HOY_FJ} · {DAYS_MONTH_FJ - HOY_FJ}d restantes
        </div>
      </div>

      <div style={{ display:'flex', alignItems:'center', gap:18, marginTop:14, position:'relative' }}>
        <div style={{ width:200, height:200, position:'relative', flexShrink:0 }}>
          <svg width="200" height="200" viewBox="0 0 200 200">
            <defs>
              <linearGradient id="fj-dk-grad-paid" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#C7EE9C"/>
                <stop offset="100%" stopColor="#6FE09A"/>
              </linearGradient>
              <linearGradient id="fj-dk-grad-pending" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#F2B58A"/>
                <stop offset="100%" stopColor="#E8976A"/>
              </linearGradient>
              <linearGradient id="fj-dk-grad-overdue" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#E88A70"/>
                <stop offset="100%" stopColor="#D96A4F"/>
              </linearGradient>
            </defs>
            <circle cx="100" cy="100" r={R} fill="none" stroke="rgba(246,251,239,0.06)" strokeWidth="18"/>
            <g transform="rotate(-90 100 100)">
              <circle cx="100" cy="100" r={R} fill="none" stroke="url(#fj-dk-grad-paid)"
                strokeWidth="18" strokeLinecap="round"
                strokeDasharray={`${C*paidPct} ${C}`}
                style={{ animation:'mf-fj-ring-paid 1.4s .3s cubic-bezier(.2,.9,.2,1) both' }}/>
              <circle cx="100" cy="100" r={R} fill="none" stroke="url(#fj-dk-grad-pending)"
                strokeWidth="18" strokeLinecap="round"
                strokeDasharray={`${C*pendingPct} ${C}`}
                strokeDashoffset={-C*paidPct}
                style={{ animation:'mf-fj-ring-pending 1.4s .6s cubic-bezier(.2,.9,.2,1) both' }}/>
              <circle cx="100" cy="100" r={R} fill="none" stroke="url(#fj-dk-grad-overdue)"
                strokeWidth="18" strokeLinecap="round"
                strokeDasharray={`${C*overduePct} ${C}`}
                strokeDashoffset={-C*(paidPct + pendingPct)}
                style={{ animation:'mf-fj-ring-overdue 1.4s .9s cubic-bezier(.2,.9,.2,1) both' }}/>
            </g>
            {Array.from({length: 12}).map((_,i) => {
              const angle = (i / 12) * 2 * Math.PI - Math.PI / 2;
              const x1 = 100 + (R - 14) * Math.cos(angle);
              const y1 = 100 + (R - 14) * Math.sin(angle);
              const x2 = 100 + (R - 10) * Math.cos(angle);
              const y2 = 100 + (R - 10) * Math.sin(angle);
              return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2}
                stroke="rgba(246,251,239,0.22)" strokeWidth="1" strokeLinecap="round"/>;
            })}
          </svg>

          <div style={{ position:'absolute', inset:0, display:'flex', flexDirection:'column',
            alignItems:'center', justifyContent:'center', textAlign:'center' }}>
            <div style={{ fontSize:9, letterSpacing:1.4, fontWeight:700, color:'rgba(246,251,239,0.55)' }}>
              FIJOS · ABRIL
            </div>
            <div className="sf-display" style={{ fontSize:26, fontWeight:800, color:'#F6FBEF',
              letterSpacing:-1, lineHeight:1, marginTop:3,
              textShadow:'0 0 16px rgba(199,238,156,0.3)' }}>
              <CountUp to={total} duration={1200} prefix="$"/>
            </div>
            <div style={{ marginTop:4, fontSize:11, color:'#C7EE9C', fontWeight:700 }}>
              <CountUp to={pctPaid} duration={1200} format={n=>n}/>% cubierto
            </div>
          </div>
        </div>

        <div style={{ flex:1, display:'flex', flexDirection:'column', gap:8 }}>
          <SideTileDk
            tint="#C7EE9C" icon="✓"
            value={`$${(paidAmt/1000).toFixed(0)}k`}
            label={`${sum.paid.length} pagados`}
          />
          <SideTileDk
            tint="#F2B58A" icon="◷"
            value={daysToPay != null ? `en ${daysToPay}d` : '—'}
            label={`${sum.pending.length} pendientes`}
            highlight
          />
          {overdueAmt > 0 && (
            <SideTileDk
              tint="#E88A70" icon="!"
              value={`$${(overdueAmt/1000).toFixed(0)}k`}
              label={`${overdue.length} vencido`}
              danger
            />
          )}
        </div>
      </div>

      <div style={{ marginTop:16, padding:'12px 14px', borderRadius:14,
        background:'rgba(246,251,239,0.04)', border:'1px solid rgba(246,251,239,0.08)',
        display:'flex', alignItems:'center', justifyContent:'space-between' }}>
        <div>
          <div style={{ fontSize:9, letterSpacing:1.4, fontWeight:700, color:'rgba(246,251,239,0.5)' }}>
            QUEDA LIBRE (tras fijos)
          </div>
          <div className="sf-display" style={{ fontSize:20, fontWeight:800, color:'#F6FBEF',
            letterSpacing:-0.5, marginTop:2 }}>
            ${libre.toLocaleString('es-AR')}
          </div>
        </div>
        <div style={{ flex:'0 0 auto', textAlign:'right' }}>
          <div style={{ fontSize:9, letterSpacing:1.4, fontWeight:700, color:'rgba(246,251,239,0.5)' }}>
            DE TU SUELDO
          </div>
          <div style={{ fontSize:14, fontWeight:700, color:'#F2B58A', marginTop:4 }}>
            {pctFijos}% en fijos
          </div>
          <div style={{ marginTop:4, width:90, height:5, background:'rgba(246,251,239,0.08)', borderRadius:3, overflow:'hidden', display:'flex' }}>
            <div style={{ width:`${pctFijos}%`, background:'linear-gradient(90deg, #F2B58A, #E8976A)',
              animation:'mf-grow-bar 1s .8s cubic-bezier(.2,.9,.2,1) both', transformOrigin:'left' }}/>
          </div>
        </div>
      </div>
    </div>
  );
}

function SideTileDk({ tint, icon, value, label, highlight, danger }) {
  return (
    <div style={{
      padding:'10px 12px', borderRadius:12,
      background: highlight
        ? 'linear-gradient(135deg, rgba(242,181,138,0.15), rgba(232,151,106,0.06))'
        : danger
        ? 'linear-gradient(135deg, rgba(232,138,112,0.2), rgba(217,106,79,0.08))'
        : 'rgba(246,251,239,0.04)',
      border: `1px solid ${highlight ? 'rgba(242,181,138,0.28)' : danger ? 'rgba(232,138,112,0.32)' : 'rgba(246,251,239,0.08)'}`,
      display:'flex', alignItems:'center', gap:10,
      animation:'mf-rise .6s .4s ease both',
    }}>
      <div style={{ width:28, height:28, borderRadius:8, background:`${tint}1a`,
        display:'grid', placeItems:'center', color:tint, fontSize:14, fontWeight:800,
        border:`1px solid ${tint}40`, flexShrink:0 }}>
        {icon}
      </div>
      <div style={{ minWidth:0 }}>
        <div style={{ fontSize:14, fontWeight:800, color:'#F6FBEF', letterSpacing:-0.3, lineHeight:1 }}>{value}</div>
        <div style={{ fontSize:10, color:'rgba(246,251,239,0.55)', fontWeight:600, marginTop:2 }}>{label}</div>
      </div>
    </div>
  );
}

function SmartAlertsDk({ sum, items }) {
  const subidas = items.filter(i => i.delta && i.delta > 5).slice(0, 2);
  const zombis = sum.zombis;
  const alerts = [];
  if (zombis.length > 0) {
    alerts.push({
      id:'zombi', icon:'🧟',
      title: `${zombis.length} suscripción${zombis.length>1?'es':''} zombi`,
      body: 'Sin uso en 60 días. Podés revisar.', action:'Ver',
      tint:'#C9A6E0',
    });
  }
  if (subidas.length > 0) {
    const s = subidas[0];
    alerts.push({
      id:'subida', icon:'📈',
      title: `${s.name} subió ${s.delta}%`,
      body: `vs. promedio últimos 3 meses`, action:'Comparar',
      tint:'#F2B58A',
    });
  }
  if (alerts.length === 0) return null;

  return (
    <div style={{ padding:'14px 22px 0', display:'flex', gap:10, overflowX:'auto',
      animation:'mf-rise .8s .25s ease both', scrollbarWidth:'none' }}>
      {alerts.map((a, i) => (
        <div key={a.id} style={{
          flexShrink:0, minWidth:250,
          background: `linear-gradient(135deg, ${a.tint}25, ${a.tint}10)`,
          border: `1px solid ${a.tint}50`,
          borderRadius:16, padding:'12px 14px',
          display:'flex', alignItems:'center', gap:12,
          animation: `mf-rise .6s ${0.3 + i*0.08}s ease both`,
        }}>
          <div style={{ width:36, height:36, borderRadius:10, background:`${a.tint}30`,
            display:'grid', placeItems:'center', fontSize:18, flexShrink:0 }}>{a.icon}</div>
          <div style={{ flex:1, minWidth:0 }}>
            <div style={{ fontSize:13, fontWeight:700, color:'#F6FBEF', lineHeight:1.2 }}>{a.title}</div>
            <div style={{ fontSize:11, color:'#8FA094', marginTop:2 }}>{a.body}</div>
          </div>
          <button style={{
            background:'transparent', color:'#F6FBEF',
            fontSize:11, fontWeight:700, cursor:'pointer',
            padding:'6px 10px', borderRadius:999, flexShrink:0,
            border:'1px solid rgba(246,251,239,0.2)', fontFamily:'inherit',
          }}>{a.action}</button>
        </div>
      ))}
    </div>
  );
}

function UpcomingStripDk({ upcoming }) {
  if (upcoming.length === 0) return null;
  return (
    <div style={{ padding:'14px 22px 0', animation:'mf-rise .8s .3s ease both' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', marginBottom:8 }}>
        <div style={{ fontSize:10, letterSpacing:1.6, fontWeight:700, color:'#8FA094' }}>
          PRÓXIMOS A VENCER
        </div>
        <div style={{ fontSize:11, color:'#8FA094', fontWeight:600 }}>
          en los próximos {Math.max(...upcoming.map(u=>u.day-HOY_FJ))} días
        </div>
      </div>
      <div style={{ display:'flex', gap:8 }}>
        {upcoming.map((it, i) => {
          const cat = FIJOS_CATS.find(c=>c.id===it.cat);
          const dias = it.day - HOY_FJ;
          const urgent = dias <= 2;
          return (
            <div key={it.id} style={{
              flex:1, padding:'12px', borderRadius:14,
              background: urgent ? 'linear-gradient(135deg, #4A201A, #3A2A22)' : '#13221B',
              border: urgent ? '1px solid #E88A70' : '1px solid #1F332A',
              animation: `mf-rise .6s ${0.4 + i*0.08}s ease both`,
              position:'relative', overflow:'hidden',
            }}>
              <div style={{ fontSize:9, fontWeight:700, letterSpacing:1.2,
                color: urgent ? '#F2B58A' : '#8FA094' }}>
                {dias === 0 ? 'HOY' : dias === 1 ? 'MAÑANA' : `EN ${dias}D`}
              </div>
              <div style={{ fontSize:13, fontWeight:700, color:'#F6FBEF', marginTop:2,
                whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{it.name}</div>
              <div className="sf-display" style={{ fontSize:14, fontWeight:800, color:'#F6FBEF', letterSpacing:-0.3, marginTop:4 }}>
                ${it.amount.toLocaleString('es-AR')}
              </div>
              <div style={{ position:'absolute', top:8, right:8, width:20, height:20, borderRadius:6,
                background:`${cat.color}22`, border:`1px solid ${cat.color}40`,
                display:'grid', placeItems:'center', fontSize:11 }}>
                {cat.emoji}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function FjTabsDk({ tab, setTab, sum }) {
  const tabs = [
    { id:'todos',     label:'Todos',      count: FIJOS_ITEMS.length },
    { id:'pendientes',label:'Pendientes', count: sum.pending.length + sum.overdue.length, dot:'#E8976A' },
    { id:'pagados',   label:'Pagados',    count: sum.paid.length, dot:'#8DD66A' },
    { id:'zombis',    label:'Zombi',      count: sum.zombis.length, dot:'#C9A6E0' },
  ];
  return (
    <div style={{ padding:'16px 22px 0', display:'flex', gap:6, overflowX:'auto', scrollbarWidth:'none',
      animation:'mf-rise .8s .35s ease both' }}>
      {tabs.map(t => {
        const on = tab === t.id;
        return (
          <button key={t.id} onClick={()=>setTab(t.id)} style={{
            flexShrink:0, padding:'8px 14px', borderRadius:999, cursor:'pointer',
            background: on ? 'linear-gradient(140deg,#C7EE9C,#8DD66A)' : '#13221B',
            color: on ? '#0A1410' : '#F6FBEF',
            border: on ? 'none' : '1px solid #1F332A',
            fontSize:13, fontWeight:700, fontFamily:'inherit',
            display:'flex', alignItems:'center', gap:6,
          }}>
            {t.dot && <span style={{ width:6, height:6, borderRadius:3, background:t.dot, display:'block' }}/>}
            {t.label}
            <span style={{ fontSize:11, fontWeight:700,
              color: on ? 'rgba(10,20,16,0.65)' : '#8FA094',
              padding:'1px 6px', borderRadius:999,
              background: on ? 'rgba(10,20,16,0.15)' : '#0E1A15' }}>{t.count}</span>
          </button>
        );
      })}
    </div>
  );
}

function CatGroupDk({ group, delay=0 }) {
  const [expanded, setExpanded] = useStateFj(true);
  return (
    <div style={{ animation:`mf-rise .6s ${delay}s ease both` }}>
      <button onClick={()=>setExpanded(e=>!e)} style={{
        width:'100%', background:'transparent', border:'none', cursor:'pointer',
        padding:'0 2px 8px', display:'flex', alignItems:'center', justifyContent:'space-between',
        fontFamily:'inherit',
      }}>
        <div style={{ display:'flex', alignItems:'center', gap:10 }}>
          <div style={{ width:32, height:32, borderRadius:10,
            background:`linear-gradient(135deg, ${group.color}30, ${group.color}12)`,
            display:'grid', placeItems:'center', fontSize:16,
            border:`1px solid ${group.color}40` }}>
            {group.emoji}
          </div>
          <div style={{ textAlign:'left' }}>
            <div style={{ fontSize:14, fontWeight:700, color:'#F6FBEF' }}>{group.label}</div>
            <div style={{ fontSize:11, color:'#8FA094' }}>
              {group.items.length} ítem{group.items.length!==1?'s':''}
            </div>
          </div>
        </div>
        <div style={{ display:'flex', alignItems:'center', gap:8 }}>
          <div style={{ fontSize:14, fontWeight:800, color:'#F6FBEF', letterSpacing:-0.3 }}>
            ${group.total.toLocaleString('es-AR')}
          </div>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" style={{
            transform: expanded ? 'rotate(180deg)' : 'rotate(0)', transition:'transform .2s ease',
          }}>
            <path d="M6 9l6 6 6-6" stroke="#8FA094" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>
      </button>
      {expanded && (
        <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
          {group.items.map((it, i) => (
            <FijoRowDk key={it.id} item={it} delay={delay + 0.1 + i*0.04}/>
          ))}
        </div>
      )}
    </div>
  );
}

function FijoRowDk({ item, delay=0 }) {
  const cat = FIJOS_CATS.find(c=>c.id===item.cat);
  const who = FAMILY[item.who];
  const [open, setOpen] = useStateFj(false);

  const statusColor = item.status==='paid' ? '#9EE0B2'
                    : item.status==='overdue' ? '#E88A70' : '#F2B58A';
  const statusBg    = item.status==='paid' ? '#1F4F30'
                    : item.status==='overdue' ? '#4A201A' : '#3A2A22';
  const statusLabel = item.status==='paid' ? 'Pagado'
                    : item.status==='overdue' ? 'Vencido' : 'Pendiente';

  const diasVenc = item.day - HOY_FJ;
  const vencLabel = item.status === 'paid'
    ? `Pagó día ${item.day}`
    : diasVenc < 0 ? `Vencido hace ${Math.abs(diasVenc)}d`
    : diasVenc === 0 ? 'Vence hoy'
    : `Vence en ${diasVenc}d`;

  return (
    <div onClick={()=>setOpen(o=>!o)} style={{
      background:'#13221B', borderRadius:16, padding:'12px 14px',
      border:'1px solid #1F332A', cursor:'pointer',
      animation:`mf-rise .5s ${delay}s ease both`,
      transition:'transform .15s ease, box-shadow .15s ease',
      boxShadow: open ? '0 10px 28px -8px rgba(0,0,0,0.5)' : 'none',
    }}>
      <div style={{ display:'flex', alignItems:'center', gap:12 }}>
        <div style={{ position:'relative', width:40, height:40, flexShrink:0 }}>
          <div style={{ width:40, height:40, borderRadius:12,
            background:`linear-gradient(140deg, ${cat.color}28, ${cat.color}12)`,
            display:'grid', placeItems:'center', fontSize:18,
            border:`1px solid ${cat.color}40` }}>
            {cat.emoji}
          </div>
          {item.zombi && (
            <div style={{ position:'absolute', top:-4, right:-4, width:16, height:16, borderRadius:999,
              background:'#C9A6E0', border:'2px solid #13221B',
              display:'grid', placeItems:'center', fontSize:9 }}>🧟</div>
          )}
        </div>
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ display:'flex', alignItems:'baseline', gap:8 }}>
            <div style={{ fontSize:14, fontWeight:700, color:'#F6FBEF', whiteSpace:'nowrap',
              overflow:'hidden', textOverflow:'ellipsis' }}>{item.name}</div>
            {item.delta && item.delta > 5 && (
              <span style={{ fontSize:9, fontWeight:700, color:'#F2B58A',
                padding:'1px 6px', background:'#3A2A22', borderRadius:999,
                border:'1px solid #F2B58A44' }}>
                +{item.delta}%
              </span>
            )}
          </div>
          <div style={{ display:'flex', alignItems:'center', gap:6, marginTop:3,
            fontSize:11, color:'#8FA094' }}>
            <span style={{ padding:'1px 7px', borderRadius:999, background:statusBg, color:statusColor,
              fontWeight:700, fontSize:10 }}>{statusLabel}</span>
            <span>·</span>
            <span>{vencLabel}</span>
            {item.cuotaIdx && (
              <>
                <span>·</span>
                <span>cuota {item.cuotaIdx}/{item.cuotaTot}</span>
              </>
            )}
          </div>
        </div>
        <div style={{ textAlign:'right', flexShrink:0 }}>
          <div className="sf-display" style={{ fontSize:16, fontWeight:800, color:'#F6FBEF', letterSpacing:-0.4 }}>
            ${item.amount.toLocaleString('es-AR')}
          </div>
          <div style={{ marginTop:4, display:'flex', justifyContent:'flex-end' }}>
            <SparklineLt hist={item.hist} color={cat.color}/>
          </div>
        </div>
      </div>

      {open && (
        <div style={{ marginTop:12, paddingTop:12, borderTop:'1px dashed #1F332A',
          animation:'mf-fade .25s ease both' }}>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
            <DetailTileDk label="FRECUENCIA" value={item.freq}/>
            <DetailTileDk label="MÉTODO"     value={item.method}/>
            <DetailTileDk label="PAGA"       value={who.name} accent={who.color}/>
            <DetailTileDk label="CATEGORÍA"  value={cat.label}/>
          </div>
          <div style={{ marginTop:10, display:'flex', gap:6 }}>
            {item.status !== 'paid' && (
              <button style={{ flex:2, background:'linear-gradient(140deg,#C7EE9C,#8DD66A)', color:'#0A1410', border:'none',
                padding:'10px', borderRadius:12, fontSize:13, fontWeight:700, cursor:'pointer', fontFamily:'inherit' }}>
                ✓ Registrar pago
              </button>
            )}
            <button style={{
              flex: item.status === 'paid' ? 2 : 1,
              background:'#0E1A15', color:'#F6FBEF', border:'1px solid #1F332A',
              padding:'10px', borderRadius:12, fontSize:13, fontWeight:700, cursor:'pointer', fontFamily:'inherit' }}>
              Editar
            </button>
            <button style={{ flex:1, background:'#13221B', color:'#8FA094', border:'1px solid #1F332A',
              padding:'10px', borderRadius:12, fontSize:13, fontWeight:600, cursor:'pointer', fontFamily:'inherit' }}>
              Pausar
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function DetailTileDk({ label, value, accent }) {
  return (
    <div style={{ padding:'8px 10px', background:'#0E1A15', borderRadius:10, border:'1px solid #1F332A' }}>
      <div style={{ fontSize:9, letterSpacing:1.2, fontWeight:700, color:'#6A7A70' }}>{label}</div>
      <div style={{ fontSize:12, fontWeight:700, color: accent || '#F6FBEF', marginTop:2 }}>{value}</div>
    </div>
  );
}

function CircleBtnFjDk({ children, onClick, ...rest }) {
  return <button onClick={onClick} {...rest} style={{
    width:38, height:38, border:'1px solid #1F332A', borderRadius:999, background:'#13221B',
    display:'grid', placeItems:'center', cursor:'pointer',
    boxShadow:'0 2px 8px rgba(0,0,0,0.35)', fontFamily:'inherit',
  }}>{children}</button>;
}

// TabBar dark variant (reuse from gastos)
function TabBarGxDk({ active='fijos', onPlusClick }) {
  const item = (key, label, icon, lines) => {
    const on = key === active;
    return (
      <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:4, flex:1, opacity: on ? 1 : 0.55 }}>
        <div style={{ width:22, height:22, display:'grid', placeItems:'center', color:'#F6FBEF' }}>{icon}</div>
        <div style={{ fontSize:11, fontWeight: on ? 700 : 500, color:'#F6FBEF', lineHeight:1.1, textAlign:'center' }}>
          {lines ? lines.map((l,i)=> <div key={i}>{l}</div>) : label}
        </div>
      </div>
    );
  };
  return (
    <div style={{
      position:'absolute', left:0, right:0, bottom:0, height:96,
      background:'#0E1A15', borderTop:'1px solid rgba(246,251,239,0.06)',
      display:'flex', alignItems:'flex-start', justifyContent:'space-between',
      padding:'14px 18px 0', zIndex:10,
    }}>
      {item('inicio','Inicio',
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M3 11l9-7 9 7v9a2 2 0 01-2 2h-4v-6h-6v6H5a2 2 0 01-2-2v-9z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round"/></svg>
      )}
      {item('gastos','Gastos',
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><rect x="5" y="3" width="14" height="18" rx="2" stroke="currentColor" strokeWidth="1.8"/><path d="M8 8h8M8 12h8M8 16h5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg>
      )}
      <div style={{ width:64, display:'flex', justifyContent:'center' }}>
        <button onClick={onPlusClick} style={{
          width:56, height:56, borderRadius:999,
          background:'linear-gradient(140deg,#C7EE9C,#8DD66A)', color:'#0A1410',
          display:'grid', placeItems:'center', fontSize:28, fontWeight:700, marginTop:-18,
          boxShadow:'0 10px 28px rgba(0,0,0,0.5), 0 0 0 4px #0A1410',
          animation:'mf-breathe 3.2s ease-in-out infinite',
          border:'none', cursor: onPlusClick ? 'pointer' : 'default', fontFamily:'inherit',
        }}>+</button>
      </div>
      {item('fijos',null,
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><rect x="3" y="5" width="18" height="15" rx="2" stroke="currentColor" strokeWidth="1.8"/><path d="M3 9h18M8 3v4M16 3v4" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg>,
        ['Gastos','Fijos']
      )}
      {item('control','Control',
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M3 17l5-6 4 3 7-8" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/><path d="M14 6h5v5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg>
      )}
    </div>
  );
}

// export
Object.assign(window, { FijosLight, FijosDark, FIJOS_ITEMS, FIJOS_CATS });
