// Design tokens shared across variants — palette extends the original app
// (deep forest green + cream) with warm peach/apricot accents.

const T = {
  // greens (from original)
  greenInk:   '#0F2A1E',   // near-black green (deep hero card)
  greenDark:  '#143B2A',
  greenMid:   '#2E7D5B',
  greenAcc:   '#6FE09A',   // bright mint (the + registrar)
  greenSoft:  '#DDEFE3',   // very soft green tint for bgs
  greenGlow:  '#9EE5BA',

  // warm accents (new)
  cream:      '#F6EFE3',   // page bg
  creamSoft:  '#FAF4EA',
  creamCard:  '#FFFBF2',
  peach:      '#F2B58A',
  peachSoft:  '#FADFC8',
  clay:       '#E08E63',
  butter:     '#F1D690',
  plum:       '#6B3A4F',

  // ink
  ink:        '#0E1A14',
  ink2:       '#2A3A31',
  muted:      '#6F7A73',
  mutedSoft:  '#9AA39D',
  line:       '#E9E1D3',
  lineSoft:   '#EFE8D9',

  // semantic
  up:         '#2CAE6E',
  down:       '#D96A4F',
};

window.T = T;
