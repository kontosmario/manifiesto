// V1 Dark — variante nocturna de V1 Core
// Misma arquitectura, paleta oscura cálida con verdes profundos y acentos lima/durazno

const { useEffect: useEffectDk, useState: useStateDk, useRef: useRefDk } = React;

// ─────────────────────────────────────────────────────────────
// Greeting (dark)
// ─────────────────────────────────────────────────────────────
function GreetingHeaderDk({ name = 'Mario', hour = 22 }) {
  const g = hour < 6  ? { t:'Buenas noches,',  icon:<MoonIconDk/> }
         : hour < 12  ? { t:'Buen día,',       icon:<SunIconDk/> }
         : hour < 19  ? { t:'Buenas tardes,',  icon:<SunLowIconDk/> }
         :              { t:'Buenas noches,',  icon:<MoonIconDk/> };
  return (
    <div style={{ padding:'2px 22px 0', animation:'mf-rise .7s ease both' }}>
      <div style={{ display:'flex', alignItems:'center', gap:8, color:'#8FA094', fontSize:14, fontWeight:500 }}>
        <div style={{ width:22, height:22, display:'grid', placeItems:'center', animation:'mf-float-slow 5s ease-in-out infinite' }}>{g.icon}</div>
        {g.t}
      </div>
      <div className="sf-display" style={{
        fontSize:34, lineHeight:1.05, fontWeight:800, color:'#F6FBEF', marginTop:2, letterSpacing:-1.2,
      }}>
        Hola, {name}
      </div>
    </div>
  );
}
const SunIconDk    = () => <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="4" fill="#F2B58A"/><g stroke="#F2B58A" strokeWidth="1.8" strokeLinecap="round"><path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.5 5.5l1.4 1.4M17.1 17.1l1.4 1.4M5.5 18.5l1.4-1.4M17.1 6.9l1.4-1.4"/></g></svg>;
const SunLowIconDk = () => <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="14" r="4" fill="#E8976A"/><g stroke="#E8976A" strokeWidth="1.8" strokeLinecap="round"><path d="M4 18h16M12 7v2M6 9l1.4 1.4M18 9l-1.4 1.4"/></g></svg>;
const MoonIconDk   = () => <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M20 14.5A8 8 0 019.5 4a8 8 0 1010.5 10.5z" fill="#C7EE9C"/></svg>;

// ─────────────────────────────────────────────────────────────
// Sparkline (dark)
// ─────────────────────────────────────────────────────────────
function SparklineDk({ data, color='#C7EE9C', fill='rgba(199,238,156,0.22)', w=320, h=56, delay=400 }) {
  const max = Math.max(...data), min = Math.min(...data);
  const pad = 4;
  const pts = data.map((v,i)=>{
    const x = pad + (i/(data.length-1))*(w-2*pad);
    const y = pad + (1-(v-min)/(max-min||1))*(h-2*pad);
    return [x,y];
  });
  const d = pts.map((p,i)=>(i===0?'M':'L')+p[0].toFixed(1)+' '+p[1].toFixed(1)).join(' ');
  const area = d + ` L ${w-pad} ${h-pad} L ${pad} ${h-pad} Z`;
  const ref = useRefDk();
  useEffectDk(()=>{
    if (!ref.current) return;
    const len = ref.current.getTotalLength();
    ref.current.style.strokeDasharray = len;
    ref.current.style.strokeDashoffset = len;
    ref.current.style.animation = `mf-draw 1.4s ${delay}ms ease forwards`;
  },[data,delay]);
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} style={{ display:'block' }}>
      <path d={area} fill={fill} style={{ animation:`mf-fade .8s ${delay+600}ms both` }}/>
      <path ref={ref} d={d} fill="none" stroke={color} strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"/>
      <circle cx={pts[pts.length-1][0]} cy={pts[pts.length-1][1]} r="4" fill={color}
        style={{ animation:`mf-fade .4s ${delay+1200}ms both, mf-breathe 2s ${delay+1400}ms ease-in-out infinite` }}/>
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────
// Circle buttons (dark)
// ─────────────────────────────────────────────────────────────
function CircleBtnDk({ children }) {
  return <button style={{
    width:38, height:38, border:'1px solid #1F332A', borderRadius:999, background:'#13221B',
    display:'grid', placeItems:'center', cursor:'pointer', position:'relative',
    boxShadow:'0 2px 8px rgba(0,0,0,0.35)',
  }}>{children}
    <span style={{ position:'absolute', top:8, right:10, width:7, height:7, borderRadius:4, background:'#E8976A', boxShadow:'0 0 0 2px #13221B' }}/>
  </button>;
}
const BellIconDk = () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M18 16v-5a6 6 0 10-12 0v5l-2 2h16l-2-2z" stroke="#E8F2E0" strokeWidth="1.8" strokeLinejoin="round"/><path d="M10 20a2 2 0 004 0" stroke="#E8F2E0" strokeWidth="1.8" strokeLinecap="round"/></svg>;
const SlidersIconDk = () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M4 6h10M4 12h6M4 18h14" stroke="#E8F2E0" strokeWidth="1.8" strokeLinecap="round"/><circle cx="17" cy="6" r="2" stroke="#E8F2E0" strokeWidth="1.8"/><circle cx="13" cy="12" r="2" stroke="#E8F2E0" strokeWidth="1.8"/><circle cx="19" cy="18" r="2" stroke="#E8F2E0" strokeWidth="1.8"/></svg>;

// ─────────────────────────────────────────────────────────────
// META CARD (dark)
// ─────────────────────────────────────────────────────────────
function MetaCardDk({ title='Viaje a Bariloche', emoji='🏔️', current=1920000, goal=3000000, months=3 }) {
  const pct = Math.round((current/goal)*100);
  return (
    <div style={{ margin:'12px 22px 0',
      background:'linear-gradient(140deg, #1F6B43 0%, #0C2418 100%)', color:'#F6FBEF',
      borderRadius:20, padding:'14px 16px', animation:'mf-rise .9s .3s ease both',
      position:'relative', overflow:'hidden',
      border:'1px solid #1F332A',
      boxShadow:'0 12px 28px -14px rgba(0,0,0,0.7)',
    }}>
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
        <div>
          <div style={{ fontSize:10, letterSpacing:1.4, fontWeight:700, color:'#C7EE9C' }}>META · {title.toUpperCase()}</div>
          <div className="sf-display" style={{ fontSize:22, fontWeight:800, marginTop:2, letterSpacing:-0.6 }}>
            ${(current/1000).toLocaleString('es-AR')}k <span style={{ color:'rgba(246,251,239,0.5)', fontSize:14, fontWeight:500 }}>/ ${(goal/1000).toLocaleString('es-AR')}k</span>
          </div>
        </div>
        <div style={{ fontSize:30, animation:'mf-float 3s ease-in-out infinite' }}>{emoji}</div>
      </div>
      <div style={{ marginTop:10, height:8, background:'rgba(255,255,255,0.1)', borderRadius:4, overflow:'hidden', position:'relative' }}>
        <div style={{
          height:'100%', width:`${pct}%`,
          background:'linear-gradient(90deg,#C7EE9C,#E8976A)', borderRadius:4,
          transformOrigin:'left', animation:'mf-grow-bar 1.3s .5s cubic-bezier(.2,.9,.2,1) both',
          boxShadow:'0 0 12px rgba(199,238,156,0.45)',
        }}/>
        <div style={{ position:'absolute', inset:0, overflow:'hidden' }}>
          <div style={{ position:'absolute', top:0, bottom:0, width:'40%',
            background:'linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent)',
            animation:'mf-shine 3.2s 1.8s ease-in-out infinite' }}/>
        </div>
      </div>
      <div style={{ marginTop:8, display:'flex', justifyContent:'space-between', fontSize:11, color:'rgba(246,251,239,0.6)' }}>
        <span>{pct}% alcanzado</span>
        <span>faltan ~{months} meses</span>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Dónde va el dinero (dark)
// ─────────────────────────────────────────────────────────────
function CategoryBreakdownDk() {
  const items = [
    { label:'Casa',       pct:42, color:'#2E9A5F' },
    { label:'Comida',     pct:26, color:'#E8976A' },
    { label:'Transporte', pct:14, color:'#6FE09A' },
    { label:'Ocio',       pct:10, color:'#F1D690' },
    { label:'Otros',      pct: 8, color:'#6A7A70' },
  ];
  return (
    <div style={{ margin:'14px 22px 0', background:'#13221B', border:'1px solid #1F332A',
      borderRadius:18, padding:'14px 14px 12px', animation:'mf-rise .9s .4s ease both' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:10 }}>
        <div style={{ fontSize:10, letterSpacing:1.6, fontWeight:700, color:'#8FA094' }}>DÓNDE VA EL DINERO</div>
        <div style={{ fontSize:11, color:'#E8F2E0', fontWeight:600 }}>abril</div>
      </div>
      <div style={{ display:'flex', height:14, borderRadius:7, overflow:'hidden', background:'#0E1A15' }}>
        {items.map((it,i)=>(
          <div key={i} style={{
            width:`${it.pct}%`, background: it.color,
            transformOrigin:'left', animation:`mf-grow-bar .9s ${0.55+i*0.1}s cubic-bezier(.2,.9,.2,1) both`
          }}/>
        ))}
      </div>
      <div style={{ marginTop:10, display:'flex', flexWrap:'wrap', gap:'6px 12px' }}>
        {items.map((it,i)=>(
          <div key={i} style={{ display:'flex', alignItems:'center', gap:6, fontSize:11, color:'#E8F2E0', fontWeight:600,
            animation:`mf-fade .6s ${0.8+i*0.08}s both` }}>
            <span style={{ width:8, height:8, borderRadius:4, background:it.color }}/>
            {it.label} <span style={{ color:'#8FA094', fontWeight:500 }}>{it.pct}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// VS mes pasado + RACHA (dark)
// ─────────────────────────────────────────────────────────────
function CompareAndStreakDk() {
  return (
    <div style={{ padding:'14px 22px 0', display:'grid', gridTemplateColumns:'1fr 1fr', gap:10,
      animation:'mf-rise .9s .5s ease both' }}>
      <div style={{ background:'#13221B', borderRadius:16, padding:'12px', border:'1px solid #1F332A' }}>
        <div style={{ fontSize:9, color:'#8FA094', fontWeight:700, letterSpacing:1.2 }}>VS MARZO</div>
        <div className="sf-display" style={{ fontSize:20, fontWeight:800, letterSpacing:-0.4, marginTop:2, color:'#F6FBEF' }}>+$320k</div>
        <div style={{ fontSize:10, color:'#6FE09A', fontWeight:700 }}>▲ 18% mejor</div>
        <div style={{ display:'flex', gap:6, marginTop:8, alignItems:'flex-end', height:22 }}>
          <div style={{ flex:1, height:'60%', background:'#1F332A', borderRadius:3, transformOrigin:'bottom', animation:'mf-grow-bar .8s .6s ease both' }}/>
          <div style={{ flex:1, height:'100%', background:'#C7EE9C', borderRadius:3, transformOrigin:'bottom', animation:'mf-grow-bar .8s .8s ease both' }}/>
        </div>
      </div>
      <div style={{ background:'#13221B', borderRadius:16, padding:'12px', border:'1px solid #1F332A', position:'relative', overflow:'hidden' }}>
        <div style={{ fontSize:9, color:'#8FA094', fontWeight:700, letterSpacing:1.2 }}>RACHA</div>
        <div className="sf-display" style={{ fontSize:20, fontWeight:800, letterSpacing:-0.4, marginTop:2, color:'#F6FBEF' }}>14 días</div>
        <div style={{ fontSize:10, color:'#E8976A', fontWeight:600 }}>sin excesos</div>
        <div style={{ position:'absolute', right:8, bottom:6, fontSize:28, animation:'mf-wiggle 2s ease-in-out infinite',
          filter:'drop-shadow(0 0 8px rgba(232,151,106,0.5))' }}>🔥</div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Calendario del mes (dark)
// ─────────────────────────────────────────────────────────────
function MonthCalendarDk() {
  const today = 22, days = 30;
  const mood = {};
  for (let i=1;i<=today;i++) {
    const r = Math.sin(i*1.7)*Math.cos(i*0.9);
    mood[i] = r > 0.3 ? 'amber' : r < -0.55 ? 'red' : 'green';
  }
  return (
    <div style={{ margin:'14px 22px 0', background:'#13221B', border:'1px solid #1F332A',
      borderRadius:18, padding:'14px', animation:'mf-rise .9s .6s ease both' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:10 }}>
        <div style={{ fontSize:10, letterSpacing:1.6, fontWeight:700, color:'#8FA094' }}>TU MES EN UN VISTAZO</div>
        <div style={{ display:'flex', gap:8, fontSize:9, color:'#8FA094', fontWeight:600 }}>
          <LegendDotDk color="#6FE09A" label="bien"/>
          <LegendDotDk color="#E8976A" label="alerta"/>
          <LegendDotDk color="#D96A4F" label="exceso"/>
        </div>
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(7, 1fr)', gap:5 }}>
        {['L','M','M','J','V','S','D'].map((d,i)=>(
          <div key={i} style={{ fontSize:9, textAlign:'center', color:'#6A7A70', fontWeight:700, letterSpacing:1, paddingBottom:2 }}>{d}</div>
        ))}
        {[0,1,2].map(i => <div key={'o'+i}/>)}
        {Array.from({length: days}, (_, idx) => {
          const n = idx+1;
          const m = mood[n];
          const bg = m==='green' ? '#1E3A28' : m==='amber' ? '#3A2A22' : m==='red' ? '#3A241E' : 'transparent';
          const border = n > today ? '1px dashed #1F332A' : 'none';
          const color = m==='green' ? '#8DD66A' : m==='amber' ? '#E8976A' : m==='red' ? '#D96A4F' : '#6A7A70';
          const isToday = n === today;
          return (
            <div key={n} style={{
              aspectRatio:'1', borderRadius:8,
              background: isToday ? 'linear-gradient(140deg,#C7EE9C,#8DD66A)' : bg,
              color: isToday ? '#0A1410' : color,
              display:'grid', placeItems:'center', fontSize:11, fontWeight:700,
              border, position:'relative',
              animation:`mf-fade .45s ${0.65 + n*0.012}s both`,
              boxShadow: isToday ? '0 6px 16px -4px rgba(199,238,156,0.4)' : 'none',
            }}>
              {n}
              {isToday && <div style={{ position:'absolute', bottom:2, width:4, height:4, borderRadius:2, background:'#0A1410', animation:'mf-breathe 1.6s ease-in-out infinite' }}/>}
            </div>
          );
        })}
      </div>
    </div>
  );
}
function LegendDotDk({ color, label }) {
  return <div style={{ display:'flex', alignItems:'center', gap:4 }}>
    <span style={{ width:7, height:7, borderRadius:4, background:color }}/>{label}
  </div>;
}

// ─────────────────────────────────────────────────────────────
// Mini metric card (dark)
// ─────────────────────────────────────────────────────────────
function MiniCardDk({ label, value, sub, chart, delay=0 }) {
  return (
    <div style={{
      background:'#13221B', borderRadius:18, padding:'14px 14px', border:'1px solid #1F332A',
      animation:`mf-rise .8s ${delay}ms ease both`, position:'relative', overflow:'hidden',
    }}>
      <div style={{ fontSize:10, letterSpacing:1.4, fontWeight:700, color:'#8FA094' }}>{label}</div>
      <div className="sf-display" style={{ fontSize:22, fontWeight:800, color:'#F6FBEF', marginTop:4, letterSpacing:-0.5 }}>{value}</div>
      <div style={{ fontSize:11, color:'#6A7A70', marginTop:2 }}>{sub}</div>
      <div style={{ position:'absolute', right:10, bottom:10, opacity:.95 }}>{chart}</div>
    </div>
  );
}
function MiniBarsDk({ values, color }) {
  return <div style={{ display:'flex', alignItems:'flex-end', gap:2, height:22 }}>
    {values.map((v,i)=>(
      <div key={i} style={{ width:5, height: 22*v, background:color, borderRadius:2,
        transformOrigin:'bottom', animation:`mf-grow-bar .6s ${0.4+i*0.08}s ease both` }}/>
    ))}
  </div>;
}

// Shortcut card (dark) — lleva al detalle
function ShortcutCardDk({ label, value, sub, trend, trendColor='#F6FBEF', chart, delay=0 }) {
  return (
    <div style={{
      background:'#13221B', borderRadius:18, padding:'14px', border:'1px solid #1F332A',
      animation:`mf-rise .8s ${delay}ms ease both`, position:'relative', overflow:'hidden',
      cursor:'pointer',
    }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start' }}>
        <div style={{ fontSize:10, letterSpacing:1.4, fontWeight:700, color:'#8FA094' }}>{label}</div>
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" style={{ opacity:.5 }}>
          <path d="M9 6l6 6-6 6" stroke="#F6FBEF" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      </div>
      <div className="sf-display" style={{ fontSize:22, fontWeight:800, color:'#F6FBEF', marginTop:4, letterSpacing:-0.5 }}>{value}</div>
      <div style={{ fontSize:11, color:'#6E7D74', marginTop:1 }}>{sub}</div>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-end', marginTop:8 }}>
        <div style={{ fontSize:10.5, fontWeight:700, color:trendColor }}>{trend}</div>
        <div>{chart}</div>
      </div>
    </div>
  );
}
function PagoDotsDk({ paid, total }) {
  return <div style={{ display:'flex', gap:3 }}>
    {Array.from({length:total}).map((_,i)=>(
      <div key={i} style={{
        width:6, height:6, borderRadius:3,
        background: i<paid ? '#6FE09A' : '#1F332A',
        animation:`mf-fade .4s ${0.4+i*0.04}s both`,
        boxShadow: i<paid ? '0 0 6px rgba(111,224,154,0.4)' : 'none',
      }}/>
    ))}
  </div>;
}

// ─────────────────────────────────────────────────────────────
// Activity row (dark)
// ─────────────────────────────────────────────────────────────
function ActivityRowDk({ icon, title, cat, who, amount, delay=0 }) {
  return (
    <div style={{
      background:'#13221B', borderRadius:16, padding:'12px 14px',
      display:'flex', alignItems:'center', gap:12, border:'1px solid #1F332A',
      animation:`mf-slide-in .6s ${delay}ms ease both`,
    }}>
      <div style={{ position:'relative', flexShrink:0 }}>
        <div style={{ width:38, height:38, borderRadius:12, background:'#3A2A22', display:'grid', placeItems:'center', fontSize:18 }}>{icon}</div>
        <div style={{ position:'absolute', bottom:-3, right:-3 }}>
          <Avatar name={who.name} color={who.color} size={18} ring ringColor="#13221B"/>
        </div>
      </div>
      <div style={{ flex:1, minWidth:0 }}>
        <div style={{ fontSize:14, fontWeight:700, color:'#F6FBEF' }}>{title}</div>
        <div style={{ fontSize:12, color:'#8FA094' }}>
          {who.name} · {cat}
        </div>
      </div>
      <div style={{ fontSize:14, fontWeight:800, color: amount<0?'#F6FBEF':'#6FE09A' }}>
        {fmtMoney(amount, { sign:true })}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Tab bar (dark)
// ─────────────────────────────────────────────────────────────
function TabBarDk() {
  const items = [
    { label:'Hoy', active:true, icon:<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M4 11l8-7 8 7v9a1 1 0 01-1 1h-5v-6h-4v6H5a1 1 0 01-1-1v-9z" fill="#C7EE9C"/></svg> },
    { label:'Mes', icon:<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><rect x="4" y="6" width="16" height="14" rx="2" stroke="#8FA094" strokeWidth="1.8"/><path d="M4 10h16M9 4v4M15 4v4" stroke="#8FA094" strokeWidth="1.8" strokeLinecap="round"/></svg> },
    { label:'+', big:true },
    { label:'Familia', icon:<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><circle cx="9" cy="9" r="3" stroke="#8FA094" strokeWidth="1.8"/><circle cx="17" cy="11" r="2.3" stroke="#8FA094" strokeWidth="1.8"/><path d="M3 19c0-3 2.7-5 6-5s6 2 6 5M14 19c0-2 1.8-4 4-4s4 2 4 4" stroke="#8FA094" strokeWidth="1.8" strokeLinecap="round"/></svg> },
    { label:'Metas', icon:<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="8" stroke="#8FA094" strokeWidth="1.8"/><circle cx="12" cy="12" r="3" stroke="#8FA094" strokeWidth="1.8"/></svg> },
  ];
  return (
    <div style={{
      position:'absolute', bottom:0, left:0, right:0,
      background:'rgba(10,20,16,0.92)', backdropFilter:'blur(18px)',
      borderTop:'1px solid #1F332A',
      padding:'10px 20px 28px', display:'flex', justifyContent:'space-around', alignItems:'center',
    }}>
      {items.map((it,i)=> it.big ? (
        <button key={i} style={{
          width:52, height:52, borderRadius:999, border:'none', cursor:'pointer',
          background:'linear-gradient(140deg,#C7EE9C,#8DD66A)', color:'#0A1410', fontSize:26, fontWeight:700,
          marginTop:-22, boxShadow:'0 12px 24px -8px rgba(199,238,156,0.45)',
          animation:'mf-pulse 2.4s ease-in-out infinite',
        }}>+</button>
      ) : (
        <div key={i} style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:3 }}>
          {it.icon}
          <div style={{ fontSize:10, color: it.active ? '#C7EE9C' : '#8FA094', fontWeight: it.active ? 700 : 500 }}>{it.label}</div>
        </div>
      ))}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// THE SCREEN (dark)
// ─────────────────────────────────────────────────────────────
function V1Dark() {
  return (
    <div className="screen" style={{ background:'#0A1410' }}>
      <StatusBar color="#F6FBEF"/>

      {/* ambient glows */}
      <div style={{ position:'absolute', top:-70, right:-50, width:260, height:260, borderRadius:'50%',
        background:'radial-gradient(closest-side, rgba(111,224,154,0.22), transparent 70%)',
        animation:'mf-float-slow 9s ease-in-out infinite', pointerEvents:'none' }}/>
      <div style={{ position:'absolute', top:440, left:-80, width:240, height:240, borderRadius:'50%',
        background:'radial-gradient(closest-side, rgba(232,151,106,0.18), transparent 70%)',
        animation:'mf-float-slow 11s ease-in-out infinite', animationDelay:'-3s', pointerEvents:'none' }}/>
      <div style={{ position:'absolute', top:1000, right:-60, width:280, height:280, borderRadius:'50%',
        background:'radial-gradient(closest-side, rgba(199,238,156,0.18), transparent 70%)',
        animation:'mf-float-slow 13s ease-in-out infinite', animationDelay:'-6s', pointerEvents:'none' }}/>

      {/* header */}
      <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', paddingRight:22, paddingTop:2 }}>
        <GreetingHeaderDk name="Mario" hour={22}/>
        <div style={{ display:'flex', gap:8, marginTop:14 }}>
          <CircleBtnDk><BellIconDk/></CircleBtnDk>
          <CircleBtnDk><SlidersIconDk/></CircleBtnDk>
        </div>
      </div>

      {/* family strip */}
      <div style={{ padding:'12px 22px 0', display:'flex', alignItems:'center', gap:10, animation:'mf-rise .8s .1s ease both' }}>
        <div style={{ display:'flex' }}>
          {FAMILY.map((f,i) => (
            <div key={i} style={{ marginLeft: i===0?0:-8, animation:`mf-rise .5s ${0.15+i*0.08}s ease both` }}>
              <Avatar name={f.name} color={f.color} size={26} ring ringColor="#0A1410"/>
            </div>
          ))}
        </div>
        <div style={{ fontSize:12, color:'#8FA094' }}>Familia López · <b style={{ color:'#F6FBEF' }}>4</b></div>
        <div style={{ marginLeft:'auto', fontSize:11, fontWeight:600, color:'#F6FBEF',
          background:'#13221B', border:'1px solid #1F332A', padding:'5px 10px', borderRadius:999,
          display:'flex', alignItems:'center', gap:6 }}>
          <span style={{ width:6, height:6, borderRadius:3, background:'#E8976A',
            display:'inline-block', animation:'mf-breathe 1.8s ease-in-out infinite',
            boxShadow:'0 0 8px rgba(232,151,106,0.6)' }}/>
          27 días al cobro
        </div>
      </div>

      {/* hero card */}
      <div style={{ margin:'12px 22px 0',
        background:'linear-gradient(160deg, #133827 0%, #1F6B43 55%, #2E9A5F 100%)',
        borderRadius:26,
        padding:'20px 22px', color:'#F6FBEF', position:'relative', overflow:'hidden',
        animation:'mf-rise .9s .15s ease both',
        border:'1px solid #1F332A',
        boxShadow:'0 20px 40px -20px rgba(0,0,0,0.7), inset 0 1px 0 rgba(199,238,156,0.12)',
      }}>
        <div style={{ position:'absolute', inset:0, pointerEvents:'none', overflow:'hidden', borderRadius:26 }}>
          <div style={{ position:'absolute', top:0, left:0, width:'40%', height:'100%',
            background:'linear-gradient(120deg, transparent, rgba(255,255,255,0.08), transparent)',
            animation:'mf-shine 4.2s 1s ease-in-out infinite' }}/>
        </div>

        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
          <div style={{ fontSize:11, letterSpacing:1.6, fontWeight:700, color:'#C7EE9C' }}>DISPONIBLE HOY</div>
          <div style={{ fontSize:11, color:'rgba(246,251,239,0.55)', fontWeight:500 }}>Mes de abril</div>
        </div>

        <div className="sf-display" style={{ fontSize:46, fontWeight:800, lineHeight:1, marginTop:10, letterSpacing:-2 }}>
          <CountUp to={4455000} duration={1400} prefix="$"/>
        </div>

        <div style={{ marginTop:10, fontSize:13, color:'rgba(246,251,239,0.78)' }}>
          Margen del mes <span style={{ color:'#C7EE9C', fontWeight:700 }}>+$2.535.000</span>
          <span style={{ marginLeft:8, padding:'2px 8px', borderRadius:999, background:'rgba(199,238,156,0.18)', color:'#C7EE9C', fontSize:11, fontWeight:700 }}>+18%</span>
        </div>

        <div style={{ marginTop:14, marginLeft:-4 }}>
          <SparklineDk data={[22,28,26,33,31,38,36,42,40,47,52,58]} w={320} h={54}/>
        </div>

        <div style={{ display:'flex', gap:8, marginTop:14 }}>
          <button style={{
            border:'none', background:'linear-gradient(140deg,#C7EE9C,#8DD66A)', color:'#0A1410', padding:'14px 18px',
            borderRadius:999, fontWeight:700, fontSize:14, display:'flex', alignItems:'center', gap:8,
            cursor:'pointer', animation:'mf-pulse 2.4s ease-in-out 1.6s infinite',
            boxShadow:'0 10px 22px -6px rgba(141,214,106,0.5)',
          }}>
            <span style={{ fontSize:18, fontWeight:800, marginTop:-2 }}>+</span> Registrar gasto
          </button>
          <button style={{
            border:'1px solid rgba(246,251,239,0.2)', background:'transparent', color:'#F6FBEF',
            padding:'14px 16px', borderRadius:999, fontWeight:600, fontSize:13, cursor:'pointer',
          }}>Dividir</button>
        </div>
      </div>

      {/* metric cards — atajos a Gastos y Fijos */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10, padding:'12px 22px 0' }}>
        <ShortcutCardDk
          label="GASTOS" value="$1.545.000" sub="este mes · 47 movs"
          trend="+12% vs marzo" trendColor="#E8976A"
          chart={<MiniBarsDk values={[0.4,0.55,0.7,0.6,0.85,0.72,0.9]} color="#C7EE9C"/>}
          delay={200}
        />
        <ShortcutCardDk
          label="FIJOS" value="$920.000" sub="7 de 12 pagados"
          trend="3 próximos" trendColor="#C7EE9C"
          chart={<PagoDotsDk paid={7} total={12}/>}
          delay={260}
        />
      </div>

      <MetaCardDk/>

      {/* ACTIVITY */}
      <div style={{ padding:'14px 22px 0', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <div style={{ fontSize:11, letterSpacing:1.6, fontWeight:700, color:'#8FA094' }}>ACTIVIDAD</div>
        <div style={{ fontSize:13, fontWeight:600, color:'#F6FBEF' }}>Ver todos</div>
      </div>
      <div style={{ margin:'8px 22px 0', display:'flex', flexDirection:'column', gap:6 }}>
        <ActivityRowDk icon="🍹" title="Fernet con coca" cat="Gastos generales" who={FAMILY[0]} amount={-25000} delay={400}/>
        <ActivityRowDk icon="🛒" title="Supermercado" cat="Casa" who={FAMILY[1]} amount={-42300} delay={460}/>
        <ActivityRowDk icon="🚌" title="SUBE" cat="Transporte" who={FAMILY[2]} amount={-8000} delay={520}/>
      </div>

      <div style={{ height:120 }}/>

      <TabBarDk/>
    </div>
  );
}

window.V1Dark = V1Dark;
