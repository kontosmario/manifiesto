// Gastos screen — V1 Core style (light + dark)
// Incorpora: total visible, peso por categoría, calendario del mes,
// racha, vs mes anterior, filtros (pills) y lista de movimientos agrupada por día.

const { useState: useStateGx, useRef: useRefGx, useEffect: useEffectGx } = React;

// ─────────────────────────────────────────────────────────────
// Datos mock
// ─────────────────────────────────────────────────────────────
const GASTOS_CATS = [
  { id:'alq',  label:'Alquiler',      color:'#E08E63', darkColor:'#E8976A', emoji:'🏠' },
  { id:'mer',  label:'Mercado',       color:'#2E7D5B', darkColor:'#6FE09A', emoji:'🛒' },
  { id:'tra',  label:'Transporte',    color:'#C9A23A', darkColor:'#F1D690', emoji:'🚌' },
  { id:'oci',  label:'Ocio',          color:'#6B3A4F', darkColor:'#D99BB3', emoji:'🎬' },
  { id:'ser',  label:'Servicios',     color:'#0F2A1E', darkColor:'#8DD66A', emoji:'💡' },
  { id:'sal',  label:'Salud',         color:'#4A7FB8', darkColor:'#8FBEEB', emoji:'💊' },
  { id:'edu',  label:'Educación',     color:'#7A5AA0', darkColor:'#B8A0E0', emoji:'📚' },
  { id:'mas',  label:'Mascotas',      color:'#A35545', darkColor:'#E09578', emoji:'🐾' },
  { id:'rop',  label:'Ropa',          color:'#C06787', darkColor:'#F0A8C0', emoji:'👕' },
  { id:'tec',  label:'Tecnología',    color:'#3D6A8A', darkColor:'#8AB8D8', emoji:'💻' },
  { id:'reg',  label:'Regalos',       color:'#B8853A', darkColor:'#F0C870', emoji:'🎁' },
  { id:'via',  label:'Viajes',        color:'#2A7A7A', darkColor:'#7AD0D0', emoji:'✈️' },
  { id:'rst',  label:'Restaurantes',  color:'#A04040', darkColor:'#E08888', emoji:'🍽️' },
  { id:'dep',  label:'Deporte',       color:'#4A7A3D', darkColor:'#A0D088', emoji:'⚽' },
  { id:'sus',  label:'Suscripciones', color:'#5A4A7A', darkColor:'#A898D0', emoji:'📱' },
  { id:'imp',  label:'Impuestos',     color:'#3A3A3A', darkColor:'#8A8A8A', emoji:'📄' },
  { id:'bel',  label:'Belleza',       color:'#B06590', darkColor:'#F0A0C8', emoji:'💄' },
  { id:'otr',  label:'Otros',         color:'#8A8A8A', darkColor:'#B0B0B0', emoji:'📦' },
];

const GASTOS_MOVS = [
  // Hoy (22-abr)
  { id:1, day:22, title:'Alquiler',         cat:'alq', amount:-300000, who:0, time:'08:10' },
  { id:2, day:22, title:'Café de la mañana', cat:'oci', amount:-3200,   who:1, time:'09:25' },
  { id:3, day:22, title:'SUBE',             cat:'tra', amount:-8000,   who:2, time:'13:40' },
  // Ayer
  { id:4, day:21, title:'Supermercado Coto', cat:'mer', amount:-42300, who:1, time:'19:02' },
  { id:5, day:21, title:'Netflix',           cat:'sus', amount:-9800,  who:0, time:'21:15' },
  // 20-abr
  { id:6, day:20, title:'Edenor',            cat:'ser', amount:-18500, who:0, time:'10:00' },
  { id:7, day:20, title:'Farmacia',          cat:'sal', amount:-6400,  who:1, time:'12:30' },
  { id:9, day:20, title:'Adidas zapatillas', cat:'rop', amount:-85000, who:2, time:'17:20' },
  // 19-abr
  { id:8, day:19, title:'Uber',              cat:'tra', amount:-5200,  who:2, time:'23:45' },
  { id:10, day:19, title:'Cine Hoyts',       cat:'oci', amount:-12000, who:1, time:'21:30' },
  { id:11, day:19, title:'Veterinaria',      cat:'mas', amount:-15400, who:0, time:'11:00' },
];

const byCat = (movs) => {
  const map = {};
  movs.forEach(m => { map[m.cat] = (map[m.cat]||0) + Math.abs(m.amount); });
  return Object.entries(map).map(([cat, amount]) => {
    const c = GASTOS_CATS.find(x=>x.id===cat);
    return { ...c, amount };
  }).sort((a,b)=>b.amount-a.amount);
};

// ─────────────────────────────────────────────────────────────
// GASTOS — LIGHT
// ─────────────────────────────────────────────────────────────
function GastosLight() {
  const [filter, setFilter] = useStateGx('todas');
  const [selectedDay, setSelectedDay] = useStateGx(null);      // null = mes completo
  const [lastTappedDay, setLastTappedDay] = useStateGx(null);  // flash al volver
  const DAYS_IN_MONTH = 30;
  const byCatFilter = filter==='todas' ? GASTOS_MOVS : GASTOS_MOVS.filter(m => m.cat===filter);
  const filtered = selectedDay ? byCatFilter.filter(m => m.day===selectedDay) : byCatFilter;
  const total = filtered.reduce((s,m)=>s+Math.abs(m.amount), 0);
  const cats = byCat(filtered);
  const groups = groupByDay(filtered);

  const openDay = (d) => { setSelectedDay(d); };
  const closeDay = () => { setLastTappedDay(selectedDay); setSelectedDay(null); setTimeout(()=>setLastTappedDay(null), 1600); };
  const nextDay = () => setSelectedDay(d => d >= DAYS_IN_MONTH ? 1 : d+1);
  const prevDay = () => setSelectedDay(d => d <= 1 ? DAYS_IN_MONTH : d-1);

  return (
    <div className="screen" style={{ background:'#EFF5E8', overflowY:'auto' }}>
      <StatusBar color="#0E3A26"/>

      {/* ambient glows */}
      <div style={{ position:'absolute', top:-70, right:-50, width:240, height:240, borderRadius:'50%',
        background:'radial-gradient(closest-side, rgba(177,227,130,0.5), transparent 70%)',
        animation:'mf-float-slow 9s ease-in-out infinite', pointerEvents:'none' }}/>
      <div style={{ position:'absolute', top:700, left:-70, width:220, height:220, borderRadius:'50%',
        background:'radial-gradient(closest-side, rgba(247,181,138,0.28), transparent 70%)',
        animation:'mf-float-slow 11s ease-in-out infinite', animationDelay:'-3s', pointerEvents:'none' }}/>

      {/* header */}
      <div style={{ padding:'2px 22px 0', display:'flex', alignItems:'flex-start', justifyContent:'space-between',
        animation:'mf-rise .6s ease both' }}>
        <div>
          <div className="sf-display" style={{ fontSize:34, fontWeight:800, color:'#0F2A1E', letterSpacing:-1.2, lineHeight:1 }}>
            Gastos
          </div>
          <div style={{ fontSize:13, color:'#6F7A73', marginTop:6, maxWidth:230, lineHeight:1.35 }}>
            Historial, filtros y edición rápida de movimientos.
          </div>
        </div>
        <button style={{
          marginTop:6,
          width:40, height:40, borderRadius:999, cursor:'pointer',
          background:'linear-gradient(140deg, #1F7A4B, #0E3A26)',
          border:'none', color:'#F6FBEF',
          display:'grid', placeItems:'center',
          boxShadow:'0 8px 18px -6px rgba(14,58,38,0.5)',
          animation:'mf-pulse 2.2s ease-out infinite',
        }}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M12 5v14M5 12h14" stroke="#F6FBEF" strokeWidth="2.4" strokeLinecap="round"/></svg>
        </button>
      </div>

      {/* HERO — total visible */}
      <div style={{ margin:'14px 22px 0',
        background:'linear-gradient(160deg, #0E3A26 0%, #165C3A 55%, #1F7A4B 100%)',
        borderRadius:24, padding:'18px 20px', color:'#F6FBEF', position:'relative', overflow:'hidden',
        animation:'mf-rise .8s .1s ease both',
        boxShadow:'0 20px 40px -20px rgba(14,58,38,0.55)',
      }}>
        <div style={{ position:'absolute', inset:0, pointerEvents:'none', overflow:'hidden', borderRadius:24 }}>
          <div style={{ position:'absolute', top:0, left:0, width:'40%', height:'100%',
            background:'linear-gradient(120deg, transparent, rgba(255,255,255,0.08), transparent)',
            animation:'mf-shine 4.2s 1s ease-in-out infinite' }}/>
        </div>

        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
          <div style={{ fontSize:11, letterSpacing:1.6, fontWeight:700, color:'#B1E382' }}>TOTAL VISIBLE</div>
          <div style={{ fontSize:10, color:'rgba(255,255,255,0.6)', fontWeight:600, padding:'3px 8px',
            background:'rgba(255,255,255,0.08)', borderRadius:999 }}>
            {filtered.length} mov · {selectedDay ? `día ${selectedDay}` : 'abril'} · {filter==='todas'?'Todas':GASTOS_CATS.find(c=>c.id===filter)?.label}
          </div>
        </div>

        <div className="sf-display" style={{ fontSize:42, fontWeight:800, lineHeight:1, marginTop:10, letterSpacing:-1.8 }}>
          <CountUp to={total} duration={1200} prefix="$"/>
        </div>

        {/* peso por categoría */}
        <div style={{ marginTop:14 }}>
          <div style={{ fontSize:10, color:'rgba(255,255,255,0.55)', fontWeight:600, letterSpacing:1.2 }}>MÁS PESO POR CATEGORÍA</div>
          <div style={{ marginTop:6, display:'flex', flexDirection:'column', gap:6 }}>
            {cats.slice(0,3).map((c,i)=>{
              const pct = Math.round((c.amount/total)*100);
              return (
                <div key={c.id} style={{ animation:`mf-rise .6s ${0.2+i*0.08}s both` }}>
                  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', fontSize:12, marginBottom:4 }}>
                    <div style={{ display:'flex', alignItems:'center', gap:6, fontWeight:600 }}>
                      <span style={{ width:7, height:7, borderRadius:4, background:c.color }}/>
                      {c.label}
                    </div>
                    <div style={{ fontWeight:700 }}>${c.amount.toLocaleString('es-AR')} <span style={{ color:'rgba(255,255,255,0.55)', fontWeight:500 }}>· {pct}%</span></div>
                  </div>
                  <div style={{ height:6, background:'rgba(255,255,255,0.12)', borderRadius:3, overflow:'hidden' }}>
                    <div style={{ width:`${pct}%`, height:'100%',
                      background:`linear-gradient(90deg, ${c.color}, ${shade(c.color,20)})`,
                      borderRadius:3, transformOrigin:'left',
                      animation:`mf-grow-bar 1s ${0.4+i*0.1}s cubic-bezier(.2,.9,.2,1) both` }}/>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Insights row — promedio día + RACHA de registro */}
      <div style={{ padding:'12px 22px 0', display:'grid', gridTemplateColumns:'1fr 1fr', gap:10,
        animation:'mf-rise .8s .25s ease both' }}>
        <InsightCardLt
          label="PROMEDIO DÍA"
          value={`$${Math.round(total/22).toLocaleString('es-AR')}`}
          sub="últimos 22 días"
          subColor="#6F7A73"
          chart={
            <div style={{ display:'flex', gap:3, alignItems:'flex-end', height:24 }}>
              {[0.4,0.6,0.3,0.7,0.5,0.8,0.55].map((v,i)=>(
                <div key={i} style={{ flex:1, height:`${v*100}%`, background:'#2E7D5B', borderRadius:2,
                  transformOrigin:'bottom', animation:`mf-grow-bar .6s ${0.5+i*0.06}s ease both` }}/>
              ))}
            </div>
          }
        />
        <InsightCardLt
          label="RACHA DE REGISTRO"
          value="14 días"
          sub="sin olvidarte"
          subColor="#6B3A4F"
          chart={<div style={{ fontSize:24, animation:'mf-wiggle 2s ease-in-out infinite' }}>🔥</div>}
        />
      </div>

      {/* Calendario del mes */}
      <MonthCalendarGxLt
        movs={byCatFilter}
        selectedDay={selectedDay}
        lastTappedDay={lastTappedDay}
        onSelectDay={openDay}
        onClear={closeDay}
        onNext={nextDay}
        onPrev={prevDay}
      />

      {/* Smart Filter: search + frequent + see all */}
      <SmartFilterLt
        allCats={GASTOS_CATS}
        movs={GASTOS_MOVS}
        filter={filter}
        setFilter={setFilter}
      />

      {/* Movimientos */}
      <div style={{ padding:'14px 22px 0', display:'flex', justifyContent:'space-between', alignItems:'baseline' }}>
        <div className="sf-display" style={{ fontSize:20, fontWeight:800, color:'#0F2A1E', letterSpacing:-0.5 }}>Movimientos</div>
        <div style={{ fontSize:11, color:'#6F7A73', display:'flex', alignItems:'center', gap:4 }}>
          <SwipeHintIconLt/> Desliza para acciones
        </div>
      </div>

      <div style={{ margin:'8px 22px 0', display:'flex', flexDirection:'column', gap:14 }}>
        {groups.map((g, gi) => (
          <div key={g.label} style={{ animation:`mf-rise .6s ${0.35+gi*0.08}s ease both` }}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', padding:'0 2px 6px' }}>
              <div>
                <div style={{ fontSize:14, fontWeight:700, color:'#0F2A1E' }}>{g.label}</div>
                <div style={{ fontSize:11, color:'#9AA39D' }}>{g.items.length} movimiento{g.items.length!==1?'s':''}</div>
              </div>
              <div style={{ fontSize:14, fontWeight:800, color:'#0F2A1E' }}>-${g.total.toLocaleString('es-AR')}</div>
            </div>
            <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
              {g.items.map((m,i) => (
                <GastoRowLt key={m.id} mov={m} delay={0.4+gi*0.08+i*0.04}/>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* bottom spacer */}
      <div style={{ height:120 }}/>

      <TabBar active="gastos" accent="#8DD66A" bg="#EFF5E8"/>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Light sub-components
// ─────────────────────────────────────────────────────────────
function CircleBtnLt({ children }) {
  return <button style={{
    width:38, height:38, border:'none', borderRadius:999, background:'#FFFBF2',
    display:'grid', placeItems:'center', cursor:'pointer',
    boxShadow:'0 2px 6px rgba(15,42,30,0.08)',
  }}>{children}</button>;
}
const SortIconLt = () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M7 4v16M7 20l-3-3M7 20l3-3M17 20V4M17 4l-3 3M17 4l3 3" stroke="#0F2A1E" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>;
const FilterIconLt = () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M4 6h16M7 12h10M10 18h4" stroke="#0F2A1E" strokeWidth="1.8" strokeLinecap="round"/></svg>;

function InsightCardLt({ label, value, sub, subColor, chart }) {
  return (
    <div style={{ background:'#FFFBF2', borderRadius:16, padding:'12px', border:'1px solid #EFE8D9',
      position:'relative', overflow:'hidden' }}>
      <div style={{ fontSize:9, color:'#6F7A73', fontWeight:700, letterSpacing:1.2 }}>{label}</div>
      <div className="sf-display" style={{ fontSize:20, fontWeight:800, letterSpacing:-0.4, marginTop:2, color:'#0F2A1E' }}>{value}</div>
      <div style={{ fontSize:10, color: subColor, fontWeight:700 }}>{sub}</div>
      <div style={{ marginTop:6 }}>{chart}</div>
    </div>
  );
}

function FilterPillLt({ active, label, count, emoji, color='#0F2A1E', onClick, small }) {
  return (
    <button onClick={onClick} style={{
      flex:'0 0 auto', display:'inline-flex', alignItems:'center', gap:6,
      padding: small ? '6px 10px' : '8px 12px', borderRadius:999, cursor:'pointer', whiteSpace:'nowrap',
      background: active ? '#0F2A1E' : '#FFFBF2',
      color: active ? '#F6FBEF' : '#0F2A1E',
      border: active ? '1px solid #0F2A1E' : '1px solid #EFE8D9',
      fontSize: small ? 11 : 12, fontWeight:700,
      boxShadow: active ? '0 6px 16px -6px rgba(15,42,30,0.4)' : 'none',
      transition:'all .2s ease',
    }}>
      <span style={{ fontSize: small ? 12 : 14 }}>{emoji}</span>
      {label}
      <span style={{
        fontSize:10, fontWeight:700,
        padding:'1px 6px', borderRadius:999,
        background: active ? 'rgba(255,255,255,0.18)' : '#EFF5E8',
        color: active ? '#B1E382' : color,
      }}>{count}</span>
    </button>
  );
}

// ─────────────────────────────────────────────────────────────
// SMART FILTER (light)
// Top pills: Todas + 4 más usadas · Buscador · Chip activo si la cat no está en frecuentes
// Sheet modal: ver todas las categorías + buscar + crear nueva
// ─────────────────────────────────────────────────────────────
function SmartFilterLt({ allCats, movs, filter, setFilter }) {
  const [sheetOpen, setSheetOpen] = useStateGx(false);
  const [query, setQuery] = useStateGx('');

  // categorías con movimientos, ordenadas por frecuencia
  const usage = {};
  movs.forEach(m => { usage[m.cat] = (usage[m.cat]||0) + 1; });
  const ranked = [...allCats]
    .map(c => ({ ...c, count: usage[c.id]||0 }))
    .sort((a,b) => b.count - a.count);

  const topFour = ranked.filter(c => c.count > 0).slice(0, 4);
  const topFourIds = new Set(topFour.map(c => c.id));
  const activeCat = allCats.find(c => c.id === filter);
  const activeIsHidden = filter !== 'todas' && activeCat && !topFourIds.has(filter);

  const filteredInSheet = ranked.filter(c =>
    c.label.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <>
      <div style={{ padding:'14px 22px 0', animation:'mf-rise .8s .3s ease both' }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:8 }}>
          <div style={{ fontSize:10, letterSpacing:1.6, fontWeight:700, color:'#6F7A73' }}>FILTRAR POR CATEGORÍA</div>
          <button onClick={()=>setSheetOpen(true)} style={{
            fontSize:11, fontWeight:700, color:'#0F2A1E', background:'transparent', border:'none',
            cursor:'pointer', display:'flex', alignItems:'center', gap:4, padding:0,
          }}>
            Ver todas
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none"><path d="M9 6l6 6-6 6" stroke="#0F2A1E" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
          </button>
        </div>
        <div style={{ display:'flex', gap:6, flexWrap:'wrap', alignItems:'center' }}>
          <FilterPillLt active={filter==='todas'} onClick={()=>setFilter('todas')}
            label="Todas" count={movs.length} emoji="📋"/>
          {topFour.map(c => (
            <FilterPillLt key={c.id} active={filter===c.id} onClick={()=>setFilter(c.id)}
              label={c.label} count={c.count} emoji={c.emoji} color={c.color}/>
          ))}
          {activeIsHidden && (
            <FilterPillLt active onClick={()=>setFilter('todas')}
              label={activeCat.label} count={usage[activeCat.id]||0} emoji={activeCat.emoji} color={activeCat.color}/>
          )}
          <button onClick={()=>setSheetOpen(true)} style={{
            flex:'0 0 auto', display:'inline-flex', alignItems:'center', gap:4,
            padding:'8px 10px', borderRadius:999, cursor:'pointer',
            background:'#FFFBF2', color:'#6F7A73',
            border:'1px dashed #D9D2C4', fontSize:12, fontWeight:700,
          }}>
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="7" stroke="#6F7A73" strokeWidth="2"/><path d="M16 16l4 4" stroke="#6F7A73" strokeWidth="2" strokeLinecap="round"/></svg>
            Buscar
          </button>
        </div>
      </div>

      {sheetOpen && (
        <CategorySheetLt
          cats={ranked}
          filtered={filteredInSheet}
          query={query} setQuery={setQuery}
          filter={filter} setFilter={(id)=>{setFilter(id); setSheetOpen(false);}}
          total={movs.length}
          onClose={()=>setSheetOpen(false)}
        />
      )}
    </>
  );
}

// Sheet modal — ve todas las categorías, buscá, creá nueva (light)
function CategorySheetLt({ cats, filtered, query, setQuery, filter, setFilter, total, onClose }) {
  return (
    <div style={{
      position:'absolute', inset:0, zIndex:50,
      background:'rgba(15,42,30,0.45)', backdropFilter:'blur(4px)',
      display:'flex', flexDirection:'column', justifyContent:'flex-end',
      animation:'mf-fade .25s ease',
    }} onClick={onClose}>
      <div onClick={e=>e.stopPropagation()} style={{
        background:'#EFF5E8', borderTopLeftRadius:24, borderTopRightRadius:24,
        padding:'14px 20px 30px', boxShadow:'0 -20px 40px -10px rgba(15,42,30,0.3)',
        animation:'mf-rise .3s ease', maxHeight:'85%', overflowY:'auto',
      }}>
        {/* handle */}
        <div style={{ width:40, height:4, background:'#D9D2C4', borderRadius:2, margin:'0 auto 14px' }}/>

        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', marginBottom:12 }}>
          <div className="sf-display" style={{ fontSize:22, fontWeight:800, color:'#0F2A1E', letterSpacing:-0.6 }}>
            Categorías
          </div>
          <button onClick={onClose} style={{ background:'transparent', border:'none', fontSize:14, fontWeight:600, color:'#6F7A73', cursor:'pointer' }}>Listo</button>
        </div>

        {/* search */}
        <div style={{ background:'#FFFBF2', borderRadius:14, padding:'10px 12px',
          display:'flex', alignItems:'center', gap:8, border:'1px solid #EFE8D9', marginBottom:14 }}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="7" stroke="#6F7A73" strokeWidth="2"/><path d="M16 16l4 4" stroke="#6F7A73" strokeWidth="2" strokeLinecap="round"/></svg>
          <input value={query} onChange={e=>setQuery(e.target.value)} autoFocus
            placeholder="Buscar categoría..."
            style={{
              flex:1, border:'none', outline:'none', background:'transparent',
              fontSize:14, color:'#0F2A1E', fontWeight:500,
              fontFamily:'inherit',
            }}/>
          {query && (
            <button onClick={()=>setQuery('')} style={{ background:'transparent', border:'none', cursor:'pointer', padding:0, display:'grid', placeItems:'center' }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9" fill="#E9E1D3"/><path d="M9 9l6 6M15 9l-6 6" stroke="#6F7A73" strokeWidth="2" strokeLinecap="round"/></svg>
            </button>
          )}
        </div>

        {/* Todas + lista */}
        <button onClick={()=>setFilter('todas')} style={{
          width:'100%', padding:'12px 14px', borderRadius:14, cursor:'pointer',
          background: filter==='todas' ? '#0F2A1E' : '#FFFBF2',
          color: filter==='todas' ? '#F6FBEF' : '#0F2A1E',
          border: filter==='todas' ? '1px solid #0F2A1E' : '1px solid #EFE8D9',
          display:'flex', alignItems:'center', gap:12, marginBottom:8,
          textAlign:'left', fontFamily:'inherit',
        }}>
          <div style={{ width:36, height:36, borderRadius:10, background:'#D9D2C4', display:'grid', placeItems:'center', fontSize:18 }}>📋</div>
          <div style={{ flex:1 }}>
            <div style={{ fontSize:14, fontWeight:700 }}>Todas las categorías</div>
            <div style={{ fontSize:11, color: filter==='todas' ? 'rgba(255,255,255,0.65)' : '#6F7A73' }}>{total} movimiento{total!==1?'s':''}</div>
          </div>
          {filter==='todas' && <CheckIconLt color="#B1E382"/>}
        </button>

        {filtered.length === 0 && query && (
          <div style={{ padding:'20px 14px', textAlign:'center' }}>
            <div style={{ fontSize:13, color:'#6F7A73', marginBottom:10 }}>Sin resultados para "<b>{query}</b>"</div>
            <button style={{
              background:'linear-gradient(140deg,#C7EE9C,#8DD66A)', color:'#0E3A26',
              border:'none', padding:'10px 16px', borderRadius:999, fontSize:13, fontWeight:700, cursor:'pointer',
              display:'inline-flex', alignItems:'center', gap:6, fontFamily:'inherit',
            }}>
              <span style={{ fontSize:16 }}>+</span> Crear "{query}"
            </button>
          </div>
        )}

        <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
          {filtered.map(c => (
            <button key={c.id} onClick={()=>setFilter(c.id)} style={{
              width:'100%', padding:'12px 14px', borderRadius:14, cursor:'pointer',
              background: filter===c.id ? '#0F2A1E' : '#FFFBF2',
              color: filter===c.id ? '#F6FBEF' : '#0F2A1E',
              border: filter===c.id ? '1px solid #0F2A1E' : '1px solid #EFE8D9',
              display:'flex', alignItems:'center', gap:12,
              textAlign:'left', fontFamily:'inherit',
            }}>
              <div style={{
                width:36, height:36, borderRadius:10,
                background:`linear-gradient(140deg, ${c.color}25, ${c.color}12)`,
                border:`1px solid ${c.color}35`,
                display:'grid', placeItems:'center', fontSize:18,
              }}>{c.emoji}</div>
              <div style={{ flex:1 }}>
                <div style={{ fontSize:14, fontWeight:700 }}>{c.label}</div>
                <div style={{ fontSize:11, color: filter===c.id ? 'rgba(255,255,255,0.65)' : '#6F7A73' }}>
                  {c.count} movimiento{c.count!==1?'s':''}
                </div>
              </div>
              {filter===c.id && <CheckIconLt color="#B1E382"/>}
            </button>
          ))}
        </div>

        {/* Create new */}
        <button style={{
          marginTop:14, width:'100%', padding:'14px', borderRadius:14, cursor:'pointer',
          background:'#FFFBF2', color:'#0F2A1E', border:'1px dashed #D9D2C4',
          display:'flex', alignItems:'center', justifyContent:'center', gap:8,
          fontSize:14, fontWeight:700, fontFamily:'inherit',
        }}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M12 5v14M5 12h14" stroke="#0F2A1E" strokeWidth="2" strokeLinecap="round"/></svg>
          Crear nueva categoría
        </button>
      </div>
    </div>
  );
}

const CheckIconLt = ({ color='#B1E382' }) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M5 12l4 4 10-10" stroke={color} strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"/></svg>;
const SwipeHintIconLt = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" style={{ animation:'mf-swipe-hint 2.2s ease-in-out infinite' }}><path d="M15 5l-6 7 6 7" stroke="#6F7A73" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>;

function MonthCalendarGxLt({ movs, selectedDay, lastTappedDay, onSelectDay, onClear, onNext, onPrev }) {
  const today = 22, days = 30;
  // compute spend per day
  const spendByDay = {};
  movs.forEach(m => { spendByDay[m.day] = (spendByDay[m.day]||0) + Math.abs(m.amount); });
  // daily budget ≈ promedio del mes (actualmente gastado / today)
  const totalSoFar = Object.values(spendByDay).reduce((s,v)=>s+v,0);
  const dailyAvg = totalSoFar / Math.max(1, today);
  const amberThreshold = dailyAvg * 1.3;
  const redThreshold = dailyAvg * 2.0;

  // derive mood
  const mood = {};
  for (let i=1;i<=today;i++) {
    const s = spendByDay[i] || 0;
    if (s === 0) mood[i] = 'empty';
    else if (s >= redThreshold) mood[i] = 'red';
    else if (s >= amberThreshold) mood[i] = 'amber';
    else mood[i] = 'green';
  }

  // Si hay día seleccionado → FOCUS MODE
  if (selectedDay != null) {
    return <MonthCalendarFocusLt
      day={selectedDay} today={today} days={days}
      mood={mood[selectedDay]||'empty'}
      spent={spendByDay[selectedDay]||0}
      count={movs.filter(m => m.day===selectedDay).length}
      onClear={onClear} onNext={onNext} onPrev={onPrev}
    />;
  }

  return (
    <div style={{ margin:'14px 22px 0', background:'#FFFBF2', border:'1px solid #EFE8D9',
      borderRadius:18, padding:'14px', animation:'mf-rise .8s .35s ease both' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:4 }}>
        <div style={{ fontSize:10, letterSpacing:1.6, fontWeight:700, color:'#6F7A73' }}>TU MES EN UN VISTAZO</div>
        <div style={{ display:'flex', gap:8, fontSize:9, color:'#6F7A73', fontWeight:600 }}>
          <LegendDotGxLt color="#6FE09A" label="bien"/>
          <LegendDotGxLt color="#F2B58A" label="alerta"/>
          <LegendDotGxLt color="#D96A4F" label="exceso"/>
        </div>
      </div>
      <div style={{ fontSize:10, color:'#9AA39D', fontWeight:500, marginBottom:8 }}>Tocá un día para filtrar sus gastos</div>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(7, 1fr)', gap:5 }}>
        {['L','M','M','J','V','S','D'].map((d,i)=>(
          <div key={i} style={{ fontSize:9, textAlign:'center', color:'#9AA39D', fontWeight:700, letterSpacing:1, paddingBottom:2 }}>{d}</div>
        ))}
        {[0,1,2].map(i => <div key={'o'+i}/>)}
        {Array.from({length: days}, (_, idx) => {
          const n = idx+1;
          const m = mood[n];
          const past = n <= today;
          const bg = m==='green' ? '#DDEFE3'
                   : m==='amber' ? '#FADFC8'
                   : m==='red'   ? '#F5C6B6'
                   : 'transparent';
          const color = m==='green' ? '#2E7D5B'
                      : m==='amber' ? '#6B3A4F'
                      : m==='red'   ? '#A3452A'
                      : '#9AA39D';
          const border = !past ? '1px dashed #E9E1D3' : 'none';
          const isToday = n === today;
          const isLastTapped = n === lastTappedDay;
          return (
            <button key={n}
              onClick={past ? ()=>onSelectDay(n) : undefined}
              disabled={!past}
              style={{
                aspectRatio:'1', borderRadius:8,
                background: isToday ? '#0F2A1E' : bg,
                color: isToday ? '#FFFBF2' : color,
                display:'grid', placeItems:'center', fontSize:11, fontWeight:700,
                border: isLastTapped ? '2px solid #0F2A1E' : border,
                position:'relative',
                animation: isLastTapped ? 'mf-pulse-ring 1.6s ease-out' : `mf-fade .45s ${0.4 + n*0.012}s both`,
                boxShadow: isToday ? '0 6px 14px -4px rgba(15,42,30,0.4)' : 'none',
                cursor: past ? 'pointer' : 'default',
                padding:0, fontFamily:'inherit',
                transition:'transform .15s ease',
              }}
              onMouseDown={e => past && (e.currentTarget.style.transform = 'scale(0.92)')}
              onMouseUp={e => e.currentTarget.style.transform = ''}
              onMouseLeave={e => e.currentTarget.style.transform = ''}
            >
              {n}
              {isToday && <div style={{ position:'absolute', bottom:2, width:4, height:4, borderRadius:2, background:'#6FE09A', animation:'mf-breathe 1.6s ease-in-out infinite' }}/>}
            </button>
          );
        })}
      </div>
    </div>
  );
}

// FOCUS MODE — un solo día grande, chevrons, chip para volver (light)
function MonthCalendarFocusLt({ day, today, days, mood, spent, count, onClear, onNext, onPrev }) {
  const dayName = getDayName(day);
  const isToday = day === today;
  const moodLabel = mood==='green' ? 'Día tranquilo' : mood==='amber' ? 'Día de alerta' : mood==='red' ? 'Día de exceso' : 'Sin movimientos';
  const moodColor = mood==='green' ? '#2E7D5B' : mood==='amber' ? '#A3452A' : mood==='red' ? '#C03A2A' : '#9AA39D';
  const moodBg   = mood==='green' ? '#DDEFE3' : mood==='amber' ? '#FADFC8' : mood==='red' ? '#F5C6B6' : '#F4F1E8';
  const [touchStart, setTouchStart] = useStateGx(null);

  return (
    <div style={{ margin:'14px 22px 0', background:'#FFFBF2', border:'1px solid #EFE8D9',
      borderRadius:18, padding:'14px', animation:'mf-rise .4s ease both', position:'relative' }}
      onTouchStart={e => setTouchStart(e.touches[0].clientY)}
      onTouchEnd={e => {
        if (touchStart && e.changedTouches[0].clientY - touchStart > 50) onClear();
        setTouchStart(null);
      }}
    >
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:4 }}>
        <div style={{ fontSize:10, letterSpacing:1.6, fontWeight:700, color:'#6F7A73' }}>DÍA SELECCIONADO</div>
        <div style={{
          padding:'3px 8px', borderRadius:999, background: moodBg, color: moodColor,
          fontSize:10, fontWeight:700, letterSpacing:0.3,
        }}>{moodLabel}</div>
      </div>

      {/* hero: chevron + big number + chevron */}
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'8px 0 4px', gap:12 }}>
        <button onClick={onPrev} style={chevronBtnLt} aria-label="día anterior">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M15 6l-6 6 6 6" stroke="#0F2A1E" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/></svg>
        </button>
        <button onClick={onClear}
          style={{ flex:1, background:'transparent', border:'none', cursor:'pointer', padding:'4px 0', fontFamily:'inherit' }}
          title="Volver al mes">
          <div className="sf-display" style={{
            fontSize:88, fontWeight:800, color:'#0F2A1E', letterSpacing:-3, lineHeight:0.9,
            animation:'mf-day-pop .35s cubic-bezier(.2,.9,.2,1) both',
          }}>
            {day}
          </div>
          <div style={{ fontSize:12, color:'#6F7A73', fontWeight:600, marginTop:2 }}>
            {dayName} · abril {isToday && <span style={{ color:'#2E7D5B', fontWeight:700 }}>· hoy</span>}
          </div>
        </button>
        <button onClick={onNext} style={chevronBtnLt} aria-label="día siguiente">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M9 6l6 6-6 6" stroke="#0F2A1E" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/></svg>
        </button>
      </div>

      {/* stats */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8, marginTop:12, paddingTop:12, borderTop:'1px solid #EFE8D9' }}>
        <div>
          <div style={{ fontSize:9, color:'#6F7A73', fontWeight:700, letterSpacing:1.2 }}>GASTADO</div>
          <div className="sf-display" style={{ fontSize:18, fontWeight:800, color:'#0F2A1E', letterSpacing:-0.4, marginTop:2 }}>
            ${spent.toLocaleString('es-AR')}
          </div>
        </div>
        <div style={{ textAlign:'right' }}>
          <div style={{ fontSize:9, color:'#6F7A73', fontWeight:700, letterSpacing:1.2 }}>MOVIMIENTOS</div>
          <div className="sf-display" style={{ fontSize:18, fontWeight:800, color:'#0F2A1E', letterSpacing:-0.4, marginTop:2 }}>
            {count}
          </div>
        </div>
      </div>

      {/* back chip */}
      <div style={{ marginTop:12, display:'flex', justifyContent:'center' }}>
        <button onClick={onClear} style={{
          display:'inline-flex', alignItems:'center', gap:6,
          padding:'8px 14px', borderRadius:999, cursor:'pointer',
          background:'#0F2A1E', color:'#F6FBEF', border:'none',
          fontSize:12, fontWeight:700, fontFamily:'inherit',
          boxShadow:'0 6px 16px -6px rgba(15,42,30,0.4)',
        }}>
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none"><path d="M6 6l12 12M18 6L6 18" stroke="#F6FBEF" strokeWidth="2.2" strokeLinecap="round"/></svg>
          Abril completo
        </button>
      </div>
    </div>
  );
}

const chevronBtnLt = {
  width:36, height:36, borderRadius:999,
  background:'#EFF5E8', border:'1px solid #E9E1D3',
  display:'grid', placeItems:'center', cursor:'pointer',
  padding:0, fontFamily:'inherit',
};

function getDayName(d) {
  // abril 2024 — día 1 es lunes (approx for demo)
  const names = ['dom','lun','mar','mié','jue','vie','sáb'];
  const full = ['domingo','lunes','martes','miércoles','jueves','viernes','sábado'];
  // día 22 = lunes (offset base: día 1 = lunes)
  const idx = ((d - 1) % 7 + 1) % 7;
  return full[idx];
}
function LegendDotGxLt({ color, label }) {
  return <div style={{ display:'flex', alignItems:'center', gap:4 }}>
    <span style={{ width:7, height:7, borderRadius:4, background:color }}/>{label}
  </div>;
}

// VS mes pasado + Racha (light)
function CompareAndStreakGxLt({ movs }) {
  const totalSoFar = movs.reduce((s,m)=>s+Math.abs(m.amount),0);
  const prevMonthRef = 685000; // mock de referencia marzo
  const delta = Math.round(((totalSoFar - prevMonthRef) / prevMonthRef) * 100);
  const savingVsLast = delta < 0;
  return (
    <div style={{ padding:'14px 22px 0', display:'grid', gridTemplateColumns:'1fr 1fr', gap:10,
      animation:'mf-rise .9s .45s ease both' }}>
      <div style={{ background:'#FFFBF2', borderRadius:16, padding:'12px', border:'1px solid #EFE8D9' }}>
        <div style={{ fontSize:9, color:'#6F7A73', fontWeight:700, letterSpacing:1.2 }}>VS MARZO</div>
        <div className="sf-display" style={{ fontSize:22, fontWeight:800, color: savingVsLast?'#2E7D5B':'#A3452A', letterSpacing:-0.5, marginTop:2 }}>
          {savingVsLast?'':'+'}{delta}%
        </div>
        <div style={{ fontSize:10, color:'#6F7A73', fontWeight:600 }}>{savingVsLast?'gastás menos':'gastás más'}</div>
        <div style={{ display:'flex', alignItems:'flex-end', gap:3, marginTop:8, height:24 }}>
          {[0.5,0.7,0.6,0.85,1, savingVsLast?0.72:1.08].map((v,i)=>(
            <div key={i} style={{
              flex:1,
              height:`${Math.min(100,v*100)}%`,
              background: i===5 ? (savingVsLast?'#6FE09A':'#E08E63') : '#EFE8D9',
              borderRadius:2, animation:`mf-grow-bar .6s ${0.5+i*0.08}s ease both`, transformOrigin:'bottom',
            }}/>
          ))}
        </div>
      </div>
      <div style={{ background:'#FFFBF2', borderRadius:16, padding:'12px', border:'1px solid #EFE8D9' }}>
        <div style={{ fontSize:9, color:'#6F7A73', fontWeight:700, letterSpacing:1.2 }}>RACHA</div>
        <div className="sf-display" style={{ fontSize:22, fontWeight:800, color:'#0F2A1E', letterSpacing:-0.5, marginTop:2 }}>
          12 días
        </div>
        <div style={{ fontSize:10, color:'#6F7A73', fontWeight:600 }}>registrando gastos</div>
        <div style={{ marginTop:8, display:'flex', gap:3 }}>
          {Array.from({length:12}).map((_,i)=>(
            <div key={i} style={{
              flex:1, height:18, borderRadius:3,
              background:'linear-gradient(180deg,#C7EE9C,#6FE09A)',
              animation:`mf-grow-bar .5s ${0.6+i*0.04}s ease both`, transformOrigin:'bottom',
            }}/>
          ))}
        </div>
      </div>
    </div>
  );
}

function GastoRowLt({ mov, delay=0 }) {
  const cat = GASTOS_CATS.find(c=>c.id===mov.cat);
  const who = FAMILY[mov.who];
  const [swiped, setSwiped] = useStateGx(false);
  return (
    <div style={{ position:'relative', borderRadius:14, overflow:'hidden',
      animation:`mf-slide-in .5s ${delay}s ease both` }}>
      {/* action background */}
      <div style={{ position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'flex-end',
        paddingRight:14, gap:8,
        background:'linear-gradient(90deg, #FFFBF2 30%, #FADFC8 60%, #E08E63)' }}>
        <button style={{ width:32, height:32, borderRadius:10, border:'none', background:'rgba(255,255,255,0.9)', cursor:'pointer' }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" style={{ margin:'auto', display:'block' }}><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3" stroke="#A3452A" strokeWidth="1.8" strokeLinecap="round"/></svg>
        </button>
        <button style={{ width:32, height:32, borderRadius:10, border:'none', background:'rgba(255,255,255,0.9)', cursor:'pointer' }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" style={{ margin:'auto', display:'block' }}><path d="M4 20l4-1 11-11-3-3L5 16l-1 4z" stroke="#0F2A1E" strokeWidth="1.8" strokeLinejoin="round"/></svg>
        </button>
      </div>
      <div onClick={()=>setSwiped(s=>!s)} style={{
        background:'#FFFBF2', borderRadius:14, padding:'12px 14px',
        display:'flex', alignItems:'center', gap:12, border:'1px solid #EFE8D9',
        transform: swiped ? 'translateX(-90px)' : 'translateX(0)',
        transition:'transform .25s cubic-bezier(.2,.9,.2,1)',
        cursor:'pointer', position:'relative',
      }}>
        <div style={{ position:'relative', flexShrink:0 }}>
          <div style={{ width:38, height:38, borderRadius:12,
            background:`linear-gradient(140deg, ${cat.color}22, ${cat.color}11)`,
            display:'grid', placeItems:'center', fontSize:18, border:`1px solid ${cat.color}33` }}>
            {cat.emoji}
          </div>
          <div style={{ position:'absolute', bottom:-3, right:-3 }}>
            <Avatar name={who.name} color={who.color} size={16} ring ringColor="#FFFBF2"/>
          </div>
        </div>
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ fontSize:14, fontWeight:700, color:'#0F2A1E' }}>{mov.title}</div>
          <div style={{ fontSize:11, color:'#6F7A73', display:'flex', alignItems:'center', gap:6, marginTop:2 }}>
            <span style={{
              padding:'2px 7px', borderRadius:999, background:`${cat.color}18`, color:cat.color, fontWeight:700, fontSize:10,
              border:`1px solid ${cat.color}25`,
            }}>{cat.label}</span>
            · {who.name} · {mov.time}
          </div>
        </div>
        <div style={{ textAlign:'right' }}>
          <div style={{ fontSize:14, fontWeight:800, color:'#0F2A1E' }}>-${Math.abs(mov.amount).toLocaleString('es-AR')}</div>
          <div style={{ fontSize:9, color:'#9AA39D', fontWeight:700, letterSpacing:1 }}>DESLIZÁ</div>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// GASTOS — DARK
// ─────────────────────────────────────────────────────────────
function GastosDark() {
  const [filter, setFilter] = useStateGx('todas');
  const [selectedDay, setSelectedDay] = useStateGx(null);
  const [lastTappedDay, setLastTappedDay] = useStateGx(null);
  const DAYS_IN_MONTH = 30;
  const byCatFilter = filter==='todas' ? GASTOS_MOVS : GASTOS_MOVS.filter(m => m.cat===filter);
  const filtered = selectedDay ? byCatFilter.filter(m => m.day===selectedDay) : byCatFilter;
  const total = filtered.reduce((s,m)=>s+Math.abs(m.amount), 0);
  const cats = byCat(filtered);
  const groups = groupByDay(filtered);

  const openDay = (d) => { setSelectedDay(d); };
  const closeDay = () => { setLastTappedDay(selectedDay); setSelectedDay(null); setTimeout(()=>setLastTappedDay(null), 1600); };
  const nextDay = () => setSelectedDay(d => d >= DAYS_IN_MONTH ? 1 : d+1);
  const prevDay = () => setSelectedDay(d => d <= 1 ? DAYS_IN_MONTH : d-1);

  return (
    <div className="screen" style={{ background:'#0A1410', overflowY:'auto' }}>
      <StatusBar color="#F6FBEF"/>

      {/* ambient glows */}
      <div style={{ position:'absolute', top:-70, right:-50, width:260, height:260, borderRadius:'50%',
        background:'radial-gradient(closest-side, rgba(111,224,154,0.22), transparent 70%)',
        animation:'mf-float-slow 9s ease-in-out infinite', pointerEvents:'none' }}/>
      <div style={{ position:'absolute', top:700, left:-70, width:220, height:220, borderRadius:'50%',
        background:'radial-gradient(closest-side, rgba(232,151,106,0.18), transparent 70%)',
        animation:'mf-float-slow 11s ease-in-out infinite', animationDelay:'-3s', pointerEvents:'none' }}/>

      <div style={{ padding:'2px 22px 0', display:'flex', alignItems:'flex-start', justifyContent:'space-between',
        animation:'mf-rise .6s ease both' }}>
        <div>
          <div className="sf-display" style={{ fontSize:34, fontWeight:800, color:'#F6FBEF', letterSpacing:-1.2, lineHeight:1 }}>
            Gastos
          </div>
          <div style={{ fontSize:13, color:'#8FA094', marginTop:6, maxWidth:230, lineHeight:1.35 }}>
            Historial, filtros y edición rápida de movimientos.
          </div>
        </div>
        <button style={{
          marginTop:6,
          width:40, height:40, borderRadius:999, cursor:'pointer',
          background:'linear-gradient(140deg, #C7EE9C, #8DD66A)',
          border:'none', color:'#0A1410',
          display:'grid', placeItems:'center',
          boxShadow:'0 8px 18px -6px rgba(199,238,156,0.5)',
          animation:'mf-pulse 2.2s ease-out infinite',
        }}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M12 5v14M5 12h14" stroke="#0A1410" strokeWidth="2.4" strokeLinecap="round"/></svg>
        </button>
      </div>

      <div style={{ margin:'14px 22px 0',
        background:'linear-gradient(160deg, #133827 0%, #1F6B43 55%, #2E9A5F 100%)',
        borderRadius:24, padding:'18px 20px', color:'#F6FBEF', position:'relative', overflow:'hidden',
        animation:'mf-rise .8s .1s ease both',
        border:'1px solid #1F332A',
        boxShadow:'0 20px 40px -20px rgba(0,0,0,0.7), inset 0 1px 0 rgba(199,238,156,0.12)',
      }}>
        <div style={{ position:'absolute', inset:0, pointerEvents:'none', overflow:'hidden', borderRadius:24 }}>
          <div style={{ position:'absolute', top:0, left:0, width:'40%', height:'100%',
            background:'linear-gradient(120deg, transparent, rgba(255,255,255,0.08), transparent)',
            animation:'mf-shine 4.2s 1s ease-in-out infinite' }}/>
        </div>

        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
          <div style={{ fontSize:11, letterSpacing:1.6, fontWeight:700, color:'#C7EE9C' }}>TOTAL VISIBLE</div>
          <div style={{ fontSize:10, color:'rgba(246,251,239,0.6)', fontWeight:600, padding:'3px 8px',
            background:'rgba(246,251,239,0.08)', borderRadius:999 }}>
            {filtered.length} mov · {selectedDay ? `día ${selectedDay}` : 'abril'} · {filter==='todas'?'Todas':GASTOS_CATS.find(c=>c.id===filter)?.label}
          </div>
        </div>

        <div className="sf-display" style={{ fontSize:42, fontWeight:800, lineHeight:1, marginTop:10, letterSpacing:-1.8 }}>
          <CountUp to={total} duration={1200} prefix="$"/>
        </div>

        <div style={{ marginTop:14 }}>
          <div style={{ fontSize:10, color:'rgba(246,251,239,0.55)', fontWeight:600, letterSpacing:1.2 }}>MÁS PESO POR CATEGORÍA</div>
          <div style={{ marginTop:6, display:'flex', flexDirection:'column', gap:6 }}>
            {cats.slice(0,3).map((c,i)=>{
              const pct = Math.round((c.amount/total)*100);
              return (
                <div key={c.id} style={{ animation:`mf-rise .6s ${0.2+i*0.08}s both` }}>
                  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', fontSize:12, marginBottom:4 }}>
                    <div style={{ display:'flex', alignItems:'center', gap:6, fontWeight:600 }}>
                      <span style={{ width:7, height:7, borderRadius:4, background:c.darkColor }}/>
                      {c.label}
                    </div>
                    <div style={{ fontWeight:700 }}>${c.amount.toLocaleString('es-AR')} <span style={{ color:'rgba(246,251,239,0.55)', fontWeight:500 }}>· {pct}%</span></div>
                  </div>
                  <div style={{ height:6, background:'rgba(246,251,239,0.1)', borderRadius:3, overflow:'hidden' }}>
                    <div style={{ width:`${pct}%`, height:'100%',
                      background:`linear-gradient(90deg, ${c.darkColor}, ${shade(c.darkColor,20)})`,
                      borderRadius:3, transformOrigin:'left',
                      animation:`mf-grow-bar 1s ${0.4+i*0.1}s cubic-bezier(.2,.9,.2,1) both`,
                      boxShadow:`0 0 8px ${c.darkColor}44` }}/>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div style={{ padding:'12px 22px 0', display:'grid', gridTemplateColumns:'1fr 1fr', gap:10,
        animation:'mf-rise .8s .25s ease both' }}>
        <InsightCardDk
          label="PROMEDIO DÍA" value={`$${Math.round(total/22).toLocaleString('es-AR')}`} sub="últimos 22 días" subColor="#8FA094"
          chart={
            <div style={{ display:'flex', gap:3, alignItems:'flex-end', height:24 }}>
              {[0.4,0.6,0.3,0.7,0.5,0.8,0.55].map((v,i)=>(
                <div key={i} style={{ flex:1, height:`${v*100}%`, background:'#C7EE9C', borderRadius:2,
                  transformOrigin:'bottom', animation:`mf-grow-bar .6s ${0.5+i*0.06}s ease both`,
                  boxShadow:'0 0 6px rgba(199,238,156,0.4)' }}/>
              ))}
            </div>
          }
        />
        <InsightCardDk
          label="RACHA DE REGISTRO" value="14 días" sub="sin olvidarte" subColor="#E8976A"
          chart={<div style={{ fontSize:24, animation:'mf-wiggle 2s ease-in-out infinite', filter:'drop-shadow(0 0 8px rgba(232,151,106,0.5))' }}>🔥</div>}
        />
      </div>

      <MonthCalendarGxDk movs={byCatFilter} onDayClick={openDay} selectedDay={selectedDay} lastTappedDay={lastTappedDay}/>

      <SmartFilterDk
        allCats={GASTOS_CATS}
        movs={GASTOS_MOVS}
        filter={filter}
        setFilter={setFilter}
      />

      <div style={{ padding:'14px 22px 0', display:'flex', justifyContent:'space-between', alignItems:'baseline' }}>
        <div className="sf-display" style={{ fontSize:20, fontWeight:800, color:'#F6FBEF', letterSpacing:-0.5 }}>Movimientos</div>
        <div style={{ fontSize:11, color:'#8FA094', display:'flex', alignItems:'center', gap:4 }}>
          <SwipeHintIconDk/> Desliza para acciones
        </div>
      </div>

      <div style={{ margin:'8px 22px 0', display:'flex', flexDirection:'column', gap:14 }}>
        {groups.map((g, gi) => (
          <div key={g.label} style={{ animation:`mf-rise .6s ${0.35+gi*0.08}s ease both` }}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', padding:'0 2px 6px' }}>
              <div>
                <div style={{ fontSize:14, fontWeight:700, color:'#F6FBEF' }}>{g.label}</div>
                <div style={{ fontSize:11, color:'#6A7A70' }}>{g.items.length} movimiento{g.items.length!==1?'s':''}</div>
              </div>
              <div style={{ fontSize:14, fontWeight:800, color:'#F6FBEF' }}>-${g.total.toLocaleString('es-AR')}</div>
            </div>
            <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
              {g.items.map((m,i) => (
                <GastoRowDk key={m.id} mov={m} delay={0.4+gi*0.08+i*0.04}/>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div style={{ height:120 }}/>

      <TabBarGxDk/>
    </div>
  );
}

// Dark sub-components
function CircleBtnDk2({ children }) {
  return <button style={{
    width:38, height:38, border:'1px solid #1F332A', borderRadius:999, background:'#13221B',
    display:'grid', placeItems:'center', cursor:'pointer',
    boxShadow:'0 2px 8px rgba(0,0,0,0.35)',
  }}>{children}</button>;
}
const SortIconDk = () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M7 4v16M7 20l-3-3M7 20l3-3M17 20V4M17 4l-3 3M17 4l3 3" stroke="#E8F2E0" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>;
const FilterIconDk = () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M4 6h16M7 12h10M10 18h4" stroke="#E8F2E0" strokeWidth="1.8" strokeLinecap="round"/></svg>;

function InsightCardDk({ label, value, sub, subColor, chart }) {
  return (
    <div style={{ background:'#13221B', borderRadius:16, padding:'12px', border:'1px solid #1F332A',
      position:'relative', overflow:'hidden' }}>
      <div style={{ fontSize:9, color:'#8FA094', fontWeight:700, letterSpacing:1.2 }}>{label}</div>
      <div className="sf-display" style={{ fontSize:20, fontWeight:800, letterSpacing:-0.4, marginTop:2, color:'#F6FBEF' }}>{value}</div>
      <div style={{ fontSize:10, color: subColor, fontWeight:700 }}>{sub}</div>
      <div style={{ marginTop:6 }}>{chart}</div>
    </div>
  );
}

function FilterPillDk({ active, label, count, emoji, color='#C7EE9C', onClick, small }) {
  return (
    <button onClick={onClick} style={{
      flex:'0 0 auto', display:'inline-flex', alignItems:'center', gap:6,
      padding: small ? '6px 10px' : '8px 12px', borderRadius:999, cursor:'pointer', whiteSpace:'nowrap',
      background: active ? 'linear-gradient(140deg,#C7EE9C,#8DD66A)' : '#13221B',
      color: active ? '#0A1410' : '#F6FBEF',
      border: active ? '1px solid #C7EE9C' : '1px solid #1F332A',
      fontSize: small ? 11 : 12, fontWeight:700,
      boxShadow: active ? '0 8px 18px -6px rgba(199,238,156,0.4)' : 'none',
      transition:'all .2s ease',
    }}>
      <span style={{ fontSize: small ? 12 : 14 }}>{emoji}</span>
      {label}
      <span style={{
        fontSize:10, fontWeight:700,
        padding:'1px 6px', borderRadius:999,
        background: active ? 'rgba(10,20,16,0.2)' : '#0A1410',
        color: active ? '#0A1410' : color,
      }}>{count}</span>
    </button>
  );
}

// ─────────────────────────────────────────────────────────────
// SMART FILTER (dark)
// ─────────────────────────────────────────────────────────────
function SmartFilterDk({ allCats, movs, filter, setFilter }) {
  const [sheetOpen, setSheetOpen] = useStateGx(false);
  const [query, setQuery] = useStateGx('');

  const usage = {};
  movs.forEach(m => { usage[m.cat] = (usage[m.cat]||0) + 1; });
  const ranked = [...allCats]
    .map(c => ({ ...c, count: usage[c.id]||0, _color: c.darkColor || c.color }))
    .sort((a,b) => b.count - a.count);

  const topFour = ranked.filter(c => c.count > 0).slice(0, 4);
  const topFourIds = new Set(topFour.map(c => c.id));
  const activeCat = allCats.find(c => c.id === filter);
  const activeIsHidden = filter !== 'todas' && activeCat && !topFourIds.has(filter);

  const filteredInSheet = ranked.filter(c =>
    c.label.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <>
      <div style={{ padding:'14px 22px 0', animation:'mf-rise .8s .3s ease both' }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:8 }}>
          <div style={{ fontSize:10, letterSpacing:1.6, fontWeight:700, color:'#8FA094' }}>FILTRAR POR CATEGORÍA</div>
          <button onClick={()=>setSheetOpen(true)} style={{
            fontSize:11, fontWeight:700, color:'#C7EE9C', background:'transparent', border:'none',
            cursor:'pointer', display:'flex', alignItems:'center', gap:4, padding:0,
          }}>
            Ver todas
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none"><path d="M9 6l6 6-6 6" stroke="#C7EE9C" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
          </button>
        </div>
        <div style={{ display:'flex', gap:6, flexWrap:'wrap', alignItems:'center' }}>
          <FilterPillDk active={filter==='todas'} onClick={()=>setFilter('todas')}
            label="Todas" count={movs.length} emoji="📋"/>
          {topFour.map(c => (
            <FilterPillDk key={c.id} active={filter===c.id} onClick={()=>setFilter(c.id)}
              label={c.label} count={c.count} emoji={c.emoji} color={c._color}/>
          ))}
          {activeIsHidden && (
            <FilterPillDk active onClick={()=>setFilter('todas')}
              label={activeCat.label} count={usage[activeCat.id]||0} emoji={activeCat.emoji} color={activeCat.darkColor||activeCat.color}/>
          )}
          <button onClick={()=>setSheetOpen(true)} style={{
            flex:'0 0 auto', display:'inline-flex', alignItems:'center', gap:4,
            padding:'8px 10px', borderRadius:999, cursor:'pointer',
            background:'#13221B', color:'#8FA094',
            border:'1px dashed #2A3D33', fontSize:12, fontWeight:700,
          }}>
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="7" stroke="#8FA094" strokeWidth="2"/><path d="M16 16l4 4" stroke="#8FA094" strokeWidth="2" strokeLinecap="round"/></svg>
            Buscar
          </button>
        </div>
      </div>

      {sheetOpen && (
        <CategorySheetDk
          cats={ranked}
          filtered={filteredInSheet}
          query={query} setQuery={setQuery}
          filter={filter} setFilter={(id)=>{setFilter(id); setSheetOpen(false);}}
          total={movs.length}
          onClose={()=>setSheetOpen(false)}
        />
      )}
    </>
  );
}

function CategorySheetDk({ cats, filtered, query, setQuery, filter, setFilter, total, onClose }) {
  return (
    <div style={{
      position:'absolute', inset:0, zIndex:50,
      background:'rgba(0,0,0,0.6)', backdropFilter:'blur(4px)',
      display:'flex', flexDirection:'column', justifyContent:'flex-end',
      animation:'mf-fade .25s ease',
    }} onClick={onClose}>
      <div onClick={e=>e.stopPropagation()} style={{
        background:'#0E1A15', borderTopLeftRadius:24, borderTopRightRadius:24,
        padding:'14px 20px 30px', boxShadow:'0 -20px 40px -10px rgba(0,0,0,0.6)',
        animation:'mf-rise .3s ease', maxHeight:'85%', overflowY:'auto',
        border:'1px solid #1F332A',
      }}>
        <div style={{ width:40, height:4, background:'#2A3D33', borderRadius:2, margin:'0 auto 14px' }}/>

        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', marginBottom:12 }}>
          <div className="sf-display" style={{ fontSize:22, fontWeight:800, color:'#F6FBEF', letterSpacing:-0.6 }}>
            Categorías
          </div>
          <button onClick={onClose} style={{ background:'transparent', border:'none', fontSize:14, fontWeight:600, color:'#C7EE9C', cursor:'pointer' }}>Listo</button>
        </div>

        <div style={{ background:'#13221B', borderRadius:14, padding:'10px 12px',
          display:'flex', alignItems:'center', gap:8, border:'1px solid #1F332A', marginBottom:14 }}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="7" stroke="#8FA094" strokeWidth="2"/><path d="M16 16l4 4" stroke="#8FA094" strokeWidth="2" strokeLinecap="round"/></svg>
          <input value={query} onChange={e=>setQuery(e.target.value)} autoFocus
            placeholder="Buscar categoría..."
            style={{
              flex:1, border:'none', outline:'none', background:'transparent',
              fontSize:14, color:'#F6FBEF', fontWeight:500,
              fontFamily:'inherit',
            }}/>
          {query && (
            <button onClick={()=>setQuery('')} style={{ background:'transparent', border:'none', cursor:'pointer', padding:0, display:'grid', placeItems:'center' }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9" fill="#2A3D33"/><path d="M9 9l6 6M15 9l-6 6" stroke="#8FA094" strokeWidth="2" strokeLinecap="round"/></svg>
            </button>
          )}
        </div>

        <button onClick={()=>setFilter('todas')} style={{
          width:'100%', padding:'12px 14px', borderRadius:14, cursor:'pointer',
          background: filter==='todas' ? 'linear-gradient(140deg,#C7EE9C,#8DD66A)' : '#13221B',
          color: filter==='todas' ? '#0A1410' : '#F6FBEF',
          border: filter==='todas' ? '1px solid #C7EE9C' : '1px solid #1F332A',
          display:'flex', alignItems:'center', gap:12, marginBottom:8,
          textAlign:'left', fontFamily:'inherit',
        }}>
          <div style={{ width:36, height:36, borderRadius:10, background: filter==='todas' ? 'rgba(10,20,16,0.2)' : '#0E1A15', display:'grid', placeItems:'center', fontSize:18 }}>📋</div>
          <div style={{ flex:1 }}>
            <div style={{ fontSize:14, fontWeight:700 }}>Todas las categorías</div>
            <div style={{ fontSize:11, color: filter==='todas' ? 'rgba(10,20,16,0.7)' : '#8FA094' }}>{total} movimiento{total!==1?'s':''}</div>
          </div>
          {filter==='todas' && <CheckIconDk color="#0A1410"/>}
        </button>

        {filtered.length === 0 && query && (
          <div style={{ padding:'20px 14px', textAlign:'center' }}>
            <div style={{ fontSize:13, color:'#8FA094', marginBottom:10 }}>Sin resultados para "<b style={{color:'#F6FBEF'}}>{query}</b>"</div>
            <button style={{
              background:'linear-gradient(140deg,#C7EE9C,#8DD66A)', color:'#0A1410',
              border:'none', padding:'10px 16px', borderRadius:999, fontSize:13, fontWeight:700, cursor:'pointer',
              display:'inline-flex', alignItems:'center', gap:6, fontFamily:'inherit',
            }}>
              <span style={{ fontSize:16 }}>+</span> Crear "{query}"
            </button>
          </div>
        )}

        <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
          {filtered.map(c => (
            <button key={c.id} onClick={()=>setFilter(c.id)} style={{
              width:'100%', padding:'12px 14px', borderRadius:14, cursor:'pointer',
              background: filter===c.id ? 'linear-gradient(140deg,#C7EE9C,#8DD66A)' : '#13221B',
              color: filter===c.id ? '#0A1410' : '#F6FBEF',
              border: filter===c.id ? '1px solid #C7EE9C' : '1px solid #1F332A',
              display:'flex', alignItems:'center', gap:12,
              textAlign:'left', fontFamily:'inherit',
            }}>
              <div style={{
                width:36, height:36, borderRadius:10,
                background: filter===c.id ? 'rgba(10,20,16,0.15)' : `linear-gradient(140deg, ${c._color}30, ${c._color}10)`,
                border: filter===c.id ? 'none' : `1px solid ${c._color}40`,
                display:'grid', placeItems:'center', fontSize:18,
              }}>{c.emoji}</div>
              <div style={{ flex:1 }}>
                <div style={{ fontSize:14, fontWeight:700 }}>{c.label}</div>
                <div style={{ fontSize:11, color: filter===c.id ? 'rgba(10,20,16,0.7)' : '#8FA094' }}>
                  {c.count} movimiento{c.count!==1?'s':''}
                </div>
              </div>
              {filter===c.id && <CheckIconDk color="#0A1410"/>}
            </button>
          ))}
        </div>

        <button style={{
          marginTop:14, width:'100%', padding:'14px', borderRadius:14, cursor:'pointer',
          background:'#13221B', color:'#C7EE9C', border:'1px dashed #2A3D33',
          display:'flex', alignItems:'center', justifyContent:'center', gap:8,
          fontSize:14, fontWeight:700, fontFamily:'inherit',
        }}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M12 5v14M5 12h14" stroke="#C7EE9C" strokeWidth="2" strokeLinecap="round"/></svg>
          Crear nueva categoría
        </button>
      </div>
    </div>
  );
}

const CheckIconDk = ({ color='#0A1410' }) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M5 12l4 4 10-10" stroke={color} strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"/></svg>;
const SwipeHintIconDk = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" style={{ animation:'mf-swipe-hint 2.2s ease-in-out infinite' }}><path d="M15 5l-6 7 6 7" stroke="#8FA094" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>;

function MonthCalendarGxDk({ movs, onDayClick, selectedDay, lastTappedDay }) {
  const today = 22, days = 30;
  const spendByDay = {};
  movs.forEach(m => { spendByDay[m.day] = (spendByDay[m.day]||0) + Math.abs(m.amount); });
  const totalSoFar = Object.values(spendByDay).reduce((s,v)=>s+v,0);
  const dailyAvg = totalSoFar / Math.max(1, today);
  const amberThreshold = dailyAvg * 1.3;
  const redThreshold = dailyAvg * 2.0;

  const mood = {};
  for (let i=1;i<=today;i++) {
    const s = spendByDay[i] || 0;
    if (s === 0) mood[i] = 'empty';
    else if (s >= redThreshold) mood[i] = 'red';
    else if (s >= amberThreshold) mood[i] = 'amber';
    else mood[i] = 'green';
  }

  // Focus mode cuando hay día seleccionado
  if (selectedDay != null) {
    return <MonthCalendarFocusDk
      day={selectedDay} today={today} days={days}
      mood={mood[selectedDay]||'empty'}
      spent={spendByDay[selectedDay]||0}
      count={movs.filter(m => m.day===selectedDay).length}
      onClear={() => onDayClick(null)}
      onNext={() => onDayClick(selectedDay >= days ? 1 : selectedDay+1)}
      onPrev={() => onDayClick(selectedDay <= 1 ? days : selectedDay-1)}
    />;
  }

  return (
    <div style={{ margin:'14px 22px 0', background:'#13221B', border:'1px solid #1F332A',
      borderRadius:18, padding:'14px', animation:'mf-rise .8s .35s ease both' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:4 }}>
        <div style={{ fontSize:10, letterSpacing:1.6, fontWeight:700, color:'#8FA094' }}>TU MES EN UN VISTAZO</div>
        <div style={{ display:'flex', gap:8, fontSize:9, color:'#8FA094', fontWeight:600 }}>
          <LegendDotGxDk color="#6FE09A" label="bien"/>
          <LegendDotGxDk color="#F2B58A" label="alerta"/>
          <LegendDotGxDk color="#D96A4F" label="exceso"/>
        </div>
      </div>
      <div style={{ fontSize:10, color:'#6A7A70', fontWeight:500, marginBottom:8 }}>Tocá un día para filtrar sus gastos</div>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(7, 1fr)', gap:5 }}>
        {['L','M','M','J','V','S','D'].map((d,i)=>(
          <div key={i} style={{ fontSize:9, textAlign:'center', color:'#6A7A70', fontWeight:700, letterSpacing:1, paddingBottom:2 }}>{d}</div>
        ))}
        {[0,1,2].map(i => <div key={'o'+i}/>)}
        {Array.from({length: days}, (_, idx) => {
          const n = idx+1;
          const m = mood[n];
          const past = n <= today;
          const bg = m==='green' ? '#1F4F30'
                   : m==='amber' ? '#3A2A22'
                   : m==='red'   ? '#4A201A'
                   : 'transparent';
          const color = m==='green' ? '#9EE0B2'
                      : m==='amber' ? '#F2B58A'
                      : m==='red'   ? '#E88A70'
                      : '#3A4A40';
          const border = !past ? '1px dashed #1F332A' : 'none';
          const isToday = n === today;
          const isSelected = selectedDay === n;
          const isClickable = past && m !== 'empty' && onDayClick;
          const justClosed = lastTappedDay === n;
          return (
            <div key={n}
              onClick={isClickable ? (e)=>{ e.stopPropagation(); onDayClick(n); } : undefined}
              style={{
                aspectRatio:'1', borderRadius:8,
                background: isSelected ? 'linear-gradient(140deg,#F6FBEF,#C7EE9C)'
                           : isToday ? 'linear-gradient(140deg,#C7EE9C,#8DD66A)'
                           : bg,
                color: isSelected ? '#0A1410' : isToday ? '#0A1410' : color,
                display:'grid', placeItems:'center', fontSize:11, fontWeight:700,
                border: isSelected ? '2px solid #F6FBEF' : border,
                position:'relative',
                animation: justClosed ? 'mf-day-pop .5s ease both' : `mf-fade .45s ${0.4 + n*0.012}s both`,
                boxShadow: isSelected ? '0 8px 20px -4px rgba(246,251,239,0.4), 0 0 0 3px rgba(246,251,239,0.15)'
                          : isToday ? '0 6px 16px -4px rgba(199,238,156,0.5)'
                          : 'none',
                cursor: isClickable ? 'pointer' : 'default',
                transform: isSelected ? 'scale(1.08)' : 'scale(1)',
                transition: 'transform .2s cubic-bezier(.2,.9,.2,1), box-shadow .2s ease',
                zIndex: isSelected ? 2 : 1,
              }}>
              {n}
              {isToday && !isSelected && <div style={{ position:'absolute', bottom:2, width:4, height:4, borderRadius:2, background:'#0A1410', animation:'mf-breathe 1.6s ease-in-out infinite' }}/>}
            </div>
          );
        })}
      </div>
    </div>
  );
}
function LegendDotGxDk({ color, label }) {
  return <div style={{ display:'flex', alignItems:'center', gap:4 }}>
    <span style={{ width:7, height:7, borderRadius:4, background:color }}/>{label}
  </div>;
}

// FOCUS MODE — un solo día grande (dark)
function MonthCalendarFocusDk({ day, today, days, mood, spent, count, onClear, onNext, onPrev }) {
  const dayName = getDayName(day);
  const isToday = day === today;
  const moodLabel = mood==='green' ? 'Día tranquilo' : mood==='amber' ? 'Día de alerta' : mood==='red' ? 'Día de exceso' : 'Sin movimientos';
  const moodColor = mood==='green' ? '#9EE0B2' : mood==='amber' ? '#F2B58A' : mood==='red' ? '#E88A70' : '#8FA094';
  const moodBg   = mood==='green' ? '#1F4F30' : mood==='amber' ? '#3A2A22' : mood==='red' ? '#4A201A' : '#13221B';
  const [touchStart, setTouchStart] = useStateGx(null);

  return (
    <div style={{ margin:'14px 22px 0', background:'#13221B', border:'1px solid #1F332A',
      borderRadius:18, padding:'14px', animation:'mf-rise .4s ease both', position:'relative' }}
      onTouchStart={e => setTouchStart(e.touches[0].clientY)}
      onTouchEnd={e => {
        if (touchStart && e.changedTouches[0].clientY - touchStart > 50) onClear();
        setTouchStart(null);
      }}
    >
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:4 }}>
        <div style={{ fontSize:10, letterSpacing:1.6, fontWeight:700, color:'#8FA094' }}>DÍA SELECCIONADO</div>
        <div style={{
          padding:'3px 8px', borderRadius:999, background: moodBg, color: moodColor,
          fontSize:10, fontWeight:700, letterSpacing:0.3,
          border: `1px solid ${moodColor}33`,
        }}>{moodLabel}</div>
      </div>

      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'8px 0 4px', gap:12 }}>
        <button onClick={onPrev} style={chevronBtnDk} aria-label="día anterior">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M15 6l-6 6 6 6" stroke="#F6FBEF" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/></svg>
        </button>
        <button onClick={onClear}
          style={{ flex:1, background:'transparent', border:'none', cursor:'pointer', padding:'4px 0', fontFamily:'inherit' }}
          title="Volver al mes">
          <div className="sf-display" style={{
            fontSize:88, fontWeight:800, color:'#F6FBEF', letterSpacing:-3, lineHeight:0.9,
            animation:'mf-day-pop .35s cubic-bezier(.2,.9,.2,1) both',
            textShadow:'0 0 24px rgba(199,238,156,0.2)',
          }}>
            {day}
          </div>
          <div style={{ fontSize:12, color:'#8FA094', fontWeight:600, marginTop:2 }}>
            {dayName} · abril {isToday && <span style={{ color:'#9EE0B2', fontWeight:700 }}>· hoy</span>}
          </div>
        </button>
        <button onClick={onNext} style={chevronBtnDk} aria-label="día siguiente">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M9 6l6 6-6 6" stroke="#F6FBEF" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/></svg>
        </button>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8, marginTop:12, paddingTop:12, borderTop:'1px solid #1F332A' }}>
        <div>
          <div style={{ fontSize:9, color:'#8FA094', fontWeight:700, letterSpacing:1.2 }}>GASTADO</div>
          <div className="sf-display" style={{ fontSize:18, fontWeight:800, color:'#F6FBEF', letterSpacing:-0.4, marginTop:2 }}>
            ${spent.toLocaleString('es-AR')}
          </div>
        </div>
        <div style={{ textAlign:'right' }}>
          <div style={{ fontSize:9, color:'#8FA094', fontWeight:700, letterSpacing:1.2 }}>MOVIMIENTOS</div>
          <div className="sf-display" style={{ fontSize:18, fontWeight:800, color:'#F6FBEF', letterSpacing:-0.4, marginTop:2 }}>
            {count}
          </div>
        </div>
      </div>

      <div style={{ marginTop:12, display:'flex', justifyContent:'center' }}>
        <button onClick={onClear} style={{
          display:'inline-flex', alignItems:'center', gap:6,
          padding:'8px 14px', borderRadius:999, cursor:'pointer',
          background:'linear-gradient(140deg,#C7EE9C,#8DD66A)', color:'#0A1410', border:'none',
          fontSize:12, fontWeight:700, fontFamily:'inherit',
          boxShadow:'0 6px 16px -6px rgba(199,238,156,0.5)',
        }}>
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none"><path d="M6 6l12 12M18 6L6 18" stroke="#0A1410" strokeWidth="2.2" strokeLinecap="round"/></svg>
          Abril completo
        </button>
      </div>
    </div>
  );
}

const chevronBtnDk = {
  width:36, height:36, borderRadius:999,
  background:'#0E1A15', border:'1px solid #1F332A',
  display:'grid', placeItems:'center', cursor:'pointer',
  padding:0, fontFamily:'inherit',
};

function CompareAndStreakGxDk({ movs }) {
  const totalSoFar = movs.reduce((s,m)=>s+Math.abs(m.amount),0);
  const prevMonthRef = 685000;
  const delta = Math.round(((totalSoFar - prevMonthRef) / prevMonthRef) * 100);
  const savingVsLast = delta < 0;
  return (
    <div style={{ padding:'14px 22px 0', display:'grid', gridTemplateColumns:'1fr 1fr', gap:10,
      animation:'mf-rise .9s .45s ease both' }}>
      <div style={{ background:'#13221B', borderRadius:16, padding:'12px', border:'1px solid #1F332A' }}>
        <div style={{ fontSize:9, color:'#8FA094', fontWeight:700, letterSpacing:1.2 }}>VS MARZO</div>
        <div className="sf-display" style={{ fontSize:22, fontWeight:800, color: savingVsLast?'#6FE09A':'#E8976A', letterSpacing:-0.5, marginTop:2 }}>
          {savingVsLast?'':'+'}{delta}%
        </div>
        <div style={{ fontSize:10, color:'#8FA094', fontWeight:600 }}>{savingVsLast?'gastás menos':'gastás más'}</div>
        <div style={{ display:'flex', alignItems:'flex-end', gap:3, marginTop:8, height:24 }}>
          {[0.5,0.7,0.6,0.85,1, savingVsLast?0.72:1.08].map((v,i)=>(
            <div key={i} style={{
              flex:1,
              height:`${Math.min(100,v*100)}%`,
              background: i===5 ? (savingVsLast?'#6FE09A':'#E8976A') : '#1F332A',
              borderRadius:2, animation:`mf-grow-bar .6s ${0.5+i*0.08}s ease both`, transformOrigin:'bottom',
            }}/>
          ))}
        </div>
      </div>
      <div style={{ background:'#13221B', borderRadius:16, padding:'12px', border:'1px solid #1F332A' }}>
        <div style={{ fontSize:9, color:'#8FA094', fontWeight:700, letterSpacing:1.2 }}>RACHA</div>
        <div className="sf-display" style={{ fontSize:22, fontWeight:800, color:'#F6FBEF', letterSpacing:-0.5, marginTop:2 }}>
          12 días
        </div>
        <div style={{ fontSize:10, color:'#8FA094', fontWeight:600 }}>registrando gastos</div>
        <div style={{ marginTop:8, display:'flex', gap:3 }}>
          {Array.from({length:12}).map((_,i)=>(
            <div key={i} style={{
              flex:1, height:18, borderRadius:3,
              background:'linear-gradient(180deg,#C7EE9C,#6FE09A)',
              animation:`mf-grow-bar .5s ${0.6+i*0.04}s ease both`, transformOrigin:'bottom',
            }}/>
          ))}
        </div>
      </div>
    </div>
  );
}

function GastoRowDk({ mov, delay=0 }) {
  const cat = GASTOS_CATS.find(c=>c.id===mov.cat);
  const who = FAMILY[mov.who];
  const [swiped, setSwiped] = useStateGx(false);
  return (
    <div style={{ position:'relative', borderRadius:14, overflow:'hidden',
      animation:`mf-slide-in .5s ${delay}s ease both` }}>
      <div style={{ position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'flex-end',
        paddingRight:14, gap:8,
        background:'linear-gradient(90deg, #13221B 30%, #3A2A22 60%, #E8976A)' }}>
        <button style={{ width:32, height:32, borderRadius:10, border:'none', background:'rgba(10,20,16,0.85)', cursor:'pointer' }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" style={{ margin:'auto', display:'block' }}><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3" stroke="#E8976A" strokeWidth="1.8" strokeLinecap="round"/></svg>
        </button>
        <button style={{ width:32, height:32, borderRadius:10, border:'none', background:'rgba(10,20,16,0.85)', cursor:'pointer' }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" style={{ margin:'auto', display:'block' }}><path d="M4 20l4-1 11-11-3-3L5 16l-1 4z" stroke="#F6FBEF" strokeWidth="1.8" strokeLinejoin="round"/></svg>
        </button>
      </div>
      <div onClick={()=>setSwiped(s=>!s)} style={{
        background:'#13221B', borderRadius:14, padding:'12px 14px',
        display:'flex', alignItems:'center', gap:12, border:'1px solid #1F332A',
        transform: swiped ? 'translateX(-90px)' : 'translateX(0)',
        transition:'transform .25s cubic-bezier(.2,.9,.2,1)',
        cursor:'pointer', position:'relative',
      }}>
        <div style={{ position:'relative', flexShrink:0 }}>
          <div style={{ width:38, height:38, borderRadius:12,
            background:`linear-gradient(140deg, ${cat.darkColor}25, ${cat.darkColor}12)`,
            display:'grid', placeItems:'center', fontSize:18, border:`1px solid ${cat.darkColor}35` }}>
            {cat.emoji}
          </div>
          <div style={{ position:'absolute', bottom:-3, right:-3 }}>
            <Avatar name={who.name} color={who.color} size={16} ring ringColor="#13221B"/>
          </div>
        </div>
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ fontSize:14, fontWeight:700, color:'#F6FBEF' }}>{mov.title}</div>
          <div style={{ fontSize:11, color:'#8FA094', display:'flex', alignItems:'center', gap:6, marginTop:2 }}>
            <span style={{
              padding:'2px 7px', borderRadius:999, background:`${cat.darkColor}18`, color:cat.darkColor, fontWeight:700, fontSize:10,
              border:`1px solid ${cat.darkColor}30`,
            }}>{cat.label}</span>
            · {who.name} · {mov.time}
          </div>
        </div>
        <div style={{ textAlign:'right' }}>
          <div style={{ fontSize:14, fontWeight:800, color:'#F6FBEF' }}>-${Math.abs(mov.amount).toLocaleString('es-AR')}</div>
          <div style={{ fontSize:9, color:'#6A7A70', fontWeight:700, letterSpacing:1 }}>DESLIZÁ</div>
        </div>
      </div>
    </div>
  );
}

// Dark tab bar — gastos active
function TabBarGxDk() {
  const items = [
    { key:'inicio', label:'Inicio', icon:<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M4 11l8-7 8 7v9a1 1 0 01-1 1h-5v-6h-4v6H5a1 1 0 01-1-1v-9z" stroke="#8FA094" strokeWidth="1.8" strokeLinejoin="round"/></svg> },
    { key:'gastos', label:'Gastos', active:true, icon:<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><rect x="5" y="3" width="14" height="18" rx="2" fill="#C7EE9C"/><path d="M8 8h8M8 12h8M8 16h5" stroke="#0A1410" strokeWidth="1.8" strokeLinecap="round"/></svg> },
    { key:'add', big:true },
    { key:'fijos', lines:['Gastos','Fijos'], icon:<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><rect x="3" y="5" width="18" height="15" rx="2" stroke="#8FA094" strokeWidth="1.8"/><path d="M3 9h18M8 3v4M16 3v4" stroke="#8FA094" strokeWidth="1.8" strokeLinecap="round"/></svg> },
    { key:'control', label:'Control', icon:<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M3 17l5-6 4 3 7-8" stroke="#8FA094" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/><path d="M14 6h5v5" stroke="#8FA094" strokeWidth="1.8" strokeLinecap="round"/></svg> },
  ];
  return (
    <div style={{
      position:'absolute', bottom:0, left:0, right:0,
      background:'rgba(10,20,16,0.92)', backdropFilter:'blur(18px)',
      borderTop:'1px solid #1F332A',
      padding:'10px 20px 28px', display:'flex', justifyContent:'space-around', alignItems:'center',
    }}>
      {items.map((it,i)=> it.big ? (
        <button key={i} style={{
          width:52, height:52, borderRadius:999, border:'none', cursor:'pointer',
          background:'linear-gradient(140deg,#C7EE9C,#8DD66A)', color:'#0A1410', fontSize:26, fontWeight:700,
          marginTop:-22, boxShadow:'0 12px 24px -8px rgba(199,238,156,0.45)',
          animation:'mf-pulse 2.4s ease-in-out infinite',
        }}>+</button>
      ) : (
        <div key={i} style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:3 }}>
          {it.icon}
          <div style={{ fontSize:10, color: it.active ? '#C7EE9C' : '#8FA094', fontWeight: it.active ? 700 : 500, textAlign:'center', lineHeight:1.1 }}>
            {it.lines ? it.lines.map((l,j)=><div key={j}>{l}</div>) : it.label}
          </div>
        </div>
      ))}
    </div>
  );
}

// helper
function groupByDay(movs) {
  const today = 22;
  const labelFor = (d) => d===today ? 'Hoy' : d===today-1 ? 'Ayer' : `${d} abr`;
  const map = {};
  movs.forEach(m => { (map[m.day] ||= []).push(m); });
  return Object.entries(map)
    .sort(([a],[b]) => +b-+a)
    .map(([d, items]) => ({
      day: +d, label: labelFor(+d), items,
      total: items.reduce((s,m)=>s+Math.abs(m.amount), 0)
    }));
}

// ─────────────────────────────────────────────────────────────
// GASTOS — ORIGINAL (referencia, del screenshot provisto)
// ─────────────────────────────────────────────────────────────
function GastosOriginal() {
  return (
    <div className="screen" style={{ background:'#F1EADC' }}>
      <StatusBar color="#0F2A1E"/>
      <div style={{ padding:'0 22px', display:'flex', justifyContent:'space-between', alignItems:'flex-start' }}>
        <div>
          <div style={{ fontSize:34, fontWeight:800, color:'#0F2A1E', letterSpacing:-1 }}>Gastos</div>
          <div style={{ fontSize:13, color:'#6F7A73', marginTop:4, maxWidth:220 }}>Historial, filtros y edición rápida de movimientos.</div>
        </div>
        <div style={{ display:'flex', gap:8, marginTop:10 }}>
          <div style={{ width:36, height:36, borderRadius:999, background:'#FFFBF2', display:'grid', placeItems:'center' }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M7 4v16M17 4v16M7 20l-3-3M7 20l3-3M17 4l-3 3M17 4l3 3" stroke="#0F2A1E" strokeWidth="1.8" strokeLinecap="round"/></svg>
          </div>
          <div style={{ width:36, height:36, borderRadius:999, background:'#FFFBF2', display:'grid', placeItems:'center' }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M4 6h16M7 12h10M10 18h4" stroke="#0F2A1E" strokeWidth="1.8" strokeLinecap="round"/></svg>
          </div>
        </div>
      </div>
      <div style={{ margin:'14px 22px 0',
        background:'linear-gradient(160deg, #D5E8B8 0%, #E8EEBE 100%)',
        borderRadius:20, padding:'16px 18px', border:'1px solid #CADD9E' }}>
        <div style={{ fontSize:11, fontWeight:700, letterSpacing:1.4, color:'#0F2A1E' }}>TOTAL VISIBLE</div>
        <div style={{ fontSize:34, fontWeight:800, color:'#0F2A1E', letterSpacing:-1, marginTop:4 }}>$ 30.000,00</div>
        <div style={{ fontSize:12, color:'#5A6B54' }}>1 movimiento visible · Ciclo · Todas</div>
        <div style={{ fontSize:15, fontWeight:700, color:'#0F2A1E', marginTop:14 }}>Mas peso por categoria</div>
        <div style={{ marginTop:8, display:'flex', justifyContent:'space-between', fontSize:13 }}>
          <div style={{ display:'flex', alignItems:'center', gap:6 }}>
            <span style={{ width:8, height:8, borderRadius:4, background:'#E08E63' }}/>
            <b>Alquiler</b>
          </div>
          <b>$ 30.000,00</b>
        </div>
        <div style={{ marginTop:6, height:4, borderRadius:2, background:'#E08E63' }}/>
        <div style={{ fontSize:11, color:'#5A6B54', marginTop:6 }}>100% del total visible</div>
      </div>
      <div style={{ margin:'14px 22px 0', background:'#FFFBF2', borderRadius:20, padding:'16px', border:'1px solid #EFE8D9' }}>
        <div style={{ fontSize:22, fontWeight:800, color:'#0F2A1E' }}>Movimientos</div>
        <div style={{ fontSize:12, color:'#6F7A73', marginTop:2 }}>Toca para editar o desliza cada fila para acciones rápidas.</div>
        <div style={{ marginTop:14, display:'flex', justifyContent:'space-between' }}>
          <div>
            <div style={{ fontSize:14, fontWeight:700, color:'#0F2A1E' }}>Hoy</div>
            <div style={{ fontSize:11, color:'#9AA39D' }}>1 movimiento</div>
          </div>
          <div style={{ fontSize:14, fontWeight:800, color:'#0F2A1E' }}>$ 30.000,00</div>
        </div>
        <div style={{ marginTop:10, background:'#FFF', borderRadius:14, padding:'12px', border:'1px solid #EFE8D9', display:'flex', justifyContent:'space-between' }}>
          <div>
            <div style={{ fontSize:14, fontWeight:700 }}><span style={{ color:'#E08E63', marginRight:6 }}>●</span>Alquiler</div>
            <div style={{ marginTop:6, display:'inline-block', fontSize:11, padding:'3px 8px', borderRadius:999, background:'#FADFC8', color:'#6B3A4F' }}>● Alquiler</div>
            <div style={{ fontSize:11, color:'#6F7A73', marginTop:6 }}>Mario · 22-abr</div>
          </div>
          <div style={{ textAlign:'right' }}>
            <div style={{ fontSize:14, fontWeight:800, color:'#0F2A1E' }}>$ 30.000,00</div>
            <div style={{ fontSize:10, color:'#9AA39D', fontWeight:700, letterSpacing:1 }}>DESLIZA</div>
          </div>
        </div>
      </div>
      <TabBar active="gastos" accent="#6FE09A" bg="#F1EADC"/>
    </div>
  );
}

window.GastosLight = GastosLight;
window.GastosDark = GastosDark;
window.GastosOriginal = GastosOriginal;
window.GASTOS_CATS = GASTOS_CATS;
window.GASTOS_MOVS = GASTOS_MOVS;
