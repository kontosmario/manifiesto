// Control v2 — data + math helpers + shared atoms
// Diseñado para principiantes: lenguaje simple, sin jerga.
// Todo es matemática pura sobre movimientos registrados.

const { useState: useStateCv, useEffect: useEffectCv, useMemo: useMemoCv, useRef: useRefCv } = React;

// ─────────────────────────────────────────────────────────────
// DATOS
// Sueldo 2.200.000, Fijos 1.250.000 → Libre mensual 950.000
// Mes de 30 días, vamos por el día 22 a las 14:20
// ─────────────────────────────────────────────────────────────
const CTRL = {
  ingresoMes:  2200000,
  fijosMes:    1250000,
  libreMes:     950000,
  cupoDiario:    31600,   // libre / 30
  diasMes: 30,
  diaActual: 22,
  horaActual: 14, minActual: 20,
  gastoHoy: 12400,
  gastoHoyItems: 3,
  proximoSueldoEnDias: 8,  // día 30 - día 22
  // Gasto real de los 21 días previos
  dias: [
    26400, 30900, 15000, 42100, 28400, 31500, 18900,
    22400, 29800, 35600, 14000, 27800, 31200, 19500,
    24300, 33900, 41200, 28100, 22700, 37400, 29800,
  ],
  // dow de cada día del mes (0=Lun para simplificar): día 1 = Martes → 1
  diasDow: [1,2,3,4,5,6,0, 1,2,3,4,5,6,0, 1,2,3,4,5,6,0], // 21 días
  // Fijos pagados día por día (para cobertura)
  fijosCobertura: 17,     // los fijos del mes se cubren con los primeros 17 días de sueldo
  // No-spend days: detectados (días con 0 gasto discrecional)
  diasSinGastar: [3, 11, 18],  // índices 0-based → días 3, 11, 18 sin gastos
  // Meta semanal de no-spend
  metaNoSpendSemana: 3,
  logrosNoSpendSemana: 2,
  // Comparación con mes pasado (marzo)
  mesPasado: {
    nombre: 'Marzo',
    gastoTotal: 1687000,     // gasto total discrecional mes anterior
    diasBajoCupo: 15,        // cuántos días cerró bajo cupo
    promedioDiario: 56233,   // 1687000 / 30
    topCat: { label: 'Ocio', amount: 142000, pct: 8.4 },
  },
  // Tareas asesor
  tareas: [
    { id:'t1', emoji:'🎬', cat:'Ocio',
      title:'Bajá un poco el Ocio esta semana',
      body:'Ya gastaste $28.400 en ocio. Te pusiste un tope de $20.000.',
      impact:'+$8.400 por mes',
      impactRaw: 8400,
      cta:'Ver gastos',
      urgency:'media',
    },
    { id:'t2', emoji:'🧟', cat:'Suscripciones',
      title:'Disney+ lleva 2 meses sin usar',
      body:'Pagás $4.200 cada mes. Si lo cancelás, te ahorrás $50.400 al año.',
      impact:'+$4.200 por mes',
      impactRaw: 4200,
      cta:'Cancelar',
      urgency:'alta',
    },
    { id:'t3', emoji:'⚡', cat:'Servicios',
      title:'La luz subió 14%',
      body:'Edenor pasó de $28.000 a $32.500. Hay planes más baratos.',
      impact:'−$3.200 por mes',
      impactRaw: 3200,
      cta:'Comparar',
      urgency:'baja',
    },
  ],
};

// ─────────────────────────────────────────────────────────────
// MATEMÁTICA — todo es cálculo puro
// ─────────────────────────────────────────────────────────────
function calcControl(d) {
  // 1. HOY
  const horaF = d.horaActual + d.minActual/60;
  const libreHoy = d.cupoDiario - d.gastoHoy;
  const cupoHastaAhora = (horaF / 24) * d.cupoDiario;
  const delta = cupoHastaAhora - d.gastoHoy;
  const estaOk = delta >= 0;

  // 2. VAULT (alcancía)
  const detalleDias = d.dias.map((g, i) => ({ dia: i+1, gasto: g, delta: d.cupoDiario - g, dow: d.diasDow[i] }));
  const vault = detalleDias.reduce((s, x) => s + Math.max(0, x.delta), 0);
  const diasGanadores = detalleDias.filter(x => x.gasto <= d.cupoDiario).length;
  const diasPerdedores = detalleDias.length - diasGanadores;
  const gastoTotalMes = detalleDias.reduce((s,x)=>s+x.gasto, 0);
  const promedioDiario = gastoTotalMes / detalleDias.length;

  // Racha
  let racha = 0;
  for (let i = detalleDias.length - 1; i >= 0; i--) {
    if (detalleDias[i].gasto <= d.cupoDiario) racha++; else break;
  }

  // Mejor/peor
  const mejor = detalleDias.reduce((a,b)=>b.gasto < a.gasto ? b : a);
  const peor  = detalleDias.reduce((a,b)=>b.gasto > a.gasto ? b : a);

  // 3. PROYECCIÓN FECHA EXACTA
  // Si seguís al ritmo actual (promedio), en qué día se acaba tu plata libre del mes?
  // plata libre total = cupoDiario * diasMes = libreMes. Ya gastaste gastoTotalMes + gastoHoy.
  const gastadoHastaHoy = gastoTotalMes + d.gastoHoy;
  const libreMes = d.cupoDiario * d.diasMes;
  const restanteMes = libreMes - gastadoHastaHoy;
  const diasRestantes = d.diasMes - d.diaActual + 1; // incluye hoy
  // A ritmo promedio, cuántos días más durará el restante?
  const duracionAlRitmo = restanteMes / promedioDiario;
  // Día exacto del mes en el que se acaba la plata
  const diaAgotamientoFloat = d.diaActual + duracionAlRitmo;
  const diaAgotamiento = Math.min(d.diasMes + 1, Math.max(1, Math.floor(diaAgotamientoFloat)));
  const alcanzaElMes = diaAgotamiento > d.diasMes;
  // Proyección de cierre: cuánto gastás todo el mes si seguís al ritmo
  const gastoProyectadoMes = promedioDiario * d.diasMes;
  const sobrantePresupuestadoMes = libreMes - gastoProyectadoMes;

  // 4. PATRÓN POR DÍA DE SEMANA
  // Agrupamos por dow
  const dowNames = ['Lun','Mar','Mié','Jue','Vie','Sáb','Dom'];
  const porDow = dowNames.map((name, i) => {
    const dias = detalleDias.filter(x => x.dow === i);
    const total = dias.reduce((s,x)=>s+x.gasto, 0);
    const avg = dias.length ? total / dias.length : 0;
    return { name, avg, count: dias.length };
  });
  const globalAvg = promedioDiario;
  const porDowEnriched = porDow.map(d => ({
    ...d,
    ratio: d.avg / globalAvg,
  }));
  const peorDow = porDowEnriched.reduce((a,b)=> b.avg > a.avg ? b : a);
  const mejorDow = porDowEnriched.filter(x=>x.avg>0).reduce((a,b)=> b.avg < a.avg ? b : a);

  // 5. NO-SPEND DAYS
  const noSpendCount = d.diasSinGastar.length;

  // 6. COBERTURA DE FIJOS (días que el sueldo banca fijos)
  const coberturaFijos = Math.ceil((d.fijosMes / d.ingresoMes) * d.diasMes);
  const diasLibres = d.diasMes - coberturaFijos;

  // 7. MOMENTUM — velocidad últimos 7 vs 7-14
  const ultimos7 = detalleDias.slice(-7);
  const previos7 = detalleDias.slice(-14, -7);
  const avgU7 = ultimos7.reduce((s,x)=>s+x.gasto, 0) / Math.max(1, ultimos7.length);
  const avgP7 = previos7.reduce((s,x)=>s+x.gasto, 0) / Math.max(1, previos7.length);
  const momentum = avgU7 / avgP7; // 1 = igual, >1 acelerando, <1 desacelerando

  // 8. SCORE 0-100 (simple pero claro)
  // 40% = % bajo cupo, 20% = racha (cap 7d), 20% = momentum (bueno si <=1),
  // 10% = no-spend-count (cap 5), 10% = ratio fijos/ingreso (bueno si <0.6)
  const sBajoCupo = (diasGanadores / detalleDias.length) * 40;
  const sRacha    = Math.min(racha, 7) / 7 * 20;
  const sMomentum = momentum <= 1 ? 20 : Math.max(0, 20 - (momentum-1)*40);
  const sNoSpend  = Math.min(noSpendCount, 5) / 5 * 10;
  const sFijos    = Math.max(0, (1 - (d.fijosMes / d.ingresoMes)) / 0.5) * 10;
  const score = Math.round(sBajoCupo + sRacha + sMomentum + sNoSpend + sFijos);
  const scoreLabel = score >= 80 ? 'Excelente' : score >= 65 ? 'Muy bien' : score >= 50 ? 'Bien' : score >= 35 ? 'Regular' : 'Atención';
  const scoreColor = score >= 65 ? '#2E7D5B' : score >= 50 ? '#C9A23A' : '#D96A4F';
  const scoreColorDk = score >= 65 ? '#9EE0B2' : score >= 50 ? '#F1D690' : '#E88A70';

  // 9. LAST 7 incluyendo hoy (para ritmo semanal)
  const last7 = detalleDias.slice(-6).map(x => ({ ...x }));
  last7.push({ dia: d.diaActual, gasto: d.gastoHoy, delta: d.cupoDiario - d.gastoHoy, inProgress: true });

  // 10. COMPARACIÓN MES PASADO (proyección mes actual vs total mes pasado)
  const mpTotal = d.mesPasado?.gastoTotal ?? 0;
  const proyectadoMes = gastoProyectadoMes;
  const vsMesDeltaPct = mpTotal ? ((proyectadoMes - mpTotal) / mpTotal) * 100 : 0;
  const vsMesAhorro = mpTotal - proyectadoMes;  // positivo = ahorro
  const vsMesDiasBajoCupo = diasGanadores - (d.mesPasado?.diasBajoCupo ?? 0);
  const vsMesMejor = proyectadoMes < mpTotal;

  return {
    // hoy
    libreHoy, cupoHastaAhora, delta, estaOk, horaF,
    // vault
    vault, diasGanadores, diasPerdedores, promedioDiario, racha, mejor, peor, detalleDias,
    // proyección
    diaAgotamiento, alcanzaElMes, gastoProyectadoMes, sobrantePresupuestadoMes, diasRestantes, restanteMes,
    // dow pattern
    porDowEnriched, peorDow, mejorDow, globalAvg,
    // no-spend
    noSpendCount,
    // cobertura
    coberturaFijos, diasLibres,
    // momentum
    momentum, avgU7, avgP7,
    // score
    score, scoreLabel, scoreColor, scoreColorDk,
    // ritmo
    last7,
    // vs mes pasado
    mpTotal, proyectadoMes, vsMesDeltaPct, vsMesAhorro, vsMesDiasBajoCupo, vsMesMejor,
  };
}

// ─────────────────────────────────────────────────────────────
// ATOMS COMPARTIDOS (light & dark reciben tema)
// ─────────────────────────────────────────────────────────────

// Chip de micro-aclaración (para "explicación para dummies")
function CvHint({ children, theme }) {
  const isDark = theme === 'dark';
  return (
    <div style={{
      display:'inline-flex', alignItems:'center', gap:4,
      padding:'2px 7px', borderRadius:999,
      background: isDark ? 'rgba(246,251,239,0.06)' : '#F6F1E4',
      border: `1px solid ${isDark ? 'rgba(246,251,239,0.1)' : '#EFE8D9'}`,
      fontSize:10, color: isDark ? '#8FA094' : '#6F7A73', fontWeight:600,
    }}>
      💡 {children}
    </div>
  );
}

// Label pequeño editorial
function CvLabel({ children, theme, color }) {
  const isDark = theme === 'dark';
  return (
    <div style={{
      fontSize:10, letterSpacing:1.6, fontWeight:700,
      color: color || (isDark ? '#8FA094' : '#6F7A73'),
    }}>{children}</div>
  );
}

// Mini tooltip "¿Qué es esto?"
function CvWhat({ text, theme }) {
  const isDark = theme === 'dark';
  return (
    <div style={{
      display:'inline-flex', alignItems:'center', gap:3,
      fontSize:11, color: isDark ? '#8FA094' : '#6F7A73',
      fontWeight:500,
    }}>{text}</div>
  );
}

Object.assign(window, { CTRL, calcControl, CvHint, CvLabel, CvWhat });
