// V4 — "La meta es el héroe"
// Motivacional. La meta de ahorro (viaje, casa, auto) es visual y central,
// con progreso animado y proyección. Números grandes pero puestos al servicio
// del sueño. Incluye "¿qué pasa si ahorro X más por semana?".

function V4Meta() {
  const pct = 64;
  return (
    <div className="screen" style={{ background:'#F6EFE3', color:'#0F2A1E' }}>
      <StatusBar color="#0F2A1E"/>

      {/* header compact */}
      <div style={{ padding:'2px 22px 0', display:'flex', alignItems:'center', justifyContent:'space-between' }}>
        <div>
          <div style={{ fontSize:12, color:'#6F7A73' }}>Martes · abril</div>
          <div style={{ fontSize:20, fontWeight:800, letterSpacing:-0.4 }}>Hola, Mario</div>
        </div>
        <div style={{ display:'flex', gap:8 }}>
          <CircleBtn><BellIcon/></CircleBtn>
          <CircleBtn><SlidersIcon/></CircleBtn>
        </div>
      </div>

      {/* goal ring hero */}
      <div style={{ padding:'12px 22px 0', animation:'mf-rise .9s .1s ease both' }}>
        <div style={{
          background:'linear-gradient(180deg, #FFFBF2 0%, #FADFC8 100%)',
          borderRadius:28, padding:'16px 16px 18px', border:'1px solid #EFE8D9',
          position:'relative', overflow:'hidden',
        }}>
          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
            <div>
              <div style={{ fontSize:10, letterSpacing:1.4, fontWeight:700, color:'#E08E63' }}>META ACTIVA</div>
              <div className="serif" style={{ fontSize:22, fontWeight:700, letterSpacing:-0.5, marginTop:2 }}>Casa propia</div>
              <div style={{ fontSize:11, color:'#6F7A73', marginTop:2 }}>familiar · desde enero</div>
            </div>
            <GoalRing pct={pct} size={112}/>
          </div>

          {/* amounts */}
          <div style={{ display:'flex', justifyContent:'space-between', marginTop:14, gap:12 }}>
            <div>
              <div style={{ fontSize:10, color:'#6F7A73', fontWeight:600, letterSpacing:0.8 }}>AHORRADO</div>
              <div className="serif" style={{ fontSize:26, fontWeight:700, letterSpacing:-0.8 }}>
                <CountUp to={19200000} duration={1500} prefix="$"/>
              </div>
            </div>
            <div style={{ textAlign:'right' }}>
              <div style={{ fontSize:10, color:'#6F7A73', fontWeight:600, letterSpacing:0.8 }}>META</div>
              <div className="serif" style={{ fontSize:26, fontWeight:700, letterSpacing:-0.8, color:'#6F7A73' }}>$30.000.000</div>
            </div>
          </div>

          {/* projection */}
          <div style={{ marginTop:12, background:'#FFFBF2', borderRadius:14, padding:'10px 12px', display:'flex', alignItems:'center', gap:10, border:'1px solid rgba(224,142,99,0.2)' }}>
            <div style={{ fontSize:22, animation:'mf-float 3s ease-in-out infinite' }}>🏡</div>
            <div style={{ flex:1 }}>
              <div style={{ fontSize:11, color:'#6F7A73', fontWeight:600 }}>al ritmo actual</div>
              <div style={{ fontSize:13, fontWeight:700, color:'#0F2A1E' }}>llegás en <span style={{ color:'#E08E63' }}>8 meses</span> · dic 2026</div>
            </div>
            <button style={{ border:'none', background:'#0F2A1E', color:'#FFFBF2', padding:'8px 12px', borderRadius:999, fontSize:11, fontWeight:700, cursor:'pointer' }}>acelerar</button>
          </div>
        </div>
      </div>

      {/* today row */}
      <div style={{ padding:'14px 22px 0', animation:'mf-rise .9s .25s ease both' }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:8 }}>
          <div style={{ fontSize:11, letterSpacing:1.4, fontWeight:700, color:'#6F7A73' }}>DISPONIBLE HOY</div>
          <div style={{ fontSize:11, color:'#6F7A73' }}>cobro en <b style={{ color:'#0F2A1E' }}>27d</b></div>
        </div>
        <div style={{ display:'flex', alignItems:'baseline', justifyContent:'space-between' }}>
          <div className="serif" style={{ fontSize:44, fontWeight:700, letterSpacing:-1.4, lineHeight:1 }}>
            <CountUp to={4455000} duration={1400} prefix="$"/>
          </div>
          <button style={{ border:'none', background:'#6FE09A', color:'#0F2A1E', padding:'12px 16px', borderRadius:999, fontWeight:700, fontSize:13, cursor:'pointer', animation:'mf-pulse 2.4s ease-in-out 1.6s infinite', display:'flex', alignItems:'center', gap:6 }}>
            <span style={{ fontSize:16 }}>+</span> gasto
          </button>
        </div>
        <div style={{ fontSize:12, color:'#6F7A73', marginTop:2 }}>
          Si hoy gastás <b style={{ color:'#0F2A1E' }}>menos de $130k</b> sumás $5k a la casa
        </div>
      </div>

      {/* weekly pace */}
      <div style={{ padding:'16px 22px 0', animation:'mf-rise .9s .35s ease both' }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:6 }}>
          <div style={{ fontSize:11, letterSpacing:1.4, fontWeight:700, color:'#6F7A73' }}>RITMO SEMANAL</div>
          <div style={{ fontSize:11, color:'#2CAE6E', fontWeight:700 }}>▲ 12% vs sem pasada</div>
        </div>
        <div style={{ display:'flex', gap:6, alignItems:'flex-end', height:56 }}>
          {[0.35,0.5,0.4,0.62,0.55,0.78,0.9].map((v,i)=>(
            <div key={i} style={{ flex:1, display:'flex', flexDirection:'column', alignItems:'center', gap:4 }}>
              <div style={{
                width:'100%', height: 40*v+8, background: i===6 ? 'linear-gradient(180deg,#F2B58A,#E08E63)' : '#EFE8D9',
                borderRadius:6, transformOrigin:'bottom',
                animation:`mf-grow-bar .6s ${.4+i*0.07}s cubic-bezier(.2,.9,.2,1) both`,
              }}/>
              <div style={{ fontSize:9, color: i===6 ? '#0F2A1E' : '#9AA39D', fontWeight: i===6?700:500 }}>{['L','M','M','J','V','S','D'][i]}</div>
            </div>
          ))}
        </div>
      </div>

      {/* family contributing */}
      <div style={{ padding:'14px 22px 0', animation:'mf-rise .9s .45s ease both' }}>
        <div style={{ fontSize:11, letterSpacing:1.4, fontWeight:700, color:'#6F7A73', marginBottom:8 }}>APORTANDO ESTE MES</div>
        <div style={{ display:'flex', gap:8 }}>
          {FAMILY.slice(0,3).map((f,i) => {
            const amt = [820, 640, 460][i];
            return (
              <div key={i} style={{ flex:1, background:'#FFFBF2', border:'1px solid #EFE8D9', borderRadius:14, padding:'10px 10px' }}>
                <Avatar name={f.name} color={f.color} size={22}/>
                <div style={{ fontSize:11, fontWeight:700, color:'#0F2A1E', marginTop:6 }}>{f.name}</div>
                <div className="serif" style={{ fontSize:15, fontWeight:700, letterSpacing:-0.3 }}>${amt}k</div>
              </div>
            );
          })}
        </div>
      </div>

      <TabBar accent="#6FE09A" bg="#F6EFE3"/>
    </div>
  );
}

function GoalRing({ pct=64, size=112 }) {
  const r = size/2 - 8;
  const c = 2 * Math.PI * r;
  const off = c * (1 - pct/100);
  return (
    <div style={{ position:'relative', width:size, height:size }}>
      <svg width={size} height={size} style={{ transform:'rotate(-90deg)' }}>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="rgba(15,42,30,0.08)" strokeWidth="8"/>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="url(#ringGrad)" strokeWidth="8" strokeLinecap="round"
          strokeDasharray={c} strokeDashoffset={c} style={{ animation:`mf-ringfill 1.4s .3s cubic-bezier(.2,.9,.2,1) forwards` }}/>
        <defs>
          <linearGradient id="ringGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#6FE09A"/>
            <stop offset="1" stopColor="#E08E63"/>
          </linearGradient>
        </defs>
        <style>{`@keyframes mf-ringfill { to { stroke-dashoffset: ${off} } }`}</style>
      </svg>
      <div style={{ position:'absolute', inset:0, display:'grid', placeItems:'center', textAlign:'center' }}>
        <div>
          <div className="serif" style={{ fontSize:28, fontWeight:700, letterSpacing:-0.8, color:'#0F2A1E' }}>
            <CountUp to={pct} duration={1400} format={n=>n} />%
          </div>
          <div style={{ fontSize:9, color:'#6F7A73', fontWeight:600, letterSpacing:1, marginTop:-2 }}>DE LA META</div>
        </div>
      </div>
    </div>
  );
}

window.V4Meta = V4Meta;
