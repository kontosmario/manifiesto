// V3 — "Feed familiar vivo"
// La familia es lo central. Feed social-like con actividad en tiempo real,
// avatares grandes, reacciones. Los números siguen presentes pero como
// "status bar" superior, no como el heroe. Estilo: instagram-meets-finance.

function V3Feed() {
  return (
    <div className="screen" style={{ background:'#FAF4EA' }}>
      <StatusBar color="#0F2A1E"/>

      {/* top summary strip */}
      <div style={{ padding:'4px 20px 0' }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
          <div style={{ fontSize:22, fontWeight:800, color:'#0F2A1E', letterSpacing:-0.5 }}>Familia López</div>
          <div style={{ display:'flex', gap:8 }}>
            <CircleBtn><BellIcon/></CircleBtn>
            <CircleBtn><SlidersIcon/></CircleBtn>
          </div>
        </div>
        <div style={{ fontSize:12, color:'#6F7A73', marginTop:2 }}>hoy · martes 22 de abril</div>
      </div>

      {/* family stories row */}
      <div style={{ padding:'12px 20px 4px', display:'flex', gap:12, animation:'mf-rise .8s .1s ease both' }}>
        {FAMILY.map((f, i) => (
          <div key={i} style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:4, animation:`mf-rise .6s ${0.15+i*0.08}s ease both` }}>
            <div style={{ padding:2, borderRadius:999, background: i===0 ? 'linear-gradient(140deg,#F2B58A,#6FE09A)' : 'transparent' }}>
              <div style={{ padding:2, background:'#FAF4EA', borderRadius:999 }}>
                <Avatar name={f.name} color={f.color} size={48}/>
              </div>
            </div>
            <div style={{ fontSize:10, color:'#0F2A1E', fontWeight:600 }}>{i===0?'Tú':f.name.split(' ')[0]}</div>
            <div style={{ fontSize:9, color: i===0?'#2CAE6E':'#6F7A73', fontWeight:600 }}>
              {i===0?'$180k':['-$25k','-$42k','-$8k'][i-1]}
            </div>
          </div>
        ))}
        <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:4 }}>
          <div style={{ width:48, height:48, borderRadius:999, border:'2px dashed #E9E1D3', display:'grid', placeItems:'center', color:'#9AA39D', fontSize:20 }}>+</div>
          <div style={{ fontSize:10, color:'#6F7A73' }}>invitar</div>
        </div>
      </div>

      {/* running total pill */}
      <div style={{ padding:'0 20px', animation:'mf-rise .9s .2s ease both' }}>
        <div style={{
          background:'#0F2A1E', color:'#FFFBF2', borderRadius:20, padding:'14px 16px',
          display:'flex', alignItems:'center', justifyContent:'space-between', position:'relative', overflow:'hidden',
        }}>
          <div>
            <div style={{ fontSize:10, letterSpacing:1.4, fontWeight:700, color:'#9EE5BA' }}>DISPONIBLE JUNTOS</div>
            <div className="serif" style={{ fontSize:32, fontWeight:700, letterSpacing:-1, marginTop:2 }}>
              <CountUp to={4455000} duration={1400} prefix="$"/>
            </div>
          </div>
          <div style={{ textAlign:'right', fontSize:11, color:'rgba(255,255,255,0.65)' }}>
            <div>cobro en</div>
            <div style={{ fontSize:22, fontWeight:800, color:'#FFFBF2', letterSpacing:-0.5 }}>27<span style={{ fontSize:12, color:'#9EE5BA' }}>d</span></div>
          </div>
          {/* live dot */}
          <div style={{ position:'absolute', top:12, right:12, display:'flex', alignItems:'center', gap:4, fontSize:10, color:'#6FE09A', fontWeight:700 }}>
            <span style={{ width:6, height:6, borderRadius:3, background:'#6FE09A', animation:'mf-breathe 1.5s ease-in-out infinite' }}/>
            EN VIVO
          </div>
        </div>
      </div>

      {/* feed header */}
      <div style={{ padding:'14px 20px 8px', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <div style={{ fontSize:11, letterSpacing:1.4, fontWeight:700, color:'#6F7A73' }}>ACTIVIDAD DE HOY</div>
        <div style={{ fontSize:12, fontWeight:600, color:'#2E7D5B' }}>filtrar</div>
      </div>

      {/* feed */}
      <div style={{ padding:'0 20px', display:'flex', flexDirection:'column', gap:10 }}>
        <FeedCard who={FAMILY[1]} time="hace 12 min" cat="Supermercado" emoji="🛒"
          title="Supermercado Coto" sub="Casa · compra semanal" amount={-42300}
          reactions={[{who:FAMILY[0],em:'👍'},{who:FAMILY[2],em:'❤️'}]} delay={250}/>
        <FeedCard who={FAMILY[0]} time="hace 1h" cat="Fernet con coca" emoji="🍹"
          title="Fernet con coca" sub="Gastos generales" amount={-25000}
          note="Cumple de Juan" delay={350}/>
        <FeedCard who={FAMILY[2]} time="hace 3h" cat="Colectivo" emoji="🚌"
          title="SUBE" sub="Transporte" amount={-8000} delay={450}/>

        {/* celebration card */}
        <div style={{
          background:'linear-gradient(140deg, #FADFC8, #F2B58A 60%, #E08E63)',
          borderRadius:18, padding:'14px 16px', color:'#6B3A4F',
          animation:'mf-rise .7s .5s ease both',
          display:'flex', alignItems:'center', gap:12, position:'relative', overflow:'hidden',
        }}>
          <div style={{ fontSize:32, animation:'mf-wiggle 2.4s ease-in-out infinite' }}>🎉</div>
          <div style={{ flex:1 }}>
            <div style={{ fontSize:11, fontWeight:700, letterSpacing:0.8 }}>¡LOGRO DESBLOQUEADO!</div>
            <div className="serif" style={{ fontSize:17, fontWeight:700, marginTop:2, letterSpacing:-0.3 }}>Semana sin delivery</div>
            <div style={{ fontSize:11, marginTop:2, opacity:.85 }}>Ahorraron ~$28k juntos esta semana</div>
          </div>
          <div style={{ position:'absolute', top:6, right:10, fontSize:10, animation:'mf-sparkle 1.8s ease-in-out infinite' }}>✦</div>
          <div style={{ position:'absolute', bottom:8, right:26, fontSize:8, animation:'mf-sparkle 2.4s .5s ease-in-out infinite' }}>✦</div>
        </div>
      </div>

      <TabBar accent="#6FE09A" bg="#FAF4EA"/>
    </div>
  );
}

function FeedCard({ who, time, cat, emoji, title, sub, amount, reactions, note, delay=0 }) {
  return (
    <div style={{
      background:'#FFFBF2', borderRadius:18, padding:'12px 14px', border:'1px solid #EFE8D9',
      animation:`mf-rise .7s ${delay}ms ease both`,
    }}>
      <div style={{ display:'flex', alignItems:'center', gap:10 }}>
        <Avatar name={who.name} color={who.color} size={34}/>
        <div style={{ flex:1 }}>
          <div style={{ fontSize:13, fontWeight:700, color:'#0F2A1E' }}>
            {who.name} <span style={{ color:'#6F7A73', fontWeight:500 }}>registró un gasto</span>
          </div>
          <div style={{ fontSize:11, color:'#9AA39D' }}>{time}</div>
        </div>
        <div style={{ fontSize:15, fontWeight:800, color:'#0F2A1E' }}>
          {fmtMoney(amount, { sign:true })}
        </div>
      </div>

      <div style={{ marginTop:10, display:'flex', alignItems:'center', gap:10,
        background:'#FAF4EA', borderRadius:12, padding:'10px 12px' }}>
        <div style={{ width:34, height:34, borderRadius:10, background:'#FADFC8', display:'grid', placeItems:'center', fontSize:18 }}>{emoji}</div>
        <div style={{ flex:1 }}>
          <div style={{ fontSize:13, fontWeight:700, color:'#0F2A1E' }}>{title}</div>
          <div style={{ fontSize:11, color:'#6F7A73' }}>{sub}</div>
        </div>
      </div>

      {note && (
        <div className="serif" style={{ marginTop:8, fontSize:12, fontStyle:'italic', color:'#6B3A4F', paddingLeft:8, borderLeft:'2px solid #F2B58A' }}>
          "{note}"
        </div>
      )}

      <div style={{ marginTop:10, display:'flex', alignItems:'center', gap:8 }}>
        <button style={{ border:'1px solid #EFE8D9', background:'#FAF4EA', padding:'4px 10px', borderRadius:999, fontSize:11, fontWeight:600, color:'#0F2A1E', cursor:'pointer' }}>
          ❤️ me suma
        </button>
        <button style={{ border:'1px solid #EFE8D9', background:'#FAF4EA', padding:'4px 10px', borderRadius:999, fontSize:11, fontWeight:600, color:'#0F2A1E', cursor:'pointer' }}>
          💬 comentar
        </button>
        {reactions && (
          <div style={{ marginLeft:'auto', display:'flex', alignItems:'center', gap:4 }}>
            {reactions.map((r,i) => (
              <div key={i} style={{ display:'flex', alignItems:'center', fontSize:10 }}>
                <Avatar name={r.who.name} color={r.who.color} size={16}/>
                <span style={{ marginLeft:-4, fontSize:11 }}>{r.em}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

window.V3Feed = V3Feed;
