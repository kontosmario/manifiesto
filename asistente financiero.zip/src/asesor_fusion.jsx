// Asesor Fusión — Chat conversacional + Constelación/Radar
// Idea: el chat es la experiencia principal (acceso rápido desde home),
// pero un mini-mapa estelar arriba muestra el panorama de los 5 signals.
// Tap en un nodo → highlight + scroll al mensaje correspondiente.
// El mini-mapa se puede expandir a vista radar full.

const { useState: useStateAsF, useEffect: useEffectAsF, useRef: useRefAsF } = React;

// ─────────────────────────────────────────────────────────────
// Iconos (compartidos con asesor.jsx, reusamos AsIcon global)
// ─────────────────────────────────────────────────────────────

function AsesorFusion({ entry = 'compact' }) {
  // entry: 'compact' (mini desde Home) | 'full' (pantalla completa)
  const [active, setActive] = useStateAsF(0);
  const [mapMode, setMapMode] = useStateAsF('constellation'); // 'constellation' | 'radar'
  const [expanded, setExpanded] = useStateAsF(false);
  const [seenIds, setSeenIds] = useStateAsF([]);
  const visibleSignals = SIGNALS;
  const messageRefs = useRefAsF([]);

  const onNodeTap = (i) => {
    setActive(i);
    // Scroll the chat message into view smoothly
    const el = messageRefs.current[i];
    if (el && el.scrollIntoView) {
      try { el.scrollIntoView({ behavior:'smooth', block:'center' }); } catch(e) {}
    }
  };

  // Constellation node positions
  const constellationNodes = [
    { x: 50, y: 48, r: 40, sig: SIGNALS[0] },
    { x: 18, y: 28, r: 28, sig: SIGNALS[1] },
    { x: 80, y: 26, r: 34, sig: SIGNALS[2] },
    { x: 78, y: 72, r: 24, sig: SIGNALS[3] },
    { x: 22, y: 76, r: 20, sig: SIGNALS[4] },
  ];

  // Radar polar positions (angle by type, radius by confidence)
  const radarAngles = { 'recovery-hard': -110, 'zombie-disney': -55, 'cat-accel-restos': 35, 'positive-forecast': 95, 'streak-ok': 155 };
  const radarPoints = SIGNALS.map((s, i) => {
    const angle = radarAngles[s.id];
    const radius = 50 + s.confidence * 38;
    const rad = (angle * Math.PI) / 180;
    return { ...s, x: 100 + Math.cos(rad)*radius, y: 100 + Math.sin(rad)*radius, r: 7 + (s.impact > 100000 ? 6 : s.impact > 10000 ? 3 : 0) };
  });

  return (
    <div className="screen" style={{
      background:'linear-gradient(180deg, #0F2A1E 0%, #143B2A 60%, #0A1410 100%)',
      overflowY:'auto', overflowX:'hidden', position:'relative',
    }}>
      <StatusBar color="#F6FBEF"/>

      {/* Ambient stars background */}
      <div style={{ position:'absolute', inset:0, pointerEvents:'none' }}>
        {Array.from({length: 28}).map((_,i) => {
          const left = (i*73 + i*17) % 100;
          const top = (i*41 + 7) % 100;
          const sz = 1 + (i%3);
          return (
            <div key={i} style={{
              position:'absolute', left:`${left}%`, top:`${top}%`,
              width:sz, height:sz, borderRadius:'50%',
              background:'#C7EE9C', opacity: 0.18 + (i%5)*0.06,
              animation: `mf-twinkle ${2 + (i%4)}s ease-in-out infinite`,
              animationDelay: `${(i%6)*0.3}s`,
            }}/>
          );
        })}
      </div>

      {/* Top bar — assistant identity */}
      <div style={{
        padding:'4px 18px 12px', display:'flex', alignItems:'center', gap:12,
        position:'relative', zIndex:2,
      }}>
        <button style={{
          width:34, height:34, borderRadius:10, border:'none', cursor:'pointer',
          background:'rgba(199,238,156,0.1)', color:'#C7EE9C',
          display:'grid', placeItems:'center', fontFamily:'inherit',
        }}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M15 18l-6-6 6-6"/></svg>
        </button>
        <div style={{ flex:1, display:'flex', alignItems:'center', gap:10 }}>
          <div style={{ position:'relative' }}>
            <div style={{
              width:38, height:38, borderRadius:'50%',
              background:'linear-gradient(135deg, #C7EE9C, #2E9A5F)',
              display:'grid', placeItems:'center',
              boxShadow:'0 4px 14px rgba(199,238,156,0.3)',
            }}>
              <AsIcon name="spark" size={18} color="#0F2A1E"/>
            </div>
            <span style={{
              position:'absolute', bottom:-1, right:-1, width:11, height:11,
              background:'#6FE09A', border:'2px solid #0F2A1E', borderRadius:'50%',
              animation:'mf-pulse-ring 2.4s ease-out infinite',
            }}/>
          </div>
          <div>
            <div style={{ fontSize:14, fontWeight:800, color:'#F6FBEF', letterSpacing:-0.2 }}>
              Asistente
            </div>
            <div style={{ fontSize:10.5, color:'rgba(199,238,156,0.7)', fontWeight:600,
              display:'flex', alignItems:'center', gap:5 }}>
              <span style={{ width:5, height:5, borderRadius:'50%', background:'#6FE09A',
                boxShadow:'0 0 6px #6FE09A' }}/>
              Mirando tus números · {SIGNALS.length} cosas para vos
            </div>
          </div>
        </div>
        <div style={{
          padding:'5px 11px', borderRadius:999,
          background:'rgba(199,238,156,0.14)', color:'#C7EE9C',
          fontSize:10.5, fontWeight:800, letterSpacing:0.4,
          fontVariantNumeric:'tabular-nums',
          border:'1px solid rgba(199,238,156,0.2)',
        }}>+{fmtARS(TOTAL_IMPACT)}/mes</div>
      </div>

      {/* Mini-map — constellation or radar (toggleable) */}
      <div style={{
        margin:'0 18px 14px', padding:'10px 12px 14px',
        background:'rgba(0,0,0,0.25)', backdropFilter:'blur(10px)',
        borderRadius:18, border:'1px solid rgba(199,238,156,0.12)',
        position:'relative', zIndex:2,
        animation:'mf-rise .6s ease both',
      }}>
        {/* Mode toggle */}
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:8 }}>
          <div style={{ display:'flex', alignItems:'center', gap:6 }}>
            <span style={{ fontSize:9, fontWeight:800, letterSpacing:1.6, color:'rgba(199,238,156,0.6)' }}>
              MAPA DEL CICLO
            </span>
            <span style={{ fontSize:9, color:'rgba(246,251,239,0.35)' }}>· día 22 / 30</span>
          </div>
          <div style={{
            display:'inline-flex', padding:2, borderRadius:8,
            background:'rgba(0,0,0,0.4)', border:'1px solid rgba(199,238,156,0.1)',
          }}>
            {[
              { id:'constellation', label:'Mapa' },
              { id:'radar', label:'Radar' },
            ].map(m => (
              <button key={m.id} onClick={()=>setMapMode(m.id)} style={{
                padding:'4px 9px', borderRadius:6, border:'none', cursor:'pointer',
                background: mapMode===m.id ? 'rgba(199,238,156,0.18)' : 'transparent',
                color: mapMode===m.id ? '#C7EE9C' : 'rgba(246,251,239,0.45)',
                fontSize:10, fontWeight:800, letterSpacing:0.4, fontFamily:'inherit',
                transition:'all 180ms',
              }}>{m.label}</button>
            ))}
            <button onClick={()=>setExpanded(!expanded)} style={{
              padding:'4px 8px', borderRadius:6, border:'none', cursor:'pointer',
              background:'transparent', color:'rgba(246,251,239,0.45)',
              fontSize:11, fontWeight:800, fontFamily:'inherit',
              display:'grid', placeItems:'center',
            }} aria-label={expanded ? 'Contraer' : 'Expandir'}>
              <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
                {expanded
                  ? <path d="M9 9L4 4M4 4v5M4 4h5M15 15l5 5M20 20v-5M20 20h-5"/>
                  : <path d="M3 9V3h6M21 9V3h-6M3 15v6h6M21 15v6h-6"/>
                }
              </svg>
            </button>
          </div>
        </div>

        {/* The map */}
        <div style={{
          position:'relative', height: expanded ? 240 : 140,
          borderRadius:14, overflow:'hidden',
          background: mapMode === 'radar'
            ? 'radial-gradient(circle at 50% 50%, rgba(46,154,95,0.22) 0%, rgba(15,42,30,0) 70%)'
            : 'radial-gradient(ellipse at 50% 50%, rgba(46,154,95,0.18), transparent 70%)',
          transition:'height 320ms cubic-bezier(.2,.8,.2,1)',
        }}>
          {mapMode === 'constellation' ? (
            <ConstellationView nodes={constellationNodes} active={active} onTap={onNodeTap} expanded={expanded}/>
          ) : (
            <RadarView points={radarPoints} active={active} onTap={onNodeTap} expanded={expanded}/>
          )}
        </div>

        {/* Legend / mini stats */}
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', gap:8, marginTop:10 }}>
          <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
            {[
              { type:'critical', label:'urgente' },
              { type:'warning',  label:'aviso' },
              { type:'positive', label:'a favor' },
            ].map(l => {
              const t = TYPE_TONES[l.type];
              const count = SIGNALS.filter(s=>s.type===l.type).length;
              return (
                <div key={l.type} style={{
                  display:'inline-flex', alignItems:'center', gap:4,
                  padding:'3px 7px', borderRadius:6,
                  background:'rgba(0,0,0,0.3)',
                  fontSize:9, fontWeight:700, color:'rgba(246,251,239,0.7)',
                  letterSpacing:0.4,
                }}>
                  <span style={{ width:6, height:6, borderRadius:'50%', background:t.accent }}/>
                  {count} {l.label}
                </div>
              );
            })}
          </div>
          <div style={{ fontSize:9, color:'rgba(246,251,239,0.4)', fontWeight:600, letterSpacing:0.3 }}>
            Tocá un punto
          </div>
        </div>
      </div>

      {/* Chat conversation */}
      <div style={{ padding:'4px 16px 8px', position:'relative', zIndex:2 }}>
        {visibleSignals.map((s, idx) => {
          const t = TYPE_TONES[s.type];
          const isCritical = s.urgency === 'alta';
          const isActive = idx === active;
          const intro = {
            'recovery-hard': '⚠️ Una urgente',
            'zombie-disney': 'Algo raro encontré',
            'positive-forecast': '✨ Buenas noticias',
            'cat-accel-restos': 'Mirá esto',
            'streak-ok': '¡Ey!',
          }[s.id];
          const seen = seenIds.includes(s.id);
          return (
            <div key={s.id}
              ref={el => messageRefs.current[idx] = el}
              style={{
                animation:`mf-rise .5s ${idx*0.08}s ease both`,
                display:'flex', flexDirection:'column', gap:5,
                marginTop: idx === 0 ? 0 : 14,
                opacity: seen ? 0.5 : 1,
                transition:'opacity 280ms',
              }}>
              {/* Intro tag (with timestamp aesthetic) */}
              <div style={{ display:'flex', alignItems:'center', gap:8,
                paddingLeft:6, marginBottom:2 }}>
                <span style={{ fontSize:10.5, color:'rgba(199,238,156,0.7)', fontWeight:700, letterSpacing:0.2 }}>
                  {intro}
                </span>
                <span style={{ fontSize:9, color:'rgba(246,251,239,0.3)', fontWeight:600 }}>
                  · ahora
                </span>
              </div>

              {/* Bubble */}
              <div style={{
                background: isActive
                  ? `linear-gradient(135deg, rgba(255,251,242,1), ${t.soft})`
                  : '#FFFBF2',
                border:`1.5px solid ${isActive ? t.accent : isCritical ? `${t.accent}aa` : 'rgba(15,42,30,0.08)'}`,
                borderRadius:'18px 18px 18px 4px',
                padding:'14px 16px',
                position:'relative',
                boxShadow: isActive
                  ? `0 6px 20px ${t.accent}33, 0 0 0 4px ${t.accent}22`
                  : '0 2px 10px rgba(0,0,0,0.18)',
                transition:'all 280ms cubic-bezier(.2,.8,.2,1)',
                cursor:'pointer',
              }}
              onClick={()=>setActive(idx)}>
                {/* Top — icon + headline tag */}
                <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:6 }}>
                  <div style={{ width:24, height:24, borderRadius:7, background:t.bg, color:t.fg,
                    display:'grid', placeItems:'center', flexShrink:0 }}>
                    <AsIcon name={s.icon} size={13}/>
                  </div>
                  <span style={{ fontSize:9.5, fontWeight:800, letterSpacing:1.3, color:t.fg }}>
                    {s.headline.toUpperCase()}
                  </span>
                  {isCritical && (
                    <span style={{
                      marginLeft:'auto', padding:'2px 6px', borderRadius:5,
                      background: t.fg, color:'#fff',
                      fontSize:8.5, fontWeight:800, letterSpacing:0.8,
                      animation:'mf-breathe 2.4s ease-in-out infinite',
                    }}>URGENTE</span>
                  )}
                </div>

                {/* Title */}
                <div style={{ fontSize:15, fontWeight:800, color:'#0F2A1E',
                  letterSpacing:-0.2, lineHeight:1.3 }}>
                  {s.title}
                </div>

                {/* Body */}
                <div style={{ fontSize:12.5, color:'#3E5A4A', marginTop:6, lineHeight:1.5 }}>
                  {s.body}
                </div>

                {/* Big impact bar */}
                <div style={{ marginTop:11, padding:'9px 11px', borderRadius:10,
                  background:t.soft, display:'flex', alignItems:'center', justifyContent:'space-between',
                  border:`1px solid ${t.edge}`,
                }}>
                  <span style={{ fontSize:9.5, fontWeight:800, color:t.fg, letterSpacing:0.6, textTransform:'uppercase' }}>
                    {s.impactLabel}
                  </span>
                  <span className="sf-display" style={{
                    fontSize:18, fontWeight:900, color:t.fg, letterSpacing:-0.4,
                    fontVariantNumeric:'tabular-nums',
                  }}>{s.deltaLabel}</span>
                </div>

                {/* Confidence + builder id */}
                <div style={{ display:'flex', alignItems:'center', gap:6, marginTop:8 }}>
                  <span style={{ fontSize:9, color:'#9AA39D', fontWeight:700, letterSpacing:0.4 }}>
                    {s.tier === 'solid' ? '●●●' : s.tier === 'building' ? '●●○' : '●○○'} {s.confidenceLabel}
                  </span>
                  <span style={{ fontSize:9, color:'#C9C0AB' }}>·</span>
                  <span style={{ fontSize:9, color:'#9AA39D', fontWeight:600, fontFamily:'JetBrains Mono, monospace' }}>
                    {s.builder}
                  </span>
                </div>
              </div>

              {/* Quick replies */}
              {!seen && (
                <div style={{ display:'flex', gap:6, justifyContent:'flex-end', marginTop:2,
                  flexWrap:'wrap', paddingRight:6 }}>
                  <button style={{
                    background: `linear-gradient(135deg, ${t.accent}, ${t.fg})`,
                    color: s.type === 'warning' ? '#0F2A1E' : '#fff', border:'none',
                    padding:'9px 14px', borderRadius:'14px 14px 4px 14px',
                    cursor:'pointer', fontSize:12, fontWeight:800, fontFamily:'inherit',
                    display:'flex', alignItems:'center', gap:5,
                    boxShadow:`0 3px 12px ${t.accent}55`,
                  }}>
                    {s.cta} <AsIcon name="arrow-up-right" size={11}/>
                  </button>
                  <button onClick={(e)=>{e.stopPropagation(); setSeenIds([...seenIds, s.id]);}} style={{
                    background:'rgba(255,251,242,0.15)', color:'rgba(246,251,239,0.7)',
                    border:'1px solid rgba(246,251,239,0.18)',
                    padding:'9px 13px', borderRadius:'14px 14px 4px 14px',
                    cursor:'pointer', fontSize:12, fontWeight:700, fontFamily:'inherit',
                    backdropFilter:'blur(6px)',
                  }}>Visto</button>
                </div>
              )}
              {seen && (
                <div style={{ display:'flex', justifyContent:'flex-end', paddingRight:6, marginTop:2 }}>
                  <span style={{ fontSize:10, color:'rgba(199,238,156,0.45)', fontWeight:700,
                    display:'inline-flex', alignItems:'center', gap:4 }}>
                    <AsIcon name="check" size={11}/> Visto · vuelve si persiste
                  </span>
                </div>
              )}
            </div>
          );
        })}

        {/* Typing indicator */}
        <div style={{ marginTop:18, display:'flex', alignItems:'center', gap:8, opacity:0.7 }}>
          <div style={{
            width:24, height:24, borderRadius:'50%',
            background:'linear-gradient(135deg, #C7EE9C, #2E9A5F)',
            display:'grid', placeItems:'center',
          }}>
            <AsIcon name="spark" size={11} color="#0F2A1E"/>
          </div>
          <div style={{ display:'flex', gap:3, padding:'8px 12px',
            background:'rgba(255,251,242,0.1)', borderRadius:'14px 14px 14px 4px',
            border:'1px solid rgba(199,238,156,0.12)' }}>
            {[0,1,2].map(i => (
              <span key={i} style={{
                width:5, height:5, borderRadius:'50%', background:'#C7EE9C',
                animation:`mf-typing 1.4s ${i*0.2}s ease-in-out infinite`,
              }}/>
            ))}
          </div>
          <span style={{ fontSize:10, color:'rgba(246,251,239,0.45)', fontWeight:600 }}>
            Aprendiendo de tu ritmo…
          </span>
        </div>

        {/* Compose / Ask bar (allows user to ask a question) */}
        <div style={{
          margin:'18px 0 8px', padding:'10px 14px',
          background:'rgba(255,251,242,0.08)',
          backdropFilter:'blur(8px)',
          border:'1px solid rgba(199,238,156,0.18)', borderRadius:18,
          display:'flex', alignItems:'center', gap:10,
        }}>
          <span style={{ fontSize:13, color:'rgba(246,251,239,0.5)', flex:1 }}>
            Preguntale a tu asistente…
          </span>
          <div style={{ display:'flex', gap:4 }}>
            <button style={{
              width:30, height:30, borderRadius:9, border:'none', cursor:'pointer',
              background:'rgba(199,238,156,0.1)', color:'#C7EE9C',
              display:'grid', placeItems:'center',
            }}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 1a3 3 0 00-3 3v8a3 3 0 006 0V4a3 3 0 00-3-3z"/>
                <path d="M19 10v2a7 7 0 01-14 0v-2M12 19v4M8 23h8"/>
              </svg>
            </button>
            <button style={{
              width:30, height:30, borderRadius:9, border:'none', cursor:'pointer',
              background:'linear-gradient(135deg, #C7EE9C, #2E9A5F)',
              color:'#0F2A1E', display:'grid', placeItems:'center',
            }}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M22 2L11 13M22 2l-7 20-4-9-9-4z"/>
              </svg>
            </button>
          </div>
        </div>

        {/* Suggested prompts */}
        <div style={{ display:'flex', gap:6, flexWrap:'wrap', marginBottom:20 }}>
          {['¿En qué puedo ahorrar?', '¿Cómo voy con Ushuaia?', 'Mostrame mis fijos'].map(p => (
            <button key={p} style={{
              padding:'7px 12px', borderRadius:999, border:'1px solid rgba(199,238,156,0.18)',
              background:'rgba(0,0,0,0.25)', color:'rgba(246,251,239,0.85)',
              fontSize:11.5, fontWeight:600, cursor:'pointer', fontFamily:'inherit',
            }}>{p}</button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Constellation view (the dark night-sky map)
// ─────────────────────────────────────────────────────────────
function ConstellationView({ nodes, active, onTap, expanded }) {
  const sizeMult = expanded ? 1.6 : 1;
  return (
    <>
      {/* Connection lines */}
      <svg style={{ position:'absolute', inset:0, width:'100%', height:'100%' }} viewBox="0 0 100 100" preserveAspectRatio="none">
        {[[0,1],[0,2],[0,3],[0,4],[1,2],[2,3]].map(([a,b],i) => (
          <line key={i}
            x1={nodes[a].x} y1={nodes[a].y} x2={nodes[b].x} y2={nodes[b].y}
            stroke={active === a || active === b ? 'rgba(199,238,156,0.5)' : 'rgba(199,238,156,0.18)'}
            strokeWidth="0.18" strokeDasharray="0.6 0.6"
            style={{ animation:`mf-pulse-line 4s ease-in-out infinite`, animationDelay:`${i*0.3}s`,
              transition:'stroke 200ms' }}
          />
        ))}
      </svg>

      {/* Nodes */}
      {nodes.map((n, i) => {
        const t = TYPE_TONES[n.sig.type];
        const isActive = active === i;
        const r = n.r * sizeMult;
        return (
          <button key={n.sig.id}
            onClick={()=>onTap(i)}
            style={{
              position:'absolute', left:`${n.x}%`, top:`${n.y}%`,
              width:r, height:r, borderRadius:'50%',
              transform:'translate(-50%,-50%)',
              background:`radial-gradient(circle at 30% 30%, ${t.accent}, ${t.fg})`,
              border:`${isActive ? 2.5 : 1.5}px solid ${isActive ? '#F6FBEF' : 'rgba(246,251,239,0.35)'}`,
              cursor:'pointer', padding:0,
              boxShadow: isActive
                ? `0 0 0 6px rgba(246,251,239,0.08), 0 0 32px ${t.accent}aa`
                : `0 0 12px ${t.accent}66`,
              display:'grid', placeItems:'center',
              transition:'all 220ms cubic-bezier(.2,.8,.2,1)',
            }}
            aria-label={n.sig.headline}
          >
            <div style={{ color:'#0A1410' }}>
              <AsIcon name={n.sig.icon} size={r * 0.42}/>
            </div>
            {n.sig.urgency === 'alta' && (
              <span style={{
                position:'absolute', inset:-3, borderRadius:'50%',
                border:`1.5px solid ${t.accent}`, opacity:0.5,
                animation:'mf-pulse-ring 2s ease-out infinite',
              }}/>
            )}
            {expanded && (
              <span style={{
                position:'absolute', top:'100%', left:'50%', transform:'translateX(-50%)',
                marginTop:6, fontSize:9, fontWeight:800, color:'#F6FBEF',
                background:'rgba(0,0,0,0.6)', padding:'2px 6px', borderRadius:6,
                whiteSpace:'nowrap', letterSpacing:0.3,
                fontVariantNumeric:'tabular-nums',
              }}>{n.sig.deltaLabel}</span>
            )}
          </button>
        );
      })}
    </>
  );
}

// ─────────────────────────────────────────────────────────────
// Radar view (polar dial with quadrants)
// ─────────────────────────────────────────────────────────────
function RadarView({ points, active, onTap, expanded }) {
  return (
    <svg width="100%" height="100%" viewBox="0 0 200 200" preserveAspectRatio="xMidYMid meet">
      <defs>
        <radialGradient id="radarBg" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="rgba(199,238,156,0.18)"/>
          <stop offset="100%" stopColor="rgba(46,154,95,0)"/>
        </radialGradient>
        <linearGradient id="sweepArm" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="rgba(199,238,156,0)"/>
          <stop offset="100%" stopColor="rgba(199,238,156,0.32)"/>
        </linearGradient>
      </defs>

      <circle cx="100" cy="100" r="92" fill="url(#radarBg)"/>

      {/* Concentric rings */}
      {[28, 55, 82].map((r,i) => (
        <circle key={i} cx="100" cy="100" r={r} fill="none"
          stroke="rgba(199,238,156,0.12)" strokeWidth="0.6"
          strokeDasharray={i % 2 ? '2 3' : 'none'}/>
      ))}

      {/* Cross axes */}
      <line x1="100" y1="14" x2="100" y2="186" stroke="rgba(199,238,156,0.1)" strokeWidth="0.6"/>
      <line x1="14" y1="100" x2="186" y2="100" stroke="rgba(199,238,156,0.1)" strokeWidth="0.6"/>

      {/* Sweep */}
      <g style={{ transformOrigin:'100px 100px', animation:'mf-radar-sweep 6s linear infinite' }}>
        <path d="M100 100 L100 14 A86 86 0 0 1 162 42 Z" fill="url(#sweepArm)" opacity="0.55"/>
      </g>

      {/* Quadrant labels (compact) */}
      {expanded && (
        <>
          <text x="100" y="9" textAnchor="middle" fill="rgba(199,238,156,0.5)" fontSize="6" fontWeight="800" letterSpacing="1.5">CRÍTICO</text>
          <text x="194" y="103" textAnchor="end" fill="rgba(199,238,156,0.5)" fontSize="6" fontWeight="800" letterSpacing="1.5">AVISO</text>
          <text x="100" y="196" textAnchor="middle" fill="rgba(199,238,156,0.5)" fontSize="6" fontWeight="800" letterSpacing="1.5">A FAVOR</text>
          <text x="6" y="103" textAnchor="start" fill="rgba(199,238,156,0.5)" fontSize="6" fontWeight="800" letterSpacing="1.5">NOTA</text>
        </>
      )}

      {/* Lines from center to active point */}
      {points.map((p, i) => {
        if (i !== active) return null;
        const t = TYPE_TONES[p.type];
        return (
          <line key={p.id+'-line'}
            x1="100" y1="100" x2={p.x} y2={p.y}
            stroke={t.accent} strokeWidth="1" opacity="0.8"
          />
        );
      })}

      {/* Points */}
      {points.map((p, i) => {
        const t = TYPE_TONES[p.type];
        const isActive = i === active;
        return (
          <g key={p.id} style={{ cursor:'pointer' }} onClick={()=>onTap(i)}>
            <circle cx={p.x} cy={p.y} r={p.r * 2.4} fill={t.accent} opacity={isActive ? 0.18 : 0.08}/>
            {p.urgency === 'alta' && (
              <circle cx={p.x} cy={p.y} r={p.r + 3} fill="none" stroke={t.accent} strokeWidth="0.8"
                opacity="0.5" style={{ animation:'mf-pulse-ring 2s ease-out infinite' }}/>
            )}
            <circle cx={p.x} cy={p.y} r={p.r}
              fill={t.accent}
              stroke={isActive ? '#F6FBEF' : 'rgba(15,42,30,0.4)'}
              strokeWidth={isActive ? 1.6 : 0.8}/>
          </g>
        );
      })}

      {/* Center bubble */}
      <circle cx="100" cy="100" r="22" fill="#0F2A1E" stroke="rgba(199,238,156,0.25)" strokeWidth="0.8"/>
      <text x="100" y="98" textAnchor="middle" fill="rgba(199,238,156,0.5)" fontSize="5" fontWeight="800" letterSpacing="0.8">CICLO</text>
      <text x="100" y="108" textAnchor="middle" fill="#C7EE9C" fontSize="9" fontWeight="900" fontFamily="-apple-system, sans-serif" letterSpacing="-0.3">
        {fmtARS(TOTAL_IMPACT)}
      </text>
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────
// Compact entry point — shown on Home as a card you can tap
// to open the full conversation.
// ─────────────────────────────────────────────────────────────
function AsesorHomeCard() {
  const lead = SIGNALS[0]; // most urgent
  const t = TYPE_TONES[lead.type];

  // 3 most-impactful signals as mini-list
  const top3 = [...SIGNALS].sort((a,b) => b.impact - a.impact).slice(0, 3);

  return (
    <div style={{
      position:'relative', borderRadius:24, overflow:'hidden',
      background:'linear-gradient(135deg, #0F2A1E 0%, #1F6B43 100%)',
      border:'1px solid rgba(199,238,156,0.2)',
      animation:'mf-rise .7s ease both',
    }}>
      {/* Stars background */}
      <div style={{ position:'absolute', inset:0, pointerEvents:'none' }}>
        {Array.from({length: 14}).map((_,i) => {
          const left = (i*73 + 7) % 100;
          const top = (i*41 + 11) % 100;
          return (
            <div key={i} style={{
              position:'absolute', left:`${left}%`, top:`${top}%`,
              width:2, height:2, borderRadius:'50%',
              background:'#C7EE9C', opacity: 0.3 + (i%4)*0.1,
              animation: `mf-twinkle ${2 + (i%4)}s ease-in-out infinite`,
              animationDelay: `${(i%6)*0.3}s`,
            }}/>
          );
        })}
      </div>

      {/* Header */}
      <div style={{ position:'relative', padding:'16px 18px 12px',
        display:'flex', alignItems:'center', gap:10, zIndex:1 }}>
        <div style={{ position:'relative' }}>
          <div style={{
            width:34, height:34, borderRadius:'50%',
            background:'linear-gradient(135deg, #C7EE9C, #2E9A5F)',
            display:'grid', placeItems:'center',
          }}>
            <AsIcon name="spark" size={16} color="#0F2A1E"/>
          </div>
          <span style={{
            position:'absolute', bottom:-1, right:-1, width:10, height:10,
            background:'#6FE09A', border:'2px solid #0F2A1E', borderRadius:'50%',
            animation:'mf-pulse-ring 2.4s ease-out infinite',
          }}/>
        </div>
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ fontSize:10, fontWeight:800, letterSpacing:1.5, color:'#C7EE9C' }}>
            ASISTENTE
          </div>
          <div style={{ fontSize:13, color:'rgba(246,251,239,0.7)', marginTop:1, fontWeight:600 }}>
            {SIGNALS.length} cosas para vos
          </div>
        </div>
        <div style={{
          padding:'5px 11px', borderRadius:999,
          background:'rgba(199,238,156,0.15)', color:'#C7EE9C',
          fontSize:11, fontWeight:800, letterSpacing:0.4,
          border:'1px solid rgba(199,238,156,0.22)',
          fontVariantNumeric:'tabular-nums',
        }}>+{fmtARS(TOTAL_IMPACT)}</div>
      </div>

      {/* Chat bubble preview (only the lead message) */}
      <div style={{ position:'relative', padding:'0 18px 14px', zIndex:1 }}>
        <div style={{ fontSize:10, color:'rgba(199,238,156,0.65)', fontWeight:700, marginBottom:4, paddingLeft:4 }}>
          ⚠️ Una urgente · ahora
        </div>
        <div style={{
          background:'#FFFBF2', border:`1.5px solid ${t.accent}`,
          borderRadius:'16px 16px 16px 4px',
          padding:'12px 14px',
          boxShadow:`0 4px 16px ${t.accent}33`,
        }}>
          <div style={{ display:'flex', alignItems:'center', gap:7, marginBottom:5 }}>
            <div style={{ width:22, height:22, borderRadius:6, background:t.bg, color:t.fg,
              display:'grid', placeItems:'center' }}>
              <AsIcon name={lead.icon} size={12}/>
            </div>
            <span style={{ fontSize:9, fontWeight:800, letterSpacing:1.2, color:t.fg }}>
              {lead.headline.toUpperCase()}
            </span>
            <span style={{
              marginLeft:'auto', padding:'2px 6px', borderRadius:5,
              background: t.fg, color:'#fff',
              fontSize:8, fontWeight:800, letterSpacing:0.8,
            }}>URGENTE</span>
          </div>
          <div style={{ fontSize:13.5, fontWeight:800, color:'#0F2A1E',
            letterSpacing:-0.2, lineHeight:1.3 }}>
            {lead.title}
          </div>
        </div>
      </div>

      {/* Mini constellation strip — bottom row teasing the rest */}
      <div style={{ position:'relative', padding:'10px 18px 16px', zIndex:1,
        borderTop:'1px solid rgba(199,238,156,0.12)',
        background:'rgba(0,0,0,0.18)',
      }}>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
          <div style={{ fontSize:9, fontWeight:800, letterSpacing:1.4, color:'rgba(199,238,156,0.55)' }}>
            Y +{SIGNALS.length-1} señales más
          </div>
          <span style={{ fontSize:11, fontWeight:800, color:'#C7EE9C',
            display:'inline-flex', alignItems:'center', gap:4 }}>
            Abrir chat <AsIcon name="arrow-up-right" size={11}/>
          </span>
        </div>
        <div style={{ display:'flex', gap:8, marginTop:10, alignItems:'center' }}>
          {SIGNALS.map((s,i) => {
            const t = TYPE_TONES[s.type];
            const sz = 22 + (s.impact > 100000 ? 10 : s.impact > 10000 ? 4 : 0);
            return (
              <div key={s.id} style={{ position:'relative' }}>
                <div style={{
                  width:sz, height:sz, borderRadius:'50%',
                  background:`radial-gradient(circle at 30% 30%, ${t.accent}, ${t.fg})`,
                  border:'1.5px solid rgba(246,251,239,0.3)',
                  display:'grid', placeItems:'center',
                  boxShadow:`0 0 12px ${t.accent}55`,
                }}>
                  <span style={{ color:'#0A1410', display:'grid', placeItems:'center' }}>
                    <AsIcon name={s.icon} size={sz * 0.5}/>
                  </span>
                </div>
                {s.urgency === 'alta' && (
                  <span style={{
                    position:'absolute', inset:-2, borderRadius:'50%',
                    border:`1.2px solid ${t.accent}`, opacity:0.6,
                    animation:'mf-pulse-ring 2s ease-out infinite',
                  }}/>
                )}
              </div>
            );
          })}
          {/* Connector dots */}
          <div style={{ flex:1, display:'flex', alignItems:'center', gap:3, marginLeft:6 }}>
            {Array.from({length:8}).map((_,i)=>(
              <span key={i} style={{ width:3, height:3, borderRadius:'50%',
                background:'rgba(199,238,156,0.25)' }}/>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// Wrapper for full-page demo
function AsesorFusionScreen() {
  return <AsesorFusion entry="full"/>;
}

// Wrapper for the Home card preview (compact)
function AsesorHomeCardScreen() {
  return (
    <div className="screen" style={{ background:'#EFF5E8', overflowY:'auto', padding:'18px 18px 60px' }}>
      <StatusBar color="#0F2A1E"/>
      <div style={{ height:6 }}/>

      {/* Mock home header */}
      <div style={{ padding:'4px 4px 14px', display:'flex', alignItems:'center', justifyContent:'space-between' }}>
        <div>
          <div className="sf-display" style={{ fontSize:30, fontWeight:800, letterSpacing:-1.2, lineHeight:1, color:'#0F2A1E' }}>
            Hola, Mario
          </div>
          <div style={{ fontSize:13, color:'#6F7A73', marginTop:6, fontWeight:500 }}>
            Día 22 · cobro en 8 días
          </div>
        </div>
        <div style={{ display:'flex', gap:8 }}>
          <div style={{ width:36, height:36, borderRadius:999, background:'#FFFBF2', border:'1px solid #EFE8D9' }}/>
          <div style={{ width:36, height:36, borderRadius:999, background:'#FFFBF2', border:'1px solid #EFE8D9' }}/>
        </div>
      </div>

      {/* Mock disponible card (compressed) */}
      <div style={{ background:'#0F2A1E', borderRadius:22, padding:'16px 18px', color:'#F6FBEF', marginBottom:14 }}>
        <div style={{ fontSize:10, color:'#C7EE9C', fontWeight:800, letterSpacing:1.4 }}>DISPONIBLE HOY</div>
        <div className="sf-display" style={{ fontSize:36, fontWeight:800, letterSpacing:-1.4, marginTop:4, lineHeight:1 }}>
          $187.514
        </div>
        <div style={{ fontSize:12, color:'rgba(246,251,239,0.65)', marginTop:5 }}>
          Cupo del día · gastaste $12.400
        </div>
      </div>

      {/* THE CARD */}
      <AsesorHomeCard/>

      {/* Mock more home content below */}
      <div style={{ marginTop:14, padding:'14px 16px', background:'#FFFBF2', borderRadius:18, border:'1px solid #EFE8D9' }}>
        <div style={{ fontSize:10, color:'#6F7A73', fontWeight:800, letterSpacing:1.4 }}>RECIENTE</div>
        <div style={{ fontSize:13, color:'#0F2A1E', marginTop:4, fontWeight:600 }}>3 movimientos hoy</div>
      </div>
    </div>
  );
}

Object.assign(window, { AsesorFusion, AsesorFusionScreen, AsesorHomeCard, AsesorHomeCardScreen });
