// Asesor Financiero — 4 rediseños radicales
// Cada uno explora un lenguaje visual distinto para comunicar:
// 30 signals · confianza ramping · urgencia · swipe-to-dismiss · acciones únicas

const { useState: useStateAs, useEffect: useEffectAs, useMemo: useMemoAs, useRef: useRefAs } = React;

// ─────────────────────────────────────────────────────────────
// DATA — 5 signals representativos de los 30 builders
// ─────────────────────────────────────────────────────────────
const SIGNALS = [
  {
    id: 'recovery-hard',
    type: 'critical',
    title: 'Recortá $42.300/día los próximos 8 días',
    headline: 'Si no, te pasás del libre del mes',
    body: 'Gastaste $612k de tu libre $950k. Quedan 8 días con cupo $42.300. Sin recorte, te pasás $87k.',
    impact: 87000,
    impactLabel: 'Sobregiro proyectado',
    deltaLabel: '−$87.000',
    confidence: 1.0,
    confidenceLabel: 'Datos en vivo',
    tier: 'solid',
    urgency: 'alta',
    cta: 'Ajustar cupo',
    actionKind: 'navigate',
    icon: 'shield-alert',
    builder: 'recovery-hard',
    days: 8,
    impactDir: 'down',
  },
  {
    id: 'zombie-disney',
    type: 'critical',
    title: 'Disney+ no se usa hace 2 meses',
    headline: 'Suscripción zombie',
    body: 'Pagás $4.200/mes. Última vez que el contenido se vinculó a tu cuenta: 14 feb. Cancelar libera $50.400/año.',
    impact: 50400,
    impactLabel: 'Ahorro anual',
    deltaLabel: '+$50.400/año',
    confidence: 0.92,
    confidenceLabel: 'Confirmado',
    tier: 'solid',
    urgency: 'alta',
    cta: 'Cancelar',
    actionKind: 'open-fixed-expense',
    icon: 'ghost',
    builder: 'zombie',
    impactDir: 'up',
  },
  {
    id: 'positive-forecast',
    type: 'positive',
    title: 'Vas a sobrar $3.842.604 este mes',
    headline: 'Excedente proyectado',
    body: 'Si mantenés el ritmo de los últimos 7 días, cerrás con saldo a favor. Sugerencia: mover $1.921.000 a "Ushuaia" ahora.',
    impact: 1921000,
    impactLabel: 'Movimiento sugerido',
    deltaLabel: '+$1.921.000',
    confidence: 0.78,
    confidenceLabel: 'Evidencia parcial',
    tier: 'building',
    urgency: 'baja',
    cta: 'Mover $1.921.000',
    actionKind: 'quick-savings-contribution',
    icon: 'piggy',
    builder: 'positive-forecast',
    impactDir: 'up',
  },
  {
    id: 'cat-accel-restos',
    type: 'warning',
    title: 'Restaurantes: 47% del gasto del mes',
    headline: 'Categoría dominante',
    body: 'De $475k gastados, $225k son restaurantes. Bajar 10% acá rinde más que tocar varias menores.',
    impact: 22575,
    impactLabel: 'Si bajás 10%',
    deltaLabel: '+$22.575/mes',
    confidence: 0.85,
    confidenceLabel: 'Confirmado',
    tier: 'solid',
    urgency: 'media',
    cta: 'Ver gastos',
    actionKind: 'open-expenses-filtered',
    icon: 'chart-pie',
    builder: 'cat-dominance',
    impactDir: 'up',
  },
  {
    id: 'streak-ok',
    type: 'positive',
    title: 'Llevás 3 días bajo cupo',
    headline: 'Racha sostenida',
    body: 'Ritmo estable los últimos 3 días. A este paso, el cierre del mes deja un excedente de $3.842.604.',
    impact: 0,
    impactLabel: 'Refuerzo · cupo del día $187.514',
    deltaLabel: 'Cupo $187.514',
    confidence: 1.0,
    confidenceLabel: 'En curso',
    tier: 'solid',
    urgency: 'baja',
    cta: 'Entendido',
    actionKind: 'dismiss',
    icon: 'flame',
    builder: 'streak-ok',
    impactDir: 'neutral',
  },
];

const TOTAL_IMPACT = SIGNALS.reduce((s, x) => s + x.impact, 0); // ~2.080.975

// ─────────────────────────────────────────────────────────────
// Iconos SVG inline (más sofisticados que MaterialIcons strings)
// ─────────────────────────────────────────────────────────────
function AsIcon({ name, size = 22, color = 'currentColor' }) {
  const s = size;
  switch (name) {
    case 'shield-alert':
      return (
        <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
          <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
          <path d="M12 8v5"/><circle cx="12" cy="16" r="0.8" fill={color} stroke="none"/>
        </svg>);
    case 'ghost':
      return (
        <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
          <path d="M5 11a7 7 0 0114 0v9l-2.5-1.5L14 20l-2-1.5L10 20l-2.5-1.5L5 20z"/>
          <circle cx="9.5" cy="11" r="0.9" fill={color} stroke="none"/>
          <circle cx="14.5" cy="11" r="0.9" fill={color} stroke="none"/>
        </svg>);
    case 'piggy':
      return (
        <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
          <path d="M5 13a6 6 0 016-6h3a6 6 0 016 6v1a3 3 0 01-2 2.8V19h-2v-2h-7v2H7v-2.2A3 3 0 015 14z"/>
          <circle cx="14.5" cy="12" r="0.9" fill={color} stroke="none"/>
          <path d="M9 9.5l3-1.5"/>
        </svg>);
    case 'chart-pie':
      return (
        <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
          <path d="M12 3v9l8 3a9 9 0 11-8-12z"/>
        </svg>);
    case 'flame':
      return (
        <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
          <path d="M12 22a6 6 0 006-6c0-3.5-2.5-5-3-7-.5 1-1.5 2-3 2.5C13 6 11 4 11 2c-2 3-5 6-5 10a6 6 0 006 6z"/>
        </svg>);
    case 'arrow-up-right':
      return (
        <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M7 17L17 7M9 7h8v8"/>
        </svg>);
    case 'spark':
      return (
        <svg width={s} height={s} viewBox="0 0 24 24" fill={color}>
          <path d="M12 2l1.8 6.2L20 10l-6.2 1.8L12 18l-1.8-6.2L4 10l6.2-1.8z"/>
        </svg>);
    case 'check':
      return (
        <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M5 12l4.5 4.5L19 7"/>
        </svg>);
    default:
      return null;
  }
}

// ─────────────────────────────────────────────────────────────
// Helper: format ARS short
// ─────────────────────────────────────────────────────────────
const fmtARS = (n) => {
  const abs = Math.abs(n);
  if (abs >= 1_000_000) return `$${(n/1_000_000).toFixed(abs >= 10_000_000 ? 1 : 2).replace(/\.?0+$/,'')}M`;
  if (abs >= 1_000) return `$${Math.round(n/1000)}k`;
  return `$${n}`;
};
const fmtARSFull = (n) => `$${Math.abs(n).toLocaleString('es-AR')}`;

// Color map per type
const TYPE_TONES = {
  critical: { fg:'#B33A1F', bg:'#FFE2D6', soft:'#FFF3EC', accent:'#D14E2A', edge:'#F0BFA8' },
  warning:  { fg:'#9C6A12', bg:'#FCEAC4', soft:'#FFF7E6', accent:'#C28F1E', edge:'#EBD49A' },
  positive: { fg:'#1C7E3A', bg:'#D4F0BF', soft:'#EBF8DD', accent:'#2E9A5F', edge:'#B7DD9A' },
  insight:  { fg:'#3E5A4A', bg:'#E2EAE2', soft:'#F0F4EE', accent:'#5C7762', edge:'#C5D2C7' },
};

// ═════════════════════════════════════════════════════════════
// V1 — CONSTELACIÓN DE INSIGHTS
// El asistente como mapa estelar: cada signal es una estrella
// con tamaño = impacto, color = tipo, conectada por líneas que
// muestran sinergia. La urgencia más alta está en el centro.
// Tap → expansión inline.
// ═════════════════════════════════════════════════════════════
function AsesorConstelacion() {
  const [active, setActive] = useStateAs(0); // recovery-hard primero por urgencia
  const sig = SIGNALS[active];
  const tone = TYPE_TONES[sig.type];

  // Posiciones del nodo en el mapa (orbital, en %)
  const nodes = [
    { x: 50, y: 48, r: 38, sig: SIGNALS[0] },  // critical centro
    { x: 18, y: 30, r: 28, sig: SIGNALS[1] },  // critical NW
    { x: 80, y: 26, r: 32, sig: SIGNALS[2] },  // positive NE (mayor impacto)
    { x: 78, y: 72, r: 24, sig: SIGNALS[3] },  // warning SE
    { x: 22, y: 76, r: 18, sig: SIGNALS[4] },  // positive SW pequeño
  ];

  return (
    <div style={{
      background:'#0A1410', borderRadius: 28, overflow:'hidden', position:'relative',
      border:'1px solid rgba(199,238,156,0.18)',
    }}>
      {/* Top eyebrow */}
      <div style={{
        padding:'18px 22px 0', display:'flex', alignItems:'center', justifyContent:'space-between',
      }}>
        <div style={{ display:'flex', alignItems:'center', gap:10 }}>
          <div style={{
            width:26, height:26, borderRadius:8,
            background:'linear-gradient(135deg, #C7EE9C, #6FE09A)',
            display:'grid', placeItems:'center',
          }}>
            <AsIcon name="spark" size={14} color="#0A1410"/>
          </div>
          <div>
            <div style={{ fontSize:10, fontWeight:800, letterSpacing:1.6, color:'#C7EE9C' }}>ASISTENTE</div>
            <div style={{ fontSize:11, color:'rgba(246,251,239,0.55)', marginTop:1 }}>Mapa de oportunidades</div>
          </div>
        </div>
        <div style={{
          padding:'4px 10px', borderRadius:999, background:'rgba(199,238,156,0.12)',
          fontSize:10, fontWeight:800, color:'#C7EE9C', letterSpacing:0.8,
        }}>5 SEÑALES</div>
      </div>

      {/* Hero impact total */}
      <div style={{ padding:'16px 22px 8px' }}>
        <div style={{ fontSize:11, color:'rgba(246,251,239,0.55)', fontWeight:600, letterSpacing:0.4 }}>
          Aplicando estas 5 acciones
        </div>
        <div style={{ display:'flex', alignItems:'baseline', gap:8, marginTop:4 }}>
          <div className="sf-display" style={{ fontSize:36, fontWeight:800, color:'#C7EE9C', letterSpacing:-1.5, lineHeight:1, fontVariantNumeric:'tabular-nums' }}>
            +{fmtARS(TOTAL_IMPACT)}
          </div>
          <div style={{ fontSize:13, color:'rgba(246,251,239,0.6)', fontWeight:600 }}>en el ciclo</div>
        </div>
      </div>

      {/* Constellation map */}
      <div style={{ position:'relative', height:280, margin:'12px 16px 0', borderRadius:20, overflow:'hidden',
        background:'radial-gradient(ellipse at 50% 50%, rgba(46,154,95,0.18), transparent 70%)',
      }}>
        {/* Star dust */}
        {Array.from({length: 36}).map((_,i) => {
          const left = (i*73 + i*17) % 100;
          const top = (i*53 + 11) % 100;
          const sz = 1 + (i%3);
          return (
            <div key={i} style={{
              position:'absolute', left:`${left}%`, top:`${top}%`,
              width:sz, height:sz, borderRadius:'50%',
              background:'#C7EE9C', opacity: 0.25 + (i%5)*0.08,
              animation: `mf-twinkle ${2 + (i%4)}s ease-in-out infinite`,
              animationDelay: `${(i%6)*0.3}s`,
            }}/>
          );
        })}

        {/* Connection lines (SVG) */}
        <svg style={{ position:'absolute', inset:0, width:'100%', height:'100%' }} viewBox="0 0 100 100" preserveAspectRatio="none">
          {[[0,1],[0,2],[0,3],[0,4],[1,2]].map(([a,b],i) => (
            <line key={i}
              x1={nodes[a].x} y1={nodes[a].y} x2={nodes[b].x} y2={nodes[b].y}
              stroke="rgba(199,238,156,0.18)" strokeWidth="0.18" strokeDasharray="0.6 0.6"
              style={{ animation:`mf-pulse-line 4s ease-in-out infinite`, animationDelay:`${i*0.3}s` }}
            />
          ))}
        </svg>

        {/* Nodes */}
        {nodes.map((n, i) => {
          const t = TYPE_TONES[n.sig.type];
          const isActive = active === i;
          return (
            <button key={n.sig.id}
              onClick={()=>setActive(i)}
              style={{
                position:'absolute', left:`${n.x}%`, top:`${n.y}%`,
                width:n.r, height:n.r, borderRadius:'50%',
                transform:'translate(-50%,-50%)',
                background:`radial-gradient(circle at 30% 30%, ${t.accent}, ${t.fg})`,
                border:`${isActive ? 2.5 : 1.5}px solid ${isActive ? '#F6FBEF' : 'rgba(246,251,239,0.35)'}`,
                cursor:'pointer', padding:0,
                boxShadow: isActive
                  ? `0 0 0 6px rgba(246,251,239,0.08), 0 0 32px ${t.accent}aa, 0 0 12px ${t.accent}`
                  : `0 0 16px ${t.accent}66`,
                display:'grid', placeItems:'center',
                transition:'all 220ms cubic-bezier(.2,.8,.2,1)',
              }}
              aria-label={n.sig.headline}
            >
              <div style={{ color:'#0A1410' }}>
                <AsIcon name={n.sig.icon} size={n.r * 0.42}/>
              </div>
              {/* Pulse ring for critical */}
              {n.sig.urgency === 'alta' && (
                <span style={{
                  position:'absolute', inset:-4, borderRadius:'50%',
                  border:`1.5px solid ${t.accent}`, opacity:0.5,
                  animation:'mf-pulse-ring 2s ease-out infinite',
                }}/>
              )}
              {/* Impact label flotando */}
              <span style={{
                position:'absolute', top:'100%', left:'50%', transform:'translateX(-50%)',
                marginTop:6, fontSize:9, fontWeight:800, color:'#F6FBEF',
                background:'rgba(0,0,0,0.5)', padding:'2px 6px', borderRadius:6,
                whiteSpace:'nowrap', letterSpacing:0.3, opacity: isActive ? 1 : 0.7,
                fontVariantNumeric:'tabular-nums',
              }}>
                {n.sig.deltaLabel}
              </span>
            </button>
          );
        })}
      </div>

      {/* Active signal details */}
      <div key={active} style={{ padding:'14px 22px 22px', animation:'mf-rise .4s ease both' }}>
        <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:6 }}>
          <span style={{
            padding:'3px 8px', borderRadius:6, background: tone.accent,
            fontSize:9, fontWeight:800, color: sig.type==='warning' ? '#0A1410' : '#fff', letterSpacing:1,
          }}>{sig.headline.toUpperCase()}</span>
          <span style={{ fontSize:10, color:'rgba(246,251,239,0.4)', fontWeight:600 }}>
            · {sig.confidenceLabel}
          </span>
        </div>
        <div style={{ fontSize:18, fontWeight:800, color:'#F6FBEF', lineHeight:1.25, letterSpacing:-0.3 }}>
          {sig.title}
        </div>
        <div style={{ fontSize:13, color:'rgba(246,251,239,0.65)', lineHeight:1.5, marginTop:6 }}>
          {sig.body}
        </div>

        {/* CTA + dismiss */}
        <div style={{ display:'flex', gap:8, marginTop:14 }}>
          <button style={{
            flex:1, border:'none', cursor:'pointer',
            background: `linear-gradient(135deg, ${tone.accent}, ${tone.fg})`,
            color: sig.type==='warning' ? '#0A1410' : '#fff',
            padding:'12px 16px', borderRadius:14, fontSize:13, fontWeight:800,
            fontFamily:'inherit', letterSpacing:0.2,
            display:'flex', alignItems:'center', justifyContent:'center', gap:6,
          }}>
            {sig.cta} <AsIcon name="arrow-up-right" size={14}/>
          </button>
          <button style={{
            border:'1px solid rgba(246,251,239,0.18)', cursor:'pointer',
            background:'transparent', color:'rgba(246,251,239,0.7)',
            padding:'10px 14px', borderRadius:14, fontSize:12, fontWeight:700,
            fontFamily:'inherit',
          }}>Saltar</button>
        </div>

        {/* Mini nav dots */}
        <div style={{ display:'flex', justifyContent:'center', gap:6, marginTop:14 }}>
          {SIGNALS.map((s,i) => {
            const t = TYPE_TONES[s.type];
            return (
              <button key={s.id} onClick={()=>setActive(i)} style={{
                width: i===active ? 22 : 6, height:6, borderRadius:999, border:'none', padding:0, cursor:'pointer',
                background: i===active ? t.accent : 'rgba(246,251,239,0.18)',
                transition:'all 200ms',
              }}/>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// V2 — PERIÓDICO FINANCIERO
// Editorial: tipografía monumental, headlines, sub-decks, kicker.
// Cada signal es una "edición" con jerarquía clara. Lead story
// es la urgencia mayor. Sidebar tiene los breves.
// ═════════════════════════════════════════════════════════════
function AsesorPeriodico() {
  const lead = SIGNALS[0]; // recovery-hard
  const second = SIGNALS[1]; // zombie
  const third = SIGNALS[2]; // positive forecast
  const briefs = [SIGNALS[3], SIGNALS[4]];

  return (
    <div style={{
      background:'#FAF4EA', borderRadius:18, border:'1.5px solid #2A3A31',
      padding:0, overflow:'hidden', position:'relative',
      fontFamily:"'Times New Roman', Georgia, serif",
    }}>
      {/* Masthead */}
      <div style={{
        borderBottom:'2px solid #0F2A1E', padding:'14px 20px 12px',
        display:'flex', alignItems:'center', justifyContent:'space-between',
        background:'#FFFBF2',
      }}>
        <div style={{ display:'flex', alignItems:'center', gap:10 }}>
          <div style={{ width:28, height:28, borderRadius:'50%', border:'2px solid #0F2A1E',
            display:'grid', placeItems:'center' }}>
            <AsIcon name="spark" size={14} color="#0F2A1E"/>
          </div>
          <div>
            <div className="sf-display" style={{ fontSize:22, fontWeight:900, color:'#0F2A1E', letterSpacing:-0.8, lineHeight:1, fontFamily:"'Times New Roman', serif" }}>
              EL ASISTENTE
            </div>
            <div style={{ fontSize:9, color:'#6F7A73', letterSpacing:1.5, fontWeight:700, marginTop:2,
              fontFamily:'system-ui' }}>
              EDICIÓN DEL DÍA · CICLO ABRIL · N° 22
            </div>
          </div>
        </div>
        <div style={{ textAlign:'right', fontFamily:'system-ui' }}>
          <div style={{ fontSize:9, color:'#6F7A73', letterSpacing:1, fontWeight:700 }}>IMPACTO TOTAL</div>
          <div style={{ fontSize:18, fontWeight:900, color:'#1C7E3A', letterSpacing:-0.3, fontVariantNumeric:'tabular-nums' }}>
            +{fmtARS(TOTAL_IMPACT)}
          </div>
        </div>
      </div>

      {/* Section divider */}
      <div style={{
        background:'#0F2A1E', color:'#F6FBEF', padding:'4px 20px',
        fontSize:10, fontWeight:800, letterSpacing:2.5, fontFamily:'system-ui',
        display:'flex', justifyContent:'space-between',
      }}>
        <span>PORTADA</span>
        <span>5 NOTAS</span>
      </div>

      {/* LEAD story — critical */}
      <div style={{ padding:'18px 20px 14px', borderBottom:'1px solid #E9E1D3' }}>
        <div style={{ display:'flex', gap:6, alignItems:'center', marginBottom:6 }}>
          <span style={{
            background:'#B33A1F', color:'#fff', fontSize:9, fontWeight:800,
            padding:'3px 7px', letterSpacing:1.5, fontFamily:'system-ui',
          }}>URGENTE</span>
          <span style={{ fontSize:10, color:'#6F7A73', fontFamily:'system-ui', fontWeight:600, letterSpacing:0.3 }}>
            · Datos en vivo · Confianza 100%
          </span>
        </div>
        <div className="sf-display" style={{
          fontSize:32, fontWeight:900, color:'#0F2A1E', lineHeight:1.05,
          letterSpacing:-1, marginTop:4,
          fontFamily:"'Times New Roman', Georgia, serif",
        }}>
          {lead.title}
        </div>
        <div style={{ fontSize:14, color:'#6F7A73', fontStyle:'italic', marginTop:8, lineHeight:1.4 }}>
          {lead.headline}. {lead.body}
        </div>

        {/* Big number + CTA inline */}
        <div style={{ marginTop:14, display:'flex', alignItems:'flex-end', gap:14, paddingTop:14, borderTop:'1px solid #E9E1D3' }}>
          <div>
            <div style={{ fontSize:9, color:'#6F7A73', fontWeight:800, letterSpacing:1.5, fontFamily:'system-ui' }}>
              SOBREGIRO PROYECTADO
            </div>
            <div className="sf-display" style={{ fontSize:42, fontWeight:900, color:'#B33A1F',
              letterSpacing:-1.6, lineHeight:1, fontVariantNumeric:'tabular-nums' }}>
              −{fmtARS(lead.impact)}
            </div>
          </div>
          <button style={{
            marginLeft:'auto', background:'#0F2A1E', color:'#FAF4EA', border:'none',
            padding:'12px 16px', cursor:'pointer', fontSize:12, fontWeight:800,
            letterSpacing:0.5, fontFamily:'system-ui',
            display:'flex', alignItems:'center', gap:6,
          }}>
            {lead.cta} <AsIcon name="arrow-up-right" size={13}/>
          </button>
        </div>
      </div>

      {/* Two columns — second + third */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', borderBottom:'1px solid #E9E1D3' }}>
        {[second, third].map((s, idx) => {
          const t = TYPE_TONES[s.type];
          return (
            <div key={s.id} style={{
              padding:'14px 16px', borderRight: idx===0 ? '1px solid #E9E1D3' : 'none',
            }}>
              <div style={{ display:'flex', gap:8, alignItems:'center' }}>
                <div style={{ width:24, height:24, borderRadius:6, background:t.bg,
                  display:'grid', placeItems:'center', color:t.fg }}>
                  <AsIcon name={s.icon} size={14}/>
                </div>
                <span style={{
                  fontSize:8, fontWeight:800, letterSpacing:1.5, color:t.fg,
                  fontFamily:'system-ui',
                }}>{s.headline.toUpperCase()}</span>
              </div>
              <div style={{
                fontSize:17, fontWeight:800, color:'#0F2A1E', lineHeight:1.1,
                letterSpacing:-0.4, marginTop:8,
                fontFamily:"'Times New Roman', Georgia, serif",
              }}>{s.title}</div>
              <div style={{ fontSize:11, color:'#6F7A73', marginTop:6, lineHeight:1.45 }}>
                {s.body}
              </div>
              <div style={{ marginTop:10, display:'flex', alignItems:'center', justifyContent:'space-between', gap:6 }}>
                <span className="sf-display" style={{
                  fontSize:15, fontWeight:900, color:t.fg, letterSpacing:-0.3,
                  fontVariantNumeric:'tabular-nums',
                }}>{s.deltaLabel}</span>
                <button style={{
                  background:'transparent', border:`1.5px solid ${t.fg}`, color:t.fg,
                  padding:'6px 10px', cursor:'pointer', fontSize:10, fontWeight:800,
                  fontFamily:'system-ui', letterSpacing:0.4,
                }}>{s.cta} ›</button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Section divider */}
      <div style={{
        background:'#FFFBF2', color:'#0F2A1E', padding:'6px 20px',
        fontSize:10, fontWeight:800, letterSpacing:2.5, fontFamily:'system-ui',
        borderBottom:'1px solid #E9E1D3',
      }}>BREVES</div>

      {/* Briefs row */}
      <div style={{ padding:'12px 20px 16px' }}>
        {briefs.map((s, i) => {
          const t = TYPE_TONES[s.type];
          return (
            <div key={s.id} style={{
              display:'flex', alignItems:'flex-start', gap:12,
              padding:'10px 0',
              borderBottom: i < briefs.length - 1 ? '1px dashed #E9E1D3' : 'none',
            }}>
              <div style={{
                width:28, height:28, borderRadius:6, background:t.bg, color:t.fg,
                display:'grid', placeItems:'center', flexShrink:0,
              }}>
                <AsIcon name={s.icon} size={15}/>
              </div>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{
                  fontSize:13, fontWeight:800, color:'#0F2A1E', letterSpacing:-0.2,
                  fontFamily:"'Times New Roman', Georgia, serif", lineHeight:1.2,
                }}>{s.title}</div>
                <div style={{ display:'flex', alignItems:'center', gap:8, marginTop:4 }}>
                  <span className="sf-display" style={{
                    fontSize:12, fontWeight:900, color:t.fg,
                    fontVariantNumeric:'tabular-nums',
                  }}>{s.deltaLabel}</span>
                  <span style={{ fontSize:9, color:'#9AA39D', fontWeight:600,
                    fontFamily:'system-ui', letterSpacing:0.3 }}>
                    · {s.confidenceLabel}
                  </span>
                </div>
              </div>
              <button style={{
                background:'transparent', border:'none', color:'#0F2A1E',
                padding:'4px 6px', cursor:'pointer', fontSize:11, fontWeight:800,
                fontFamily:'system-ui', letterSpacing:0.3, alignSelf:'center',
              }}>{s.cta} →</button>
            </div>
          );
        })}
      </div>

      {/* Footer */}
      <div style={{
        background:'#0F2A1E', color:'rgba(246,251,239,0.7)', padding:'8px 20px',
        fontSize:9, letterSpacing:0.4, fontFamily:'system-ui',
        display:'flex', justifyContent:'space-between',
      }}>
        <span>Próxima edición · cuando los patrones cambien</span>
        <span>Desliza para descartar</span>
      </div>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// V3 — SISMÓGRAFO FINANCIERO
// Vista horizontal: cada signal es una "onda sísmica" en una línea
// del tiempo. Altura = impacto. Color = tipo. La línea base es el
// cupo. Permite ver qué tan urgente vs ya pasado.
// Tap en la onda → detalle inline expandible.
// ═════════════════════════════════════════════════════════════
function AsesorSismografo() {
  const [open, setOpen] = useStateAs(0);

  // Cada signal con su "onda" representada en la timeline horizontal
  // x-position en el ciclo (día 0-30), y-amplitude por impacto
  const sortedByDay = [
    { ...SIGNALS[0], cycleDay: 22, height: 92, signed: -1 }, // recovery-hard NOW
    { ...SIGNALS[1], cycleDay: 14, height: 60, signed: +1 }, // zombie detectado
    { ...SIGNALS[2], cycleDay: 30, height: 78, signed: +1 }, // forecast cierre
    { ...SIGNALS[3], cycleDay: 18, height: 50, signed: +1 }, // cat dominance
    { ...SIGNALS[4], cycleDay: 22, height: 36, signed: +1 }, // streak today
  ];

  return (
    <div style={{
      background:'#FFFBF2', borderRadius:24, border:'1px solid #EFE8D9', overflow:'hidden',
    }}>
      {/* Header */}
      <div style={{ padding:'18px 22px 12px', display:'flex', alignItems:'center', justifyContent:'space-between' }}>
        <div style={{ display:'flex', alignItems:'center', gap:10 }}>
          <div style={{
            width:32, height:32, borderRadius:10, background:'#0F2A1E',
            display:'grid', placeItems:'center', position:'relative',
          }}>
            <AsIcon name="spark" size={16} color="#C7EE9C"/>
          </div>
          <div>
            <div style={{ fontSize:10, fontWeight:800, letterSpacing:1.6, color:'#6F7A73' }}>ASISTENTE</div>
            <div style={{ fontSize:13, fontWeight:800, color:'#0F2A1E', letterSpacing:-0.2 }}>
              Pulso del ciclo · día 22 / 30
            </div>
          </div>
        </div>
        <div style={{
          padding:'4px 10px', borderRadius:999, background:'#0F2A1E', color:'#C7EE9C',
          fontSize:10, fontWeight:800, letterSpacing:0.8,
        }}>+{fmtARS(TOTAL_IMPACT)}</div>
      </div>

      {/* Sismograph */}
      <div style={{ padding:'4px 22px 0', position:'relative' }}>
        <div style={{ position:'relative', height:140, background:'#F6F1E4', borderRadius:14,
          border:'1px solid #E9E1D3', overflow:'hidden',
        }}>
          {/* Day grid */}
          {Array.from({length:6}).map((_,i)=> (
            <div key={i} style={{
              position:'absolute', left:`${(i/6)*100}%`, top:0, bottom:0, width:1,
              background:'rgba(15,42,30,0.05)',
            }}/>
          ))}
          {/* Center baseline */}
          <div style={{ position:'absolute', left:0, right:0, top:'50%', height:1,
            borderTop:'1px dashed #C9C0AB' }}/>
          {/* "Today" indicator */}
          <div style={{ position:'absolute', left: `${(22/30)*100}%`, top:0, bottom:0, width:1.5,
            background:'#0F2A1E', opacity:0.7 }}/>
          <div style={{ position:'absolute', left: `${(22/30)*100}%`, top:4, transform:'translateX(-50%)',
            background:'#0F2A1E', color:'#C7EE9C', fontSize:9, fontWeight:800, padding:'2px 6px',
            borderRadius:6, letterSpacing:1, whiteSpace:'nowrap', marginLeft:0,
          }}>HOY</div>

          {/* Waves: SVG path per signal as a sin wave centered at cycleDay */}
          <svg style={{ position:'absolute', inset:0, width:'100%', height:'100%' }} viewBox="0 0 300 140" preserveAspectRatio="none">
            {sortedByDay.map((s, i) => {
              const t = TYPE_TONES[s.type];
              const cx = (s.cycleDay / 30) * 300;
              const amp = s.height * 0.5; // half-amplitude
              const baseY = 70;
              const yPeak = s.signed > 0 ? baseY - amp : baseY + amp;
              const isOpen = open === i;
              // Earthquake-like jagged waveform centered at cx, span 60u wide
              const span = 70;
              const points = [];
              for (let x = -span/2; x <= span/2; x += 4) {
                const xpos = cx + x;
                const norm = x / (span/2);
                const decay = Math.exp(-Math.abs(norm)*1.6);
                const wiggle = Math.sin(x*0.8 + i) * decay * amp;
                const y = baseY + (s.signed > 0 ? -1 : 1) * Math.abs(wiggle);
                points.push(`${xpos},${y}`);
              }
              return (
                <g key={s.id}>
                  <polyline
                    points={points.join(' ')}
                    fill="none" stroke={t.accent}
                    strokeWidth={isOpen ? 2.5 : 1.6}
                    strokeLinecap="round" strokeLinejoin="round"
                    opacity={isOpen ? 1 : 0.7}
                    style={{ transition:'all 220ms' }}
                  />
                  {/* Peak marker */}
                  <circle cx={cx} cy={yPeak} r={isOpen ? 5 : 3.2} fill={t.accent}
                    stroke="#FFFBF2" strokeWidth="1.5"/>
                </g>
              );
            })}
          </svg>

          {/* Tap regions */}
          {sortedByDay.map((s, i) => (
            <button key={s.id} onClick={()=>setOpen(i)} style={{
              position:'absolute', left:`${(s.cycleDay/30)*100 - 12}%`, top:0, bottom:0, width:'24%',
              background:'transparent', border:'none', cursor:'pointer', padding:0,
            }} aria-label={s.title}/>
          ))}
        </div>

        {/* X axis labels */}
        <div style={{ display:'flex', justifyContent:'space-between', marginTop:6, padding:'0 2px',
          fontSize:9, color:'#9AA39D', fontWeight:700, letterSpacing:0.5 }}>
          <span>D1</span><span>D6</span><span>D12</span><span>D18</span><span>D24</span><span>D30</span>
        </div>
      </div>

      {/* Active signal */}
      {open !== null && (() => {
        const s = sortedByDay[open];
        const t = TYPE_TONES[s.type];
        return (
          <div key={open} style={{
            margin:'14px 22px 0', padding:'14px 16px',
            background: t.soft, borderRadius:14, border:`1px solid ${t.edge}`,
            animation:'mf-rise .35s ease both', position:'relative',
          }}>
            <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:8 }}>
              <div style={{
                width:32, height:32, borderRadius:9, background:t.bg, color:t.fg,
                display:'grid', placeItems:'center',
              }}>
                <AsIcon name={s.icon} size={17}/>
              </div>
              <div style={{ flex:1 }}>
                <div style={{ fontSize:10, fontWeight:800, letterSpacing:1.2, color:t.fg }}>
                  {s.headline.toUpperCase()} · DÍA {s.cycleDay}
                </div>
                <div style={{ fontSize:14, fontWeight:800, color:'#0F2A1E', letterSpacing:-0.2, lineHeight:1.25, marginTop:2 }}>
                  {s.title}
                </div>
              </div>
              <span className="sf-display" style={{
                fontSize:18, fontWeight:900, color:t.fg, letterSpacing:-0.4,
                fontVariantNumeric:'tabular-nums', whiteSpace:'nowrap',
              }}>{s.deltaLabel}</span>
            </div>
            <div style={{ fontSize:12, color:'#6F7A73', lineHeight:1.5, marginBottom:10 }}>
              {s.body}
            </div>
            <div style={{ display:'flex', gap:8, alignItems:'center' }}>
              <div style={{
                fontSize:9, fontWeight:700, color:t.fg, padding:'4px 8px',
                background:'rgba(255,255,255,0.6)', borderRadius:999, letterSpacing:0.4,
              }}>● {s.confidenceLabel}</div>
              <button style={{
                marginLeft:'auto', background: t.fg, color:'#fff', border:'none',
                padding:'9px 14px', borderRadius:10, cursor:'pointer',
                fontSize:12, fontWeight:800, fontFamily:'inherit',
                display:'flex', alignItems:'center', gap:6,
              }}>{s.cta} <AsIcon name="arrow-up-right" size={12}/></button>
            </div>
          </div>
        );
      })()}

      {/* Sismic legend / mini list */}
      <div style={{ padding:'14px 22px 18px', marginTop:6 }}>
        <div style={{ fontSize:9, fontWeight:800, letterSpacing:1.6, color:'#9AA39D', marginBottom:8 }}>
          TODOS LOS EVENTOS
        </div>
        <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
          {sortedByDay.map((s, i) => {
            const t = TYPE_TONES[s.type];
            const isOpen = open === i;
            return (
              <button key={s.id} onClick={()=>setOpen(i)} style={{
                display:'flex', alignItems:'center', gap:10,
                background: isOpen ? t.soft : 'transparent',
                border: `1px solid ${isOpen ? t.edge : 'transparent'}`,
                borderRadius:10, padding:'8px 10px', cursor:'pointer',
                fontFamily:'inherit', textAlign:'left', width:'100%',
                transition:'background 180ms',
              }}>
                <div style={{ width:6, height:6, borderRadius:'50%', background:t.accent, flexShrink:0,
                  boxShadow: s.urgency==='alta' ? `0 0 0 3px ${t.accent}33` : 'none' }}/>
                <span style={{ fontSize:11, fontWeight:700, color:'#9AA39D', fontVariantNumeric:'tabular-nums', minWidth:30 }}>
                  D{s.cycleDay}
                </span>
                <span style={{ flex:1, fontSize:12, fontWeight:700, color:'#0F2A1E', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>
                  {s.headline}
                </span>
                <span style={{ fontSize:11, fontWeight:800, color:t.fg, fontVariantNumeric:'tabular-nums', whiteSpace:'nowrap' }}>
                  {s.deltaLabel}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// V4 — DIÁLOGO CONVERSACIONAL
// El asistente "habla" en burbujas. Cada signal es un mensaje
// con personalidad (tono según urgencia). El usuario "responde"
// con quick-reply chips. Sensación de chat con un amigo experto.
// ═════════════════════════════════════════════════════════════
function AsesorDialogo() {
  const [seenIds, setSeenIds] = useStateAs([]);
  const visible = SIGNALS.filter(s => !seenIds.includes(s.id));

  return (
    <div style={{
      background:'linear-gradient(180deg, #F0F4ED 0%, #E2EAE2 100%)',
      borderRadius:28, border:'1px solid #D7E3D8', overflow:'hidden',
    }}>
      {/* Header — assistant identity */}
      <div style={{ padding:'16px 20px 14px', borderBottom:'1px solid rgba(15,42,30,0.08)',
        background:'rgba(255,255,255,0.5)', backdropFilter:'blur(8px)',
        display:'flex', alignItems:'center', gap:12,
      }}>
        <div style={{ position:'relative' }}>
          <div style={{
            width:42, height:42, borderRadius:'50%',
            background:'linear-gradient(135deg, #2E9A5F, #1C7E3A)',
            display:'grid', placeItems:'center',
            boxShadow:'0 4px 14px rgba(28,126,58,0.25)',
          }}>
            <AsIcon name="spark" size={20} color="#FFFBF2"/>
          </div>
          <span style={{
            position:'absolute', bottom:0, right:0, width:11, height:11,
            background:'#2E9A5F', border:'2px solid #FFFBF2', borderRadius:'50%',
            animation:'mf-pulse-ring 2.4s ease-out infinite',
          }}/>
        </div>
        <div style={{ flex:1 }}>
          <div style={{ fontSize:14, fontWeight:800, color:'#0F2A1E', letterSpacing:-0.2 }}>
            Asistente
          </div>
          <div style={{ fontSize:11, color:'#1C7E3A', fontWeight:600, display:'flex', alignItems:'center', gap:5 }}>
            <span style={{ width:5, height:5, borderRadius:'50%', background:'#2E9A5F' }}/>
            Mirando tus números · {visible.length} cosas para vos
          </div>
        </div>
        <div style={{
          padding:'5px 10px', borderRadius:999,
          background:'#0F2A1E', color:'#C7EE9C', fontSize:10, fontWeight:800, letterSpacing:0.5,
          fontVariantNumeric:'tabular-nums',
        }}>+{fmtARS(TOTAL_IMPACT)}</div>
      </div>

      {/* Conversation */}
      <div style={{ padding:'16px 16px 4px', display:'flex', flexDirection:'column', gap:12 }}>
        {visible.map((s, idx) => {
          const t = TYPE_TONES[s.type];
          const isCritical = s.urgency === 'alta';
          // Greeting/lead-in micro-copy variations
          const intro = {
            'recovery-hard': '⚠️ Una urgente:',
            'zombie-disney': 'Encontré algo raro:',
            'positive-forecast': '✨ Buena noticia:',
            'cat-accel-restos': 'Mirá esto:',
            'streak-ok': '¡Ey!',
          }[s.id];
          return (
            <div key={s.id} style={{
              animation:`mf-rise .5s ${idx*0.08}s ease both`,
              display:'flex', flexDirection:'column', gap:6,
            }}>
              {/* Intro tag */}
              <div style={{ fontSize:11, color:'#6F7A73', fontWeight:700,
                display:'flex', alignItems:'center', gap:6, paddingLeft:6 }}>
                <span>{intro}</span>
              </div>

              {/* Bubble */}
              <div style={{
                background:'#FFFBF2',
                border:`1.5px solid ${isCritical ? t.accent : 'rgba(15,42,30,0.08)'}`,
                borderRadius:'18px 18px 18px 4px',
                padding:'14px 16px',
                position:'relative',
                boxShadow:'0 2px 10px rgba(15,42,30,0.04)',
              }}>
                {/* Label */}
                <div style={{ display:'flex', alignItems:'center', gap:6, marginBottom:6 }}>
                  <div style={{ width:22, height:22, borderRadius:6, background:t.bg, color:t.fg,
                    display:'grid', placeItems:'center', flexShrink:0 }}>
                    <AsIcon name={s.icon} size={12}/>
                  </div>
                  <span style={{ fontSize:10, fontWeight:800, letterSpacing:1.2, color:t.fg }}>
                    {s.headline.toUpperCase()}
                  </span>
                </div>

                {/* Title — prominente */}
                <div style={{ fontSize:15, fontWeight:800, color:'#0F2A1E',
                  letterSpacing:-0.2, lineHeight:1.3 }}>
                  {s.title}
                </div>

                {/* Body */}
                <div style={{ fontSize:12.5, color:'#3E5A4A', marginTop:6, lineHeight:1.5 }}>
                  {s.body}
                </div>

                {/* Big impact number */}
                <div style={{ marginTop:10, padding:'8px 10px', borderRadius:10,
                  background:t.soft, display:'flex', alignItems:'center', justifyContent:'space-between' }}>
                  <span style={{ fontSize:10, fontWeight:700, color:t.fg, letterSpacing:0.6, textTransform:'uppercase' }}>
                    {s.impactLabel}
                  </span>
                  <span className="sf-display" style={{
                    fontSize:18, fontWeight:900, color:t.fg, letterSpacing:-0.4,
                    fontVariantNumeric:'tabular-nums',
                  }}>{s.deltaLabel}</span>
                </div>

                {/* Confidence pill */}
                <div style={{ display:'flex', alignItems:'center', gap:5, marginTop:8 }}>
                  <span style={{ fontSize:9, color:'#9AA39D', fontWeight:700, letterSpacing:0.4 }}>
                    {s.tier === 'solid' ? '●●●' : s.tier === 'building' ? '●●○' : '●○○'} {s.confidenceLabel}
                  </span>
                </div>
              </div>

              {/* Quick replies (user-side bubbles) */}
              <div style={{ display:'flex', gap:6, justifyContent:'flex-end', marginTop:2,
                flexWrap:'wrap', paddingRight:6 }}>
                <button style={{
                  background: `linear-gradient(135deg, ${t.accent}, ${t.fg})`,
                  color: s.type === 'warning' ? '#0F2A1E' : '#fff', border:'none',
                  padding:'9px 14px', borderRadius:'14px 14px 4px 14px',
                  cursor:'pointer', fontSize:12, fontWeight:800, fontFamily:'inherit',
                  display:'flex', alignItems:'center', gap:5,
                  boxShadow:`0 3px 10px ${t.accent}40`,
                }}>
                  {s.cta} <AsIcon name="arrow-up-right" size={11}/>
                </button>
                <button onClick={()=>setSeenIds([...seenIds, s.id])} style={{
                  background:'rgba(255,251,242,0.8)', color:'#6F7A73',
                  border:'1px solid rgba(15,42,30,0.1)',
                  padding:'9px 13px', borderRadius:'14px 14px 4px 14px',
                  cursor:'pointer', fontSize:12, fontWeight:700, fontFamily:'inherit',
                }}>Visto</button>
              </div>
            </div>
          );
        })}

        {visible.length === 0 && (
          <div style={{ padding:'30px 14px 20px', textAlign:'center' }}>
            <div style={{
              width:56, height:56, borderRadius:'50%', margin:'0 auto 10px',
              background:'linear-gradient(135deg, #2E9A5F, #1C7E3A)',
              display:'grid', placeItems:'center', color:'#fff',
            }}>
              <AsIcon name="check" size={28}/>
            </div>
            <div style={{ fontSize:14, fontWeight:800, color:'#0F2A1E' }}>
              Todo revisado
            </div>
            <div style={{ fontSize:12, color:'#6F7A73', marginTop:4 }}>
              Vuelvo cuando vea algo nuevo
            </div>
            <button onClick={()=>setSeenIds([])} style={{
              marginTop:12, background:'transparent', border:'1px solid #D7E3D8',
              color:'#1C7E3A', padding:'7px 12px', borderRadius:999,
              cursor:'pointer', fontSize:11, fontWeight:700, fontFamily:'inherit',
            }}>Ver de nuevo</button>
          </div>
        )}
      </div>

      {/* Typing indicator (next batch) */}
      {visible.length > 0 && (
        <div style={{ padding:'4px 20px 16px', display:'flex', alignItems:'center', gap:8, opacity:0.6 }}>
          <div style={{
            width:24, height:24, borderRadius:'50%',
            background:'linear-gradient(135deg, #2E9A5F, #1C7E3A)',
            display:'grid', placeItems:'center',
          }}>
            <AsIcon name="spark" size={11} color="#FFFBF2"/>
          </div>
          <div style={{ display:'flex', gap:3, padding:'8px 12px',
            background:'rgba(255,251,242,0.7)', borderRadius:'14px 14px 14px 4px',
            border:'1px solid rgba(15,42,30,0.06)' }}>
            {[0,1,2].map(i => (
              <span key={i} style={{
                width:5, height:5, borderRadius:'50%', background:'#9AA39D',
                animation:`mf-typing 1.4s ${i*0.2}s ease-in-out infinite`,
              }}/>
            ))}
          </div>
          <span style={{ fontSize:10, color:'#9AA39D', fontWeight:600 }}>
            Aprendiendo de tu ritmo…
          </span>
        </div>
      )}
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// V5 — RADAR DE OPORTUNIDADES (tipo dial circular)
// Insights organizados en un radar circular. Ángulo = tipo
// (critical→positive). Radio = confianza. Cada dot tiene un
// halo de impacto. El centro muestra el activo seleccionado.
// ═════════════════════════════════════════════════════════════
function AsesorRadar() {
  const [active, setActive] = useStateAs(0);
  const sig = SIGNALS[active];
  const tone = TYPE_TONES[sig.type];

  // Posiciones radiales: ángulo por urgencia, radio por confianza
  const points = SIGNALS.map((s, i) => {
    // Distribute angles to avoid overlap; group by type
    const angles = { 'recovery-hard': -110, 'zombie-disney': -55, 'cat-accel-restos': 35, 'positive-forecast': 95, 'streak-ok': 155 };
    const angle = angles[s.id];
    const radius = 70 + s.confidence * 50; // 70-120
    const rad = (angle * Math.PI) / 180;
    return {
      ...s,
      angle, radius,
      x: 150 + Math.cos(rad) * radius,
      y: 150 + Math.sin(rad) * radius,
    };
  });

  return (
    <div style={{
      background:'#0F2A1E', borderRadius:28, overflow:'hidden', position:'relative',
      border:'1px solid #1F332A',
    }}>
      {/* Top bar */}
      <div style={{
        padding:'18px 22px 0', display:'flex', alignItems:'center', justifyContent:'space-between',
      }}>
        <div style={{ display:'flex', alignItems:'center', gap:10 }}>
          <div style={{
            width:30, height:30, borderRadius:9,
            background:'linear-gradient(135deg, #C7EE9C, #2E9A5F)',
            display:'grid', placeItems:'center',
          }}>
            <AsIcon name="spark" size={15} color="#0F2A1E"/>
          </div>
          <div>
            <div style={{ fontSize:10, fontWeight:800, letterSpacing:1.6, color:'#C7EE9C' }}>RADAR</div>
            <div style={{ fontSize:11, color:'rgba(246,251,239,0.55)', marginTop:1 }}>Oportunidades del ciclo</div>
          </div>
        </div>
        <div style={{
          padding:'4px 10px', borderRadius:999, background:'rgba(199,238,156,0.12)',
          fontSize:10, fontWeight:800, color:'#C7EE9C', letterSpacing:0.4,
        }}>+{fmtARS(TOTAL_IMPACT)}</div>
      </div>

      {/* Radar */}
      <div style={{ position:'relative', width:300, height:300, margin:'12px auto 0' }}>
        <svg width="300" height="300" viewBox="0 0 300 300">
          <defs>
            <radialGradient id="radarGlow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="rgba(199,238,156,0.18)"/>
              <stop offset="60%" stopColor="rgba(46,154,95,0.08)"/>
              <stop offset="100%" stopColor="rgba(46,154,95,0)"/>
            </radialGradient>
            <linearGradient id="sweep" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="rgba(199,238,156,0)"/>
              <stop offset="100%" stopColor="rgba(199,238,156,0.35)"/>
            </linearGradient>
          </defs>

          {/* Background glow */}
          <circle cx="150" cy="150" r="135" fill="url(#radarGlow)"/>

          {/* Concentric rings */}
          {[40, 75, 110, 135].map((r,i) => (
            <circle key={i} cx="150" cy="150" r={r} fill="none"
              stroke="rgba(199,238,156,0.12)" strokeWidth="1"
              strokeDasharray={i % 2 ? '3 4' : 'none'}/>
          ))}

          {/* Cross axes */}
          <line x1="150" y1="20" x2="150" y2="280" stroke="rgba(199,238,156,0.1)" strokeWidth="1"/>
          <line x1="20" y1="150" x2="280" y2="150" stroke="rgba(199,238,156,0.1)" strokeWidth="1"/>

          {/* Sweep arm rotating */}
          <g style={{ transformOrigin:'150px 150px', animation:'mf-radar-sweep 6s linear infinite' }}>
            <path d="M150 150 L150 20 A130 130 0 0 1 245 60 Z" fill="url(#sweep)" opacity="0.6"/>
          </g>

          {/* Quadrant labels */}
          <text x="150" y="14" textAnchor="middle" fill="rgba(199,238,156,0.5)" fontSize="8" fontWeight="800" letterSpacing="2">CRÍTICO</text>
          <text x="290" y="154" textAnchor="end" fill="rgba(199,238,156,0.5)" fontSize="8" fontWeight="800" letterSpacing="2">AVISO</text>
          <text x="150" y="294" textAnchor="middle" fill="rgba(199,238,156,0.5)" fontSize="8" fontWeight="800" letterSpacing="2">A FAVOR</text>
          <text x="10" y="154" textAnchor="start" fill="rgba(199,238,156,0.5)" fontSize="8" fontWeight="800" letterSpacing="2">NOTA</text>

          {/* Confidence labels at radii */}
          <text x="155" y="80" fill="rgba(199,238,156,0.3)" fontSize="7" fontWeight="700">75%</text>
          <text x="155" y="45" fill="rgba(199,238,156,0.3)" fontSize="7" fontWeight="700">100%</text>

          {/* Connection lines from center to points */}
          {points.map((p,i) => {
            const t = TYPE_TONES[p.type];
            const isActive = i === active;
            return (
              <line key={p.id+'-line'}
                x1="150" y1="150" x2={p.x} y2={p.y}
                stroke={t.accent} strokeWidth={isActive ? 1.5 : 0.6}
                opacity={isActive ? 0.8 : 0.25}
                strokeDasharray={isActive ? 'none' : '2 3'}
              />
            );
          })}

          {/* Points */}
          {points.map((p, i) => {
            const t = TYPE_TONES[p.type];
            const isActive = i === active;
            const r = 6 + (p.impact > 100000 ? 8 : p.impact > 10000 ? 4 : 0);
            return (
              <g key={p.id} style={{ cursor:'pointer' }} onClick={()=>setActive(i)}>
                {/* Halo */}
                <circle cx={p.x} cy={p.y} r={r * 2.5} fill={t.accent}
                  opacity={isActive ? 0.18 : 0.08}/>
                {p.urgency === 'alta' && (
                  <circle cx={p.x} cy={p.y} r={r + 4} fill="none" stroke={t.accent} strokeWidth="1"
                    opacity="0.5" style={{ animation:'mf-pulse-ring 2s ease-out infinite' }}/>
                )}
                <circle cx={p.x} cy={p.y} r={r} fill={t.accent}
                  stroke={isActive ? '#F6FBEF' : 'rgba(15,42,30,0.4)'} strokeWidth={isActive ? 2 : 1}/>
              </g>
            );
          })}

          {/* Center label — total */}
          <circle cx="150" cy="150" r="32" fill="#0F2A1E" stroke="rgba(199,238,156,0.25)" strokeWidth="1"/>
          <text x="150" y="146" textAnchor="middle" fill="rgba(199,238,156,0.5)" fontSize="7" fontWeight="800" letterSpacing="1.5">CICLO</text>
          <text x="150" y="160" textAnchor="middle" fill="#C7EE9C" fontSize="13" fontWeight="900" fontFamily="-apple-system, sans-serif" letterSpacing="-0.3">
            {fmtARS(TOTAL_IMPACT)}
          </text>
        </svg>
      </div>

      {/* Active card below radar */}
      <div key={active} style={{
        margin:'4px 18px 18px', padding:'14px 16px',
        background:`linear-gradient(135deg, ${tone.fg}22, transparent)`,
        border:`1px solid ${tone.accent}40`,
        borderRadius:18, animation:'mf-rise .4s ease both',
      }}>
        <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:8 }}>
          <div style={{ width:32, height:32, borderRadius:10, background:tone.accent, color:'#0F2A1E',
            display:'grid', placeItems:'center' }}>
            <AsIcon name={sig.icon} size={17}/>
          </div>
          <div style={{ flex:1, minWidth:0 }}>
            <div style={{ fontSize:9, fontWeight:800, letterSpacing:1.5, color:tone.accent }}>
              {sig.headline.toUpperCase()}
            </div>
            <div style={{ fontSize:14, fontWeight:800, color:'#F6FBEF', letterSpacing:-0.2,
              lineHeight:1.25, marginTop:2,
              overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
              {sig.title}
            </div>
          </div>
        </div>
        <div style={{ fontSize:12, color:'rgba(246,251,239,0.65)', lineHeight:1.5, marginBottom:10 }}>
          {sig.body}
        </div>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', gap:10 }}>
          <span className="sf-display" style={{
            fontSize:18, fontWeight:900, color:tone.accent, letterSpacing:-0.5,
            fontVariantNumeric:'tabular-nums',
          }}>{sig.deltaLabel}</span>
          <button style={{
            background:tone.accent, color:'#0F2A1E', border:'none',
            padding:'9px 14px', borderRadius:10, cursor:'pointer',
            fontSize:12, fontWeight:800, fontFamily:'inherit',
            display:'flex', alignItems:'center', gap:6,
          }}>
            {sig.cta} <AsIcon name="arrow-up-right" size={12}/>
          </button>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// SHELL — Wraps each variant in a phone-ish container
// ─────────────────────────────────────────────────────────────
function AsesorScreen({ variant }) {
  const bg = variant === 'constelacion' || variant === 'radar' ? '#040A07' : '#EFF5E8';
  return (
    <div className="screen" style={{ background: bg, overflowY:'auto', padding:'18px 16px 60px' }}>
      <StatusBar color={(variant==='constelacion' || variant==='radar') ? '#F6FBEF' : '#0F2A1E'}/>
      <div style={{ height:6 }}/>
      {/* Page header */}
      <div style={{ padding:'4px 6px 14px' }}>
        <div className="sf-display" style={{
          fontSize:30, fontWeight:800, letterSpacing:-1.2, lineHeight:1,
          color: (variant==='constelacion' || variant==='radar') ? '#F6FBEF' : '#0F2A1E',
        }}>
          Tu Asistente
        </div>
        <div style={{ fontSize:13, fontWeight:500, marginTop:6,
          color: (variant==='constelacion' || variant==='radar') ? 'rgba(246,251,239,0.55)' : '#6F7A73' }}>
          Mira tus datos y te dice qué hacer.
        </div>
      </div>
      {variant === 'constelacion' && <AsesorConstelacion/>}
      {variant === 'periodico' && <AsesorPeriodico/>}
      {variant === 'sismografo' && <AsesorSismografo/>}
      {variant === 'dialogo' && <AsesorDialogo/>}
      {variant === 'radar' && <AsesorRadar/>}
    </div>
  );
}

Object.assign(window, { AsesorScreen });
