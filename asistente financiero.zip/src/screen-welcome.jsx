// ─────────────────────────────────────────────────────────────
// Manifiesto · Welcome screen
// Hero: helecho que crece + wordmark + 2 CTAs.
// Fondo: verde profundo con halo orgánico durazno.
// ─────────────────────────────────────────────────────────────

function WelcomeScreen({ onLogin, onCreate }) {
  return (
    <div style={{
      width: '100%',
      height: '100%',
      background: '#0E3A26',
      color: '#FFFBF2',
      position: 'relative',
      overflow: 'hidden',
      fontFamily: '-apple-system, "SF Pro Display", system-ui, sans-serif',
      display: 'flex',
      flexDirection: 'column',
    }}>

      {/* Aurora orgánica — manchas blur que respiran */}
      <div style={{
        position: 'absolute',
        top: '-10%',
        left: '-15%',
        width: '280px',
        height: '280px',
        borderRadius: '50%',
        background: 'radial-gradient(circle, rgba(199,238,156,0.18), transparent 70%)',
        filter: 'blur(40px)',
        animation: 'aurora-1 14s ease-in-out infinite',
      }} />
      <div style={{
        position: 'absolute',
        bottom: '20%',
        right: '-20%',
        width: '300px',
        height: '300px',
        borderRadius: '50%',
        background: 'radial-gradient(circle, rgba(242,181,138,0.16), transparent 70%)',
        filter: 'blur(50px)',
        animation: 'aurora-2 18s ease-in-out infinite',
      }} />

      {/* Partículas / esporas */}
      {[...Array(8)].map((_, i) => (
        <div
          key={i}
          style={{
            position: 'absolute',
            width: '3px',
            height: '3px',
            borderRadius: '50%',
            background: i % 3 === 0 ? '#F2B58A' : '#C7EE9C',
            opacity: 0.4,
            left: `${(i * 13 + 8) % 90}%`,
            top: `${(i * 19 + 15) % 80}%`,
            animation: `spore-float ${10 + (i % 4) * 2}s ease-in-out ${i * 0.7}s infinite`,
          }}
        />
      ))}

      {/* HERO — Logo enorme centrado */}
      <div style={{
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'flex-end',
        paddingBottom: '40px',
        position: 'relative',
        zIndex: 2,
      }}>
        <Fern size={180} palette="light" animate={true} delay={300} />

        {/* Wordmark */}
        <div style={{
          marginTop: '40px',
          fontSize: '46px',
          fontWeight: 800,
          letterSpacing: '-2px',
          color: '#FFFBF2',
          animation: 'fade-in-up 0.9s cubic-bezier(.2,.8,.2,1) 1100ms both',
        }}>
          Manifiesto<span style={{ color: '#F2B58A' }}>.</span>
        </div>

        {/* Sub micro — opcional, sin tagline marketing */}
        <div style={{
          marginTop: '14px',
          fontSize: '15px',
          color: 'rgba(255, 251, 242, 0.55)',
          fontWeight: 400,
          letterSpacing: '-0.2px',
          animation: 'fade-in-up 0.9s cubic-bezier(.2,.8,.2,1) 1300ms both',
        }}>
          Finanzas para tu familia
        </div>
      </div>

      {/* CTAs */}
      <div style={{
        padding: '0 28px 50px',
        position: 'relative',
        zIndex: 2,
        animation: 'fade-in-up 0.9s cubic-bezier(.2,.8,.2,1) 1500ms both',
      }}>
        <button
          onClick={onCreate}
          style={{
            width: '100%',
            height: '56px',
            borderRadius: '18px',
            background: '#FFFBF2',
            color: '#0E3A26',
            fontSize: '16px',
            fontWeight: 700,
            letterSpacing: '-0.3px',
            border: 'none',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '8px',
            boxShadow: '0 12px 30px -10px rgba(0,0,0,0.4)',
            transition: 'transform .15s ease',
          }}
          onMouseDown={e => e.currentTarget.style.transform = 'scale(0.98)'}
          onMouseUp={e => e.currentTarget.style.transform = 'scale(1)'}
          onMouseLeave={e => e.currentTarget.style.transform = 'scale(1)'}
        >
          Empezar
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
            <path d="M5 3l5 5-5 5" stroke="#0E3A26" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </button>

        <button
          onClick={onLogin}
          style={{
            width: '100%',
            height: '52px',
            marginTop: '12px',
            borderRadius: '18px',
            background: 'transparent',
            color: '#FFFBF2',
            fontSize: '15px',
            fontWeight: 500,
            letterSpacing: '-0.2px',
            border: '1px solid rgba(255,251,242,0.18)',
            cursor: 'pointer',
          }}
        >
          Ya tengo cuenta
        </button>

        {/* Footer micro */}
        <div style={{
          marginTop: '22px',
          fontSize: '11px',
          color: 'rgba(255,251,242,0.38)',
          textAlign: 'center',
          fontWeight: 400,
        }}>
          Al continuar aceptás los <u>Términos</u> y la <u>Privacidad</u>
        </div>
      </div>

      <style>{`
        @keyframes aurora-1 {
          0%, 100% { transform: translate(0,0) scale(1); }
          50%      { transform: translate(20px, 30px) scale(1.15); }
        }
        @keyframes aurora-2 {
          0%, 100% { transform: translate(0,0) scale(1); }
          50%      { transform: translate(-25px, -20px) scale(1.1); }
        }
        @keyframes spore-float {
          0%, 100% { transform: translateY(0) translateX(0); opacity: 0.3; }
          50%      { transform: translateY(-30px) translateX(10px); opacity: 0.7; }
        }
        @keyframes fade-in-up {
          from { opacity: 0; transform: translateY(12px); }
          to   { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
}

window.WelcomeScreen = WelcomeScreen;
