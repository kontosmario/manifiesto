// ─────────────────────────────────────────────────────────────
// Manifiesto · Helecho refinado
// ─────────────────────────────────────────────────────────────
// Logo "fronda joven" — espiral natural con frondas crecientes.
// Diseñado a viewBox 100x100 para escalar perfecto a cualquier tamaño.
//
// Props:
//   size       — px (default 96)
//   palette    — 'dark' | 'light' | 'mono-light' | 'mono-dark'
//   animate    — bool, true = unfurl + sway sutil
//   delay      — ms para el unfurl (en cascada)
// ─────────────────────────────────────────────────────────────

const FERN_PALETTES = {
  dark:   { stem: '#1F7A4B', leafA: '#0E3A26', leafB: '#1F7A4B', tip: '#E08E63', tipDot: '#E08E63' }, // sobre claro
  light:  { stem: '#8DD66A', leafA: '#C7EE9C', leafB: '#8DD66A', tip: '#F2B58A', tipDot: '#F2B58A' }, // sobre oscuro
  'mono-light': { stem: '#FFFBF2', leafA: '#FFFBF2', leafB: '#FFFBF2', tip: '#FFFBF2', tipDot: '#FFFBF2' },
  'mono-dark':  { stem: '#0E3A26', leafA: '#0E3A26', leafB: '#0E3A26', tip: '#0E3A26', tipDot: '#0E3A26' },
};

function Fern({ size = 96, palette = 'dark', animate = true, delay = 0 }) {
  const c = FERN_PALETTES[palette] || FERN_PALETTES.dark;
  const id = React.useId();

  // Frondas — cada una con offset de animación para "desenrollar" en cascada
  const leaves = [
    // [cx, cy, rx, ry, rotate, color, animDelay]
    [-22, 38, 11, 5.5, -34, c.leafA, 0],     // base izq grande
    [ 16, 30, 10, 5,   30,  c.leafA, 60],    // base der
    [-14, 14,  9, 4.5, -22, c.leafB, 120],   // medio izq
    [ 10,  6,  8, 4,   18,  c.leafB, 180],   // medio der
    [ -6, -8,  7, 3.5, -10, c.leafB, 240],   // sup izq
    [  4,-22,  6, 3,    8,  c.leafB, 300],   // sup der
    [ -4,-36,  5, 2.5, -4,  c.leafB, 360],   // tope
  ];

  return (
    <svg
      width={size}
      height={size}
      viewBox="-50 -54 100 110"
      style={{
        overflow: 'visible',
        animation: animate ? `fern-rise 1s cubic-bezier(.2,.8,.2,1) ${delay}ms both` : 'none',
        transformOrigin: '0 50px',
      }}
    >
      <defs>
        <filter id={`soft-${id}`} x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur stdDeviation="0.3" />
        </filter>
      </defs>

      {/* Tallo principal — curva natural que termina en la espiral */}
      <g style={{
        animation: animate ? `fern-sway 7s ease-in-out ${delay + 800}ms infinite` : 'none',
        transformOrigin: '0 50px',
      }}>
        <path
          d="M0 50
             C -4 30, -6 12, -3 -6
             C 0 -22, 4 -34, -8 -42"
          fill="none"
          stroke={c.stem}
          strokeWidth="3.2"
          strokeLinecap="round"
          style={{
            strokeDasharray: animate ? '120' : 'none',
            strokeDashoffset: 0,
            animation: animate ? `fern-stem-draw 1.2s ease ${delay + 100}ms both` : 'none',
          }}
        />

        {/* Frondas */}
        {leaves.map(([cx, cy, rx, ry, rot, fill, leafDelay], i) => (
          <ellipse
            key={i}
            cx={cx}
            cy={cy}
            rx={rx}
            ry={ry}
            transform={`rotate(${rot} ${cx} ${cy})`}
            fill={fill}
            style={{
              transformOrigin: `${cx}px ${cy}px`,
              animation: animate
                ? `fern-leaf 0.7s cubic-bezier(.2,.9,.3,1.2) ${delay + 600 + leafDelay}ms both`
                : 'none',
            }}
          />
        ))}

        {/* Espiral en el tope — cabeza del helecho con punto durazno */}
        <g style={{
          animation: animate ? `fern-curl 1.4s cubic-bezier(.2,.8,.2,1) ${delay + 400}ms both` : 'none',
          transformOrigin: '-8px -42px',
        }}>
          <path
            d="M-8 -42
               C -20 -42, -22 -32, -16 -28
               C -10 -25, -6 -30, -8 -34
               C -10 -36, -13 -34, -13 -32"
            fill="none"
            stroke={c.tip}
            strokeWidth="3"
            strokeLinecap="round"
          />
          <circle
            cx="-13"
            cy="-32"
            r="2.2"
            fill={c.tipDot}
            style={{
              animation: animate ? `fern-pulse 2.8s ease-in-out ${delay + 1600}ms infinite` : 'none',
              transformOrigin: '-13px -32px',
            }}
          />
        </g>
      </g>
    </svg>
  );
}

// CSS injectado una sola vez
if (typeof document !== 'undefined' && !document.getElementById('fern-css')) {
  const s = document.createElement('style');
  s.id = 'fern-css';
  s.textContent = `
    @keyframes fern-rise {
      from { opacity: 0; transform: translateY(8px) scale(0.96); }
      to   { opacity: 1; transform: translateY(0) scale(1); }
    }
    @keyframes fern-sway {
      0%, 100% { transform: rotate(-1.5deg); }
      50%      { transform: rotate(1.5deg); }
    }
    @keyframes fern-stem-draw {
      from { stroke-dashoffset: 120; }
      to   { stroke-dashoffset: 0; }
    }
    @keyframes fern-leaf {
      from { opacity: 0; transform: scale(0.2); }
      to   { opacity: 1; transform: scale(1); }
    }
    @keyframes fern-curl {
      from { opacity: 0; transform: rotate(-180deg) scale(0.4); }
      to   { opacity: 1; transform: rotate(0) scale(1); }
    }
    @keyframes fern-pulse {
      0%, 100% { transform: scale(1); }
      50%      { transform: scale(1.4); }
    }
  `;
  document.head.appendChild(s);
}

window.Fern = Fern;
