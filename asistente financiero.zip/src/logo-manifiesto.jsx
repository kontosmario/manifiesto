// Manifiesto · logo final v2
// Adaptación FIEL del SVG de hojas duales — preservando la silueta original completa.
//
// El SVG tiene 3 elementos:
//   1. Hoja grande (derecha) — fill verde
//   2. Hoja chica (izquierda) — fill verde
//   3. Path negro complejo: maceta/bowl con tallo central + ramas que sostienen las hojas,
//      + un detalle pequeño en el medio (la "lengua"/hoja interior pequeña)
//   4. Línea horizontal pequeña debajo (raíz/base)

function LogoManifiesto({
  size = 200,
  palette = 'dark', // 'dark' | 'light' | 'mono-dark' | 'mono-light' | 'duotone'
  animate = false,
  delay = 0,
  iconMode = false
}) {
  const palettes = {
    // Sobre fondos claros
    'dark': {
      leafA: '#1F7A4B', // hoja grande (derecha) — verde vivo (era #4FC497 en el SVG, lo apago a verde Manifiesto)
      leafB: '#1F7A4B', // hoja chica (izquierda) — mismo verde
      structure: '#0E3A26', // todo el path negro → verde profundo Manifiesto
      accent: '#E08E63' // pequeño detalle durazno opcional (sustituye a un detalle del path)
    },
    // Sobre fondos oscuros
    'light': {
      leafA: '#9FD97A',
      leafB: '#9FD97A',
      structure: '#FFFBF2',
      accent: '#F2B58A'
    },
    'mono-dark': {
      leafA: '#0E3A26', leafB: '#0E3A26', structure: '#0E3A26', accent: '#0E3A26'
    },
    'mono-light': {
      leafA: '#FFFBF2', leafB: '#FFFBF2', structure: '#FFFBF2', accent: '#FFFBF2'
    },
    // Hojas con verde Manifiesto, una hoja en durazno
    'duotone': {
      leafA: '#0E3A26', leafB: '#E08E63', structure: '#0E3A26', accent: '#0E3A26'
    }
  };
  const c = palettes[palette];
  // ViewBox — ampliamos abajo y derecha para que la espiral grande entre
  const vb = iconMode ? '0 95 502 320' : '-15 80 532 350';

  return (
    <div style={{ width: size, display: 'inline-block', lineHeight: 0 }}>
      <svg viewBox={vb} width="100%" xmlns="http://www.w3.org/2000/svg" style={{ width: "360px" }}>

        {/* HOJA GRANDE — derecha (path original del SVG, sin tocar) */}
        <path
          d="M337.1,254.779c-34.545,5.548-67.046-17.959-72.594-52.504
             s17.959-67.046,52.504-72.594
             C417.26,113.581,492,261.545,492,261.545
             S413.358,242.533,337.1,254.779z"












          fill={c.leafA}
          style={{
            transformOrigin: '380px 200px',
            animation: animate ?
            `manif-grow-r 1.4s cubic-bezier(.2,.85,.2,1) ${delay}ms both` :
            'none'
          }} />
        

        {/* HOJA CHICA — izquierda (path original del SVG, sin tocar) */}
        <path
          d="M111.366,249.668c22.606,3.63,43.875-11.752,47.505-34.358
             s-11.752-43.875-34.358-47.505
             C58.91,157.269,10,254.096,10,254.096
             S61.463,241.654,111.366,249.668z"












          fill={c.leafB}
          style={{
            transformOrigin: '90px 210px',
            animation: animate ?
            `manif-grow-l 1.2s cubic-bezier(.2,.85,.2,1) ${delay + 200}ms both` :
            'none'
          }} />
        

        {/* ESTRUCTURA NEGRA ORIGINAL — el "macetero/bowl" con las dos ramas
                que sostienen las hojas, PERO sin el tallo central vertical (lo
                removimos para reemplazarlo por nuestro trazo continuo + espiral). */}
        <path
          d="M500.926,257.036c-0.787-1.559-19.642-38.57-51.366-74.119
             c-18.881-21.157-38.428-37.369-58.096-48.187
             c-25.338-13.936-50.919-18.958-76.04-14.923
             c-19.345,3.106-36.321,13.561-47.804,29.437
             c-7.96,11.006-12.612,23.705-13.685,36.905
             c-14.89,4.115-27.968,9.962-38.457,17.275
             c-6.814,4.751-12.31,10.029-16.389,15.628
             c-7.313-7.048-17.71-12.946-30.119-16.851
             c-2.833-22.038-19.845-40.571-42.872-44.27
             C54.103,146.367,3.206,245.368,1.074,249.587
             c-1.758,3.479-1.333,7.664,1.088,10.72
             c1.923,2.426,4.826,3.789,7.838,3.789
             c0.781,0,1.569-0.092,2.35-0.28
             c0.496-0.119,50.059-11.879,97.431-4.274
             c13.573,2.182,27.178-1.056,38.314-9.11
             c9.486-6.861,16.199-16.524,19.331-27.622
             c15.11,5.769,23.256,14.539,23.256,20.116
             c0.06,4.5,3.7,8.1,8.2,8.1
             l13.6,0
             c4.5,0,8.1-3.6,8.1-8.1
             c0-12.153,15.442-27.405,44.459-36.331
             c3.621,18.201,13.808,34.125,28.926,45.06
             c15.874,11.481,35.271,16.099,54.617,12.987
             c73.286-11.767,150.2,6.43,150.965,6.612
             c0.78,0.188,1.568,0.28,2.35,0.28
             c3.012,0,5.915-1.363,7.837-3.789
             C502.259,264.7,502.684,260.517,500.926,257.036z
             M136.374,234.225c-6.809,4.925-15.124,6.898-23.422,5.57
             c-31.319-5.031-62.832-2.406-83.126,0.52
             c15.812-24.062,47.327-63.308,84.686-63.308
             c2.772,0,5.583,0.217,8.415,0.671
             c11.54,1.854,20.607,9.805,24.457,20.032
             c-11.101-1.384-22.205-1.709-33.09-0.938
             c-5.509,0.39-9.659,5.172-9.269,10.681
             c0.39,5.51,5.168,9.684,10.681,9.269
             c10.601-0.749,21.456-0.317,32.302,1.254
             C146.019,224.494,141.991,230.162,136.374,234.225z
             M335.514,244.906c-14.064,2.259-28.178-1.096-39.725-9.447
             c-11.182-8.087-18.651-19.929-21.165-33.448
             c0.667-0.115,1.324-0.236,2.001-0.344
             c24.446-3.926,48.841-4.08,72.503-0.46
             c5.45,0.836,10.562-2.912,11.397-8.372
             s-2.913-10.563-8.372-11.397
             c-25.307-3.874-51.347-3.77-77.421,0.29
             c1.482-7.401,4.538-14.464,9.094-20.763
             c8.351-11.548,20.699-19.151,34.77-21.411
             c71.229-11.429,130.472,70.104,153.813,107.941
             C443.222,242.571,389.167,236.289,335.514,244.906z"




























































































































































































          fill={c.structure}
          style={{
            transformOrigin: '250px 250px',
            animation: animate ?
            `manif-fade-in 1.1s cubic-bezier(.4,0,.2,1) ${delay + 400}ms both` :
            'none'
          }} />
        

        {/* Detalle interno superior derecho — el trazo curvo dentro de la hoja chica/zona */}
        <path
          d="M414.567,199.57c-10.438-4.554-21.218-8.425-32.042-11.508
             c-5.307-1.509-10.844,1.567-12.356,6.88
             c-1.512,5.312,1.568,10.844,6.88,12.356
             c9.968,2.838,19.899,6.405,29.521,10.604
             c1.302,0.567,2.659,0.837,3.994,0.837
             c3.855,0,7.53-2.244,9.171-6.004
             C421.942,207.674,419.63,201.779,414.567,199.57z"
























          fill={c.structure}
          style={{
            animation: animate ?
            `manif-fade-in 1.1s cubic-bezier(.4,0,.2,1) ${delay + 600}ms both` :
            'none'
          }} />
        

        {/* Tallo + espiral como UN ÚNICO trazo continuo, hacia la DERECHA
                (lado de la hoja grande). Nace en x=200 (donde acabamos el bowl)
                y baja, se enrolla en sentido horario hacia la derecha, terminando
                con el puntito durazno en el centro. */}
        <g
          style={{
            transformOrigin: '210px 350px',
            animation: animate ?
            `manif-grow-stem 0.9s cubic-bezier(.2,.85,.2,1) ${delay + 1000}ms both` :
            'none'
          }}>
          
          <path
            d="M 200 232
               L 200 360
               C 200 380, 218 396, 240 396
               C 268 396, 290 374, 290 348
               C 290 322, 268 304, 244 304
               C 224 304, 208 318, 208 338
               C 208 354, 222 366, 238 366
               C 252 366, 264 354, 264 340
               C 264 328, 254 318, 242 318
               C 232 318, 224 326, 224 336"
            fill="none"
            stroke={c.structure}
            strokeWidth="18"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          
          {/* Punto durazno — al lado del tallo, donde lo dibujaste */}
          <circle
            cx="200"
            cy="370"
            r="11"
            fill={c.accent}
            style={{
              transformOrigin: '200px 370px',
              transformBox: 'fill-box',
              animation: animate ?
              `manif-pop 0.6s cubic-bezier(.2,1.6,.4,1) ${delay + 1500}ms both,
                   manif-pulse 3s ease-in-out ${delay + 2100}ms infinite` :
              'none'
            }} />
          
        </g>

        <style>{`
          @keyframes manif-grow-r {
            from { opacity: 0; transform: scale(0.6) translateX(20px); }
            to   { opacity: 1; transform: scale(1) translateX(0); }
          }
          @keyframes manif-grow-l {
            from { opacity: 0; transform: scale(0.6) translateX(-20px); }
            to   { opacity: 1; transform: scale(1) translateX(0); }
          }
          @keyframes manif-fade-in {
            from { opacity: 0; }
            to   { opacity: 1; }
          }
          @keyframes manif-grow-stem {
            from { opacity: 0; transform: scaleY(0); }
            to   { opacity: 1; transform: scaleY(1); }
          }
          @keyframes manif-pop {
            from { opacity: 0; transform: scale(0); }
            to   { opacity: 1; transform: scale(1); }
          }
          @keyframes manif-pulse {
            0%, 100% { transform: scale(1); }
            50%      { transform: scale(1.18); }
          }
        `}</style>
      </svg>
    </div>);

}

window.LogoManifiesto = LogoManifiesto;