// ─────────────────────────────────────────────────────────────
// Manifiesto · Login screen
// Estilo iOS — usuario recordado con avatar + Face ID prominente.
// Fondo crema, contraste con la welcome (verde profundo).
// ─────────────────────────────────────────────────────────────

function FaceIDIcon({ size = 28, color = '#FFFBF2', scanning = false }) {
  return (
    <svg width={size} height={size} viewBox="0 0 28 28" fill="none">
      {/* Esquinas */}
      <path d="M3 9V5a2 2 0 012-2h4" stroke={color} strokeWidth="1.8" strokeLinecap="round"/>
      <path d="M19 3h4a2 2 0 012 2v4" stroke={color} strokeWidth="1.8" strokeLinecap="round"/>
      <path d="M25 19v4a2 2 0 01-2 2h-4" stroke={color} strokeWidth="1.8" strokeLinecap="round"/>
      <path d="M9 25H5a2 2 0 01-2-2v-4" stroke={color} strokeWidth="1.8" strokeLinecap="round"/>
      {/* Cara */}
      <circle cx="11" cy="12" r="0.8" fill={color}/>
      <circle cx="17" cy="12" r="0.8" fill={color}/>
      <path d="M14 12v3.5" stroke={color} strokeWidth="1.5" strokeLinecap="round"/>
      <path d="M11.5 18c.8.7 1.6 1 2.5 1s1.7-.3 2.5-1" stroke={color} strokeWidth="1.5" strokeLinecap="round"/>
      {/* Línea de scan */}
      {scanning && (
        <line x1="3" y1="14" x2="25" y2="14" stroke="#E08E63" strokeWidth="1.5" strokeLinecap="round" style={{
          animation: 'scan-line 2s ease-in-out infinite',
        }}/>
      )}
    </svg>
  );
}

function LoginScreen({ onBack, onSuccess, onSwitchAccount }) {
  const [scanning, setScanning] = React.useState(false);
  const [authed, setAuthed] = React.useState(false);

  const triggerFaceID = () => {
    if (scanning || authed) return;
    setScanning(true);
    setTimeout(() => {
      setScanning(false);
      setAuthed(true);
      setTimeout(onSuccess, 800);
    }, 2200);
  };

  return (
    <div style={{
      width: '100%',
      height: '100%',
      background: '#F2EEE3',
      color: '#0E3A26',
      position: 'relative',
      overflow: 'hidden',
      fontFamily: '-apple-system, "SF Pro Display", system-ui, sans-serif',
      display: 'flex',
      flexDirection: 'column',
    }}>

      {/* Top nav */}
      <div style={{
        padding: '8px 20px 0',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        height: '52px',
      }}>
        <button onClick={onBack} style={{
          background: 'transparent',
          border: 'none',
          padding: '8px',
          margin: '-8px',
          cursor: 'pointer',
          display: 'flex',
          alignItems: 'center',
          gap: '4px',
          color: '#0E3A26',
          fontSize: '15px',
          fontWeight: 500,
        }}>
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
            <path d="M11 4l-5 5 5 5" stroke="#0E3A26" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </button>

        {/* Mini logo en nav */}
        <Fern size={28} palette="dark" animate={false} />

        <div style={{ width: '24px' }} />
      </div>

      {/* Main */}
      <div style={{
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '0 28px',
        position: 'relative',
      }}>

        {/* Bienvenida personal */}
        <div style={{
          fontSize: '13px',
          color: 'rgba(15,58,38,0.5)',
          fontWeight: 500,
          letterSpacing: '-0.2px',
          marginBottom: '10px',
          animation: 'fade-up 0.6s ease 100ms both',
        }}>
          Bienvenida de vuelta
        </div>
        <div style={{
          fontSize: '34px',
          fontWeight: 800,
          letterSpacing: '-1.5px',
          color: '#0E3A26',
          textAlign: 'center',
          animation: 'fade-up 0.6s ease 200ms both',
        }}>
          Hola, Camila
        </div>

        {/* Avatar grande con halo */}
        <div style={{
          marginTop: '40px',
          position: 'relative',
          width: '128px',
          height: '128px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          animation: 'fade-up 0.6s ease 300ms both',
        }}>
          {/* Halo verde sutil */}
          <div style={{
            position: 'absolute',
            inset: 0,
            borderRadius: '50%',
            background: 'radial-gradient(circle, rgba(31,122,75,0.12), transparent 70%)',
            transform: scanning ? 'scale(1.3)' : 'scale(1)',
            transition: 'transform 1.2s ease',
          }}/>
          {/* Anillo durazno cuando scanea */}
          {scanning && (
            <div style={{
              position: 'absolute',
              inset: '-8px',
              borderRadius: '50%',
              border: '2px solid #E08E63',
              animation: 'ring-pulse 1.4s ease-in-out infinite',
            }}/>
          )}
          {/* Avatar */}
          <div style={{
            width: '104px',
            height: '104px',
            borderRadius: '50%',
            background: 'linear-gradient(135deg, #F2B58A, #E08E63)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#FFFBF2',
            fontSize: '38px',
            fontWeight: 700,
            letterSpacing: '-1px',
            boxShadow: '0 18px 40px -16px rgba(224,142,99,0.5)',
            position: 'relative',
            zIndex: 1,
            border: '4px solid #FFFBF2',
          }}>
            {authed ? (
              <svg width="44" height="44" viewBox="0 0 44 44" fill="none" style={{
                animation: 'check-pop 0.5s cubic-bezier(.2,.8,.2,1.5) both',
              }}>
                <path d="M11 22l8 8 14-16" stroke="#FFFBF2" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            ) : 'C'}
          </div>
        </div>

        {/* Email — micro */}
        <div style={{
          marginTop: '18px',
          fontSize: '14px',
          color: 'rgba(15,58,38,0.55)',
          fontWeight: 500,
          animation: 'fade-up 0.6s ease 400ms both',
        }}>
          camila@hogar.app
        </div>

        {/* Status — cambia con scan */}
        <div style={{
          marginTop: '32px',
          height: '24px',
          fontSize: '14px',
          fontWeight: 600,
          color: authed ? '#1F7A4B' : (scanning ? '#E08E63' : 'rgba(15,58,38,0.5)'),
          letterSpacing: '-0.3px',
          transition: 'color 0.3s ease',
          animation: 'fade-up 0.6s ease 500ms both',
        }}>
          {authed ? 'Identidad confirmada' : (scanning ? 'Mirá tu cámara…' : 'Tocá para identificarte')}
        </div>
      </div>

      {/* Acciones */}
      <div style={{
        padding: '0 28px 40px',
        animation: 'fade-up 0.6s ease 600ms both',
      }}>
        {/* Face ID button — protagonista */}
        <button
          onClick={triggerFaceID}
          disabled={scanning || authed}
          style={{
            width: '100%',
            height: '60px',
            borderRadius: '18px',
            background: authed ? '#1F7A4B' : '#0E3A26',
            color: '#FFFBF2',
            fontSize: '16px',
            fontWeight: 700,
            letterSpacing: '-0.3px',
            border: 'none',
            cursor: scanning || authed ? 'default' : 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '12px',
            boxShadow: '0 14px 30px -10px rgba(15,58,38,0.4)',
            transition: 'all .25s ease',
            opacity: scanning && !authed ? 0.85 : 1,
          }}
        >
          <FaceIDIcon size={26} color="#FFFBF2" scanning={scanning} />
          {authed ? 'Entrando…' : (scanning ? 'Reconociendo' : 'Entrar con Face ID')}
        </button>

        {/* Alternativas */}
        <div style={{
          marginTop: '14px',
          display: 'flex',
          gap: '10px',
        }}>
          <button style={{
            flex: 1,
            height: '46px',
            borderRadius: '14px',
            background: 'transparent',
            border: '1px solid rgba(15,58,38,0.15)',
            color: '#0E3A26',
            fontSize: '13px',
            fontWeight: 500,
            cursor: 'pointer',
            letterSpacing: '-0.2px',
          }}>
            Usar contraseña
          </button>
          <button onClick={onSwitchAccount} style={{
            flex: 1,
            height: '46px',
            borderRadius: '14px',
            background: 'transparent',
            border: '1px solid rgba(15,58,38,0.15)',
            color: '#0E3A26',
            fontSize: '13px',
            fontWeight: 500,
            cursor: 'pointer',
            letterSpacing: '-0.2px',
          }}>
            Cambiar cuenta
          </button>
        </div>
      </div>

      <style>{`
        @keyframes fade-up {
          from { opacity: 0; transform: translateY(8px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        @keyframes scan-line {
          0%, 100% { transform: translateY(-6px); opacity: 0.6; }
          50%      { transform: translateY(6px); opacity: 1; }
        }
        @keyframes ring-pulse {
          0%, 100% { transform: scale(1); opacity: 0.7; }
          50%      { transform: scale(1.08); opacity: 1; }
        }
        @keyframes check-pop {
          from { opacity: 0; transform: scale(0.4); }
          to   { opacity: 1; transform: scale(1); }
        }
      `}</style>
    </div>
  );
}

window.LoginScreen = LoginScreen;
