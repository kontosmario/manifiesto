// ─────────────────────────────────────────────────────────────
// Manifiesto · Crear cuenta — multi-step
// 1. Nombre + email
// 2. Contraseña + Sign in with Apple opcional
// 3. ¿Solo o con familia? + invitación opcional
// ─────────────────────────────────────────────────────────────

function CreateAccountScreen({ onBack, onComplete }) {
  const [step, setStep] = React.useState(0);
  const [name, setName] = React.useState('');
  const [email, setEmail] = React.useState('');
  const [password, setPassword] = React.useState('');
  const [mode, setMode] = React.useState(null); // 'solo' | 'family'
  const [inviteEmail, setInviteEmail] = React.useState('');

  const totalSteps = 3;
  const progress = ((step + 1) / totalSteps) * 100;

  const canAdvance = () => {
    if (step === 0) return name.trim().length > 1 && email.includes('@');
    if (step === 1) return password.length >= 6;
    if (step === 2) return mode !== null;
    return false;
  };

  const next = () => {
    if (!canAdvance()) return;
    if (step < totalSteps - 1) setStep(s => s + 1);
    else onComplete();
  };

  const back = () => {
    if (step === 0) onBack();
    else setStep(s => s - 1);
  };

  return (
    <div style={{
      width: '100%',
      height: '100%',
      background: '#F2EEE3',
      color: '#0E3A26',
      position: 'relative',
      overflow: 'hidden',
      fontFamily: '-apple-system, "SF Pro Display", system-ui, sans-serif',
      display: 'flex',
      flexDirection: 'column',
    }}>

      {/* Top nav */}
      <div style={{
        padding: '8px 20px 0',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        height: '52px',
      }}>
        <button onClick={back} style={{
          background: 'transparent',
          border: 'none',
          padding: '8px',
          margin: '-8px',
          cursor: 'pointer',
          color: '#0E3A26',
        }}>
          <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
            <path d="M13 5l-6 6 6 6" stroke="#0E3A26" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </button>

        <Fern size={26} palette="dark" animate={false} />

        <div style={{
          fontSize: '13px',
          color: 'rgba(15,58,38,0.5)',
          fontWeight: 600,
          letterSpacing: '0.5px',
        }}>
          {step + 1}/{totalSteps}
        </div>
      </div>

      {/* Progress bar — orgánica */}
      <div style={{
        margin: '8px 20px 0',
        height: '3px',
        borderRadius: '2px',
        background: 'rgba(15,58,38,0.08)',
        overflow: 'hidden',
      }}>
        <div style={{
          height: '100%',
          width: `${progress}%`,
          background: 'linear-gradient(90deg, #1F7A4B, #E08E63)',
          borderRadius: '2px',
          transition: 'width 0.5s cubic-bezier(.2,.8,.2,1)',
        }}/>
      </div>

      {/* Contenido por step */}
      <div style={{
        flex: 1,
        padding: '32px 28px 0',
        display: 'flex',
        flexDirection: 'column',
        overflow: 'auto',
      }}>
        {step === 0 && <Step0 name={name} setName={setName} email={email} setEmail={setEmail} />}
        {step === 1 && <Step1 password={password} setPassword={setPassword} />}
        {step === 2 && <Step2 mode={mode} setMode={setMode} inviteEmail={inviteEmail} setInviteEmail={setInviteEmail} />}
      </div>

      {/* Botón continuar */}
      <div style={{
        padding: '16px 28px 32px',
        background: 'linear-gradient(to top, #F2EEE3 70%, transparent)',
      }}>
        <button
          onClick={next}
          disabled={!canAdvance()}
          style={{
            width: '100%',
            height: '56px',
            borderRadius: '18px',
            background: canAdvance() ? '#0E3A26' : 'rgba(15,58,38,0.15)',
            color: canAdvance() ? '#FFFBF2' : 'rgba(15,58,38,0.4)',
            fontSize: '16px',
            fontWeight: 700,
            letterSpacing: '-0.3px',
            border: 'none',
            cursor: canAdvance() ? 'pointer' : 'not-allowed',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '8px',
            boxShadow: canAdvance() ? '0 14px 30px -10px rgba(15,58,38,0.4)' : 'none',
            transition: 'all .25s ease',
          }}
        >
          {step === totalSteps - 1 ? 'Crear cuenta' : 'Continuar'}
          {canAdvance() && (
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <path d="M5 3l5 5-5 5" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          )}
        </button>
      </div>
    </div>
  );
}

// ─── Steps ───────────────────────────────────────────────────

function StepHeader({ kicker, title, sub }) {
  return (
    <div style={{ marginBottom: '32px', animation: 'step-in 0.5s ease both' }}>
      <div style={{
        fontSize: '11px',
        fontWeight: 800,
        letterSpacing: '2px',
        color: '#E08E63',
        textTransform: 'uppercase',
        marginBottom: '10px',
      }}>{kicker}</div>
      <div style={{
        fontSize: '28px',
        fontWeight: 800,
        letterSpacing: '-1.2px',
        color: '#0E3A26',
        lineHeight: 1.15,
        textWrap: 'balance',
      }}>{title}</div>
      {sub && <div style={{
        marginTop: '10px',
        fontSize: '14px',
        color: 'rgba(15,58,38,0.55)',
        lineHeight: 1.5,
      }}>{sub}</div>}
    </div>
  );
}

function FieldLabel({ children }) {
  return <div style={{
    fontSize: '11px',
    fontWeight: 700,
    letterSpacing: '1.5px',
    color: 'rgba(15,58,38,0.5)',
    textTransform: 'uppercase',
    marginBottom: '8px',
  }}>{children}</div>;
}

function Input({ value, onChange, placeholder, type = 'text', autoFocus }) {
  return (
    <input
      type={type}
      value={value}
      onChange={e => onChange(e.target.value)}
      placeholder={placeholder}
      autoFocus={autoFocus}
      style={{
        width: '100%',
        height: '56px',
        borderRadius: '16px',
        background: '#FFFBF2',
        border: '1px solid rgba(15,58,38,0.1)',
        padding: '0 18px',
        fontSize: '16px',
        fontWeight: 500,
        color: '#0E3A26',
        outline: 'none',
        fontFamily: 'inherit',
        letterSpacing: '-0.2px',
        transition: 'border-color .2s ease, box-shadow .2s ease',
        boxSizing: 'border-box',
      }}
      onFocus={e => {
        e.target.style.borderColor = '#1F7A4B';
        e.target.style.boxShadow = '0 0 0 3px rgba(31,122,75,0.12)';
      }}
      onBlur={e => {
        e.target.style.borderColor = 'rgba(15,58,38,0.1)';
        e.target.style.boxShadow = 'none';
      }}
    />
  );
}

// Step 0 — Nombre + email
function Step0({ name, setName, email, setEmail }) {
  return (
    <>
      <StepHeader
        kicker="01 · Conozcámonos"
        title="¿Cómo te llamamos?"
        sub="Tu nombre aparece en el feed familiar para que sepan quién compró qué."
      />

      <div style={{ marginBottom: '20px', animation: 'step-in 0.5s ease 100ms both' }}>
        <FieldLabel>Tu nombre</FieldLabel>
        <Input value={name} onChange={setName} placeholder="Camila" autoFocus />
      </div>

      <div style={{ animation: 'step-in 0.5s ease 200ms both' }}>
        <FieldLabel>Email</FieldLabel>
        <Input value={email} onChange={setEmail} placeholder="camila@hogar.app" type="email" />
      </div>

      {/* Apple sign in */}
      <div style={{
        marginTop: '32px',
        animation: 'step-in 0.5s ease 300ms both',
      }}>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '14px',
          marginBottom: '16px',
        }}>
          <div style={{ flex: 1, height: '1px', background: 'rgba(15,58,38,0.1)' }}/>
          <div style={{ fontSize: '11px', color: 'rgba(15,58,38,0.4)', fontWeight: 600, letterSpacing: '1px' }}>O</div>
          <div style={{ flex: 1, height: '1px', background: 'rgba(15,58,38,0.1)' }}/>
        </div>

        <button style={{
          width: '100%',
          height: '52px',
          borderRadius: '14px',
          background: '#000',
          color: '#fff',
          fontSize: '15px',
          fontWeight: 600,
          letterSpacing: '-0.2px',
          border: 'none',
          cursor: 'pointer',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '8px',
        }}>
          <svg width="16" height="16" viewBox="0 0 16 16" fill="#fff">
            <path d="M11.182 8.39c-.024-2.6 2.123-3.853 2.22-3.913-1.21-1.768-3.092-2.01-3.762-2.04-1.604-.16-3.13.943-3.943.943-.83 0-2.075-.92-3.412-.895-1.755.026-3.37 1.022-4.272 2.59-1.82 3.156-.466 7.825 1.305 10.388.866 1.255 1.897 2.66 3.247 2.61 1.305-.05 1.797-.842 3.376-.842 1.578 0 2.022.842 3.405.815 1.405-.024 2.297-1.275 3.156-2.535.992-1.456 1.4-2.864 1.425-2.937-.03-.014-2.732-1.046-2.756-4.184zM8.728 1.34c.715-.866 1.198-2.07 1.066-3.273-1.03.043-2.28.687-3.022 1.55-.665.764-1.247 1.99-1.09 3.17 1.149.09 2.33-.583 3.046-1.447z" transform="scale(0.75) translate(2 4)"/>
            <path d="M11.624 8.49c-.018-1.95 1.59-2.89 1.665-2.935-.908-1.327-2.32-1.508-2.823-1.53-1.203-.12-2.348.71-2.957.71-.622 0-1.557-.69-2.56-.67-1.317.02-2.527.766-3.205 1.943-1.366 2.366-.35 5.87.98 7.79.65.94 1.422 1.995 2.435 1.957.978-.038 1.348-.633 2.532-.633 1.184 0 1.518.633 2.555.612 1.054-.02 1.722-.957 2.366-1.902.745-1.092 1.05-2.148 1.069-2.203-.024-.01-2.05-.785-2.07-3.14zm-1.95-5.762c.537-.65.898-1.554.8-2.456-.773.032-1.71.515-2.267 1.163-.5.573-.935 1.493-.818 2.378.862.067 1.748-.437 2.285-1.085z"/>
          </svg>
          Continuar con Apple
        </button>
      </div>
    </>
  );
}

// Step 1 — Contraseña
function Step1({ password, setPassword }) {
  const strength = password.length === 0 ? 0 :
                   password.length < 6 ? 1 :
                   password.length < 10 ? 2 : 3;
  const strengthLabel = ['', 'Débil', 'Buena', 'Excelente'][strength];
  const strengthColor = ['', '#D85A4A', '#E08E63', '#1F7A4B'][strength];

  return (
    <>
      <StepHeader
        kicker="02 · Cuidá tu casa"
        title="Elegí una contraseña"
        sub="Usá al menos 6 caracteres. Vas a poder activar Face ID después."
      />

      <div style={{ animation: 'step-in 0.5s ease 100ms both' }}>
        <FieldLabel>Contraseña</FieldLabel>
        <Input value={password} onChange={setPassword} placeholder="••••••••" type="password" autoFocus />
      </div>

      {/* Strength indicator */}
      <div style={{
        marginTop: '14px',
        display: 'flex',
        alignItems: 'center',
        gap: '10px',
        animation: 'step-in 0.5s ease 200ms both',
      }}>
        <div style={{
          flex: 1,
          height: '4px',
          borderRadius: '2px',
          background: 'rgba(15,58,38,0.08)',
          display: 'flex',
          gap: '3px',
        }}>
          {[1, 2, 3].map(i => (
            <div key={i} style={{
              flex: 1,
              borderRadius: '2px',
              background: strength >= i ? strengthColor : 'transparent',
              transition: 'background .3s ease',
            }}/>
          ))}
        </div>
        <div style={{
          fontSize: '11px',
          fontWeight: 700,
          color: strengthColor || 'rgba(15,58,38,0.4)',
          letterSpacing: '0.5px',
          minWidth: '60px',
          textAlign: 'right',
        }}>{strengthLabel}</div>
      </div>

      {/* Tips */}
      <div style={{
        marginTop: '32px',
        padding: '18px 18px',
        borderRadius: '16px',
        background: 'rgba(31,122,75,0.06)',
        border: '1px solid rgba(31,122,75,0.1)',
        animation: 'step-in 0.5s ease 300ms both',
      }}>
        <div style={{
          fontSize: '12px',
          fontWeight: 700,
          color: '#1F7A4B',
          letterSpacing: '0.5px',
          marginBottom: '8px',
        }}>💡 Consejo</div>
        <div style={{
          fontSize: '13px',
          color: 'rgba(15,58,38,0.7)',
          lineHeight: 1.5,
        }}>
          Una frase corta es más fuerte que una palabra rara. <i>"verde-23-helecho"</i> es más segura que <i>"X8k!"</i>.
        </div>
      </div>
    </>
  );
}

// Step 2 — Solo o familia
function Step2({ mode, setMode, inviteEmail, setInviteEmail }) {
  return (
    <>
      <StepHeader
        kicker="03 · Tu hogar"
        title="¿Empezás solo o con tu familia?"
        sub="Podés invitar a alguien después si preferís explorar primero."
      />

      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', animation: 'step-in 0.5s ease 100ms both' }}>
        <ChoiceCard
          selected={mode === 'solo'}
          onClick={() => setMode('solo')}
          title="Empezar solo"
          sub="Yo voy registrando, después invito"
          icon="solo"
        />
        <ChoiceCard
          selected={mode === 'family'}
          onClick={() => setMode('family')}
          title="Invitar a alguien ahora"
          sub="Mi pareja, hermano, hijo, conviviente"
          icon="family"
        />
      </div>

      {/* Invitación inline si elige family */}
      {mode === 'family' && (
        <div style={{
          marginTop: '20px',
          animation: 'step-in 0.4s ease both',
        }}>
          <FieldLabel>Email de quien invitás</FieldLabel>
          <Input value={inviteEmail} onChange={setInviteEmail} placeholder="ana@hogar.app" type="email" autoFocus />
          <div style={{
            marginTop: '10px',
            fontSize: '12px',
            color: 'rgba(15,58,38,0.5)',
            lineHeight: 1.5,
          }}>
            Le llega un mail con tu invitación. Cuando acepte, ven todo en común.
          </div>
        </div>
      )}
    </>
  );
}

function ChoiceCard({ selected, onClick, title, sub, icon }) {
  return (
    <button onClick={onClick} style={{
      width: '100%',
      padding: '18px 18px',
      borderRadius: '18px',
      background: selected ? '#FFFBF2' : 'rgba(255,251,242,0.5)',
      border: selected ? '2px solid #1F7A4B' : '1px solid rgba(15,58,38,0.1)',
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      gap: '14px',
      textAlign: 'left',
      transition: 'all .2s ease',
      boxShadow: selected ? '0 8px 20px -8px rgba(31,122,75,0.25)' : 'none',
      fontFamily: 'inherit',
    }}>
      <div style={{
        width: '44px',
        height: '44px',
        borderRadius: '12px',
        background: selected ? '#1F7A4B' : 'rgba(15,58,38,0.06)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        flexShrink: 0,
        transition: 'background .2s ease',
      }}>
        {icon === 'solo' ? (
          <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
            <circle cx="11" cy="7" r="3.5" stroke={selected ? '#FFFBF2' : '#0E3A26'} strokeWidth="1.8"/>
            <path d="M4 19c0-3.5 3-6 7-6s7 2.5 7 6" stroke={selected ? '#FFFBF2' : '#0E3A26'} strokeWidth="1.8" strokeLinecap="round"/>
          </svg>
        ) : (
          <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
            <circle cx="7" cy="7" r="2.8" stroke={selected ? '#FFFBF2' : '#0E3A26'} strokeWidth="1.8"/>
            <circle cx="15" cy="7" r="2.8" stroke={selected ? '#FFFBF2' : '#0E3A26'} strokeWidth="1.8"/>
            <path d="M2 18c0-3 2-5 5-5s5 2 5 5" stroke={selected ? '#FFFBF2' : '#0E3A26'} strokeWidth="1.8" strokeLinecap="round"/>
            <path d="M10 18c0-3 2-5 5-5s5 2 5 5" stroke={selected ? '#FFFBF2' : '#0E3A26'} strokeWidth="1.8" strokeLinecap="round"/>
          </svg>
        )}
      </div>

      <div style={{ flex: 1 }}>
        <div style={{
          fontSize: '15px',
          fontWeight: 700,
          color: '#0E3A26',
          letterSpacing: '-0.3px',
          marginBottom: '2px',
        }}>{title}</div>
        <div style={{
          fontSize: '13px',
          color: 'rgba(15,58,38,0.55)',
          letterSpacing: '-0.1px',
        }}>{sub}</div>
      </div>

      {/* Radio */}
      <div style={{
        width: '22px',
        height: '22px',
        borderRadius: '50%',
        border: selected ? '6px solid #1F7A4B' : '2px solid rgba(15,58,38,0.2)',
        background: selected ? '#FFFBF2' : 'transparent',
        transition: 'all .2s ease',
        flexShrink: 0,
      }}/>
    </button>
  );
}

// Animación shared
if (typeof document !== 'undefined' && !document.getElementById('createacc-css')) {
  const s = document.createElement('style');
  s.id = 'createacc-css';
  s.textContent = `
    @keyframes step-in {
      from { opacity: 0; transform: translateY(10px); }
      to   { opacity: 1; transform: translateY(0); }
    }
  `;
  document.head.appendChild(s);
}

window.CreateAccountScreen = CreateAccountScreen;
