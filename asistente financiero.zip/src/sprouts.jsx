// Manifiesto · 8 variaciones de sprout (semilla recién germinada con 2 cotiledones)
// Estilo: geométrico, trazo grueso uniforme.
// Cada sprout es una función pura que recibe { color, accent } y devuelve los nodos SVG.
// Todos viven en un viewBox de 200×200 con el suelo conceptual en y=170.

const SW = 18; // stroke-width común

// ═══════════════════════════════════════════════════════════════
// 1 · CLÁSICO SIMÉTRICO — el arquetipo del brote
// Dos cotiledones ovalados saliendo de un tallo central recto.
// Personalidad: tierno + simétrico + determinado.
// ═══════════════════════════════════════════════════════════════
const Sprout1 = ({ color, accent }) => (
  <g>
    {/* Tallo */}
    <path d="M 100 170 L 100 100" stroke={color} strokeWidth={SW} strokeLinecap="round" fill="none"/>
    {/* Cotiledón izquierdo — gota inclinada */}
    <path
      d="M 100 100 C 70 100, 45 92, 38 70 C 50 60, 80 65, 95 90 Z"
      fill={color} stroke={color} strokeWidth={SW} strokeLinejoin="round"/>
    {/* Cotiledón derecho — espejo */}
    <path
      d="M 100 100 C 130 100, 155 92, 162 70 C 150 60, 120 65, 105 90 Z"
      fill={color} stroke={color} strokeWidth={SW} strokeLinejoin="round"/>
    {/* Punto acento — la semilla aún visible */}
    {accent && <circle cx="100" cy="170" r="9" fill={accent}/>}
  </g>
);

// ═══════════════════════════════════════════════════════════════
// 2 · ASIMÉTRICO ABIERTO — una hoja más grande
// Hoja izq pequeña, hoja der grande y elevada. Tallo recto.
// Personalidad: asimétrico + determinado.
// ═══════════════════════════════════════════════════════════════
const Sprout2 = ({ color, accent }) => (
  <g>
    <path d="M 100 170 L 100 95" stroke={color} strokeWidth={SW} strokeLinecap="round" fill="none"/>
    {/* Cotiledón izq pequeño */}
    <ellipse cx="78" cy="100" rx="22" ry="14" fill={color} transform="rotate(-25 78 100)"/>
    {/* Cotiledón der grande, más alto */}
    <ellipse cx="128" cy="78" rx="34" ry="18" fill={color} transform="rotate(20 128 78)"/>
    {accent && <circle cx="100" cy="170" r="9" fill={accent}/>}
  </g>
);

// ═══════════════════════════════════════════════════════════════
// 3 · CÍRCULOS PERFECTOS — minimalismo geométrico
// Dos círculos exactos sobre tallo recto. Lo más simple posible.
// Personalidad: minimalista + simétrico + tierno.
// ═══════════════════════════════════════════════════════════════
const Sprout3 = ({ color, accent }) => (
  <g>
    <path d="M 100 170 L 100 110" stroke={color} strokeWidth={SW} strokeLinecap="round" fill="none"/>
    <circle cx="72" cy="92" r="22" fill={color}/>
    <circle cx="128" cy="92" r="22" fill={color}/>
    {accent && <circle cx="100" cy="170" r="9" fill={accent}/>}
  </g>
);

// ═══════════════════════════════════════════════════════════════
// 4 · GOTAS HACIA ARRIBA — cotiledones puntiagudos
// Dos hojas en forma de gota apuntando hacia arriba+afuera.
// Personalidad: determinado + simétrico.
// ═══════════════════════════════════════════════════════════════
const Sprout4 = ({ color, accent }) => (
  <g>
    <path d="M 100 170 L 100 110" stroke={color} strokeWidth={SW} strokeLinecap="round" fill="none"/>
    {/* Gota izquierda */}
    <path
      d="M 100 110 C 90 100, 70 88, 55 60 C 40 80, 50 102, 75 108 Z"
      fill={color}/>
    {/* Gota derecha */}
    <path
      d="M 100 110 C 110 100, 130 88, 145 60 C 160 80, 150 102, 125 108 Z"
      fill={color}/>
    {accent && <circle cx="100" cy="170" r="9" fill={accent}/>}
  </g>
);

// ═══════════════════════════════════════════════════════════════
// 5 · TALLO CURVO — vivo, en movimiento
// Tallo con curva tipo S sutil, cotiledones inclinados hacia un lado.
// Personalidad: curvo + asimétrico + determinado.
// ═══════════════════════════════════════════════════════════════
const Sprout5 = ({ color, accent }) => (
  <g>
    <path
      d="M 100 170 C 100 150, 88 130, 96 100"
      stroke={color} strokeWidth={SW} strokeLinecap="round" fill="none"/>
    {/* Hoja izq — más baja, más chica */}
    <ellipse cx="74" cy="105" rx="24" ry="15" fill={color} transform="rotate(-18 74 105)"/>
    {/* Hoja der — más alta, más grande */}
    <ellipse cx="122" cy="86" rx="30" ry="17" fill={color} transform="rotate(15 122 86)"/>
    {accent && <circle cx="100" cy="170" r="9" fill={accent}/>}
  </g>
);

// ═══════════════════════════════════════════════════════════════
// 6 · COTILEDONES EN U — abrazo del brote
// Las dos hojas curvan hacia adentro formando una U abierta.
// Personalidad: tierno + simétrico + abrazante.
// ═══════════════════════════════════════════════════════════════
const Sprout6 = ({ color, accent }) => (
  <g>
    <path d="M 100 170 L 100 115" stroke={color} strokeWidth={SW} strokeLinecap="round" fill="none"/>
    {/* Arco izquierdo curvado hacia adentro */}
    <path
      d="M 100 115 C 70 115, 50 100, 50 70 C 65 60, 90 80, 100 105"
      stroke={color} strokeWidth={SW * 1.6} strokeLinecap="round" strokeLinejoin="round" fill="none"/>
    {/* Arco derecho */}
    <path
      d="M 100 115 C 130 115, 150 100, 150 70 C 135 60, 110 80, 100 105"
      stroke={color} strokeWidth={SW * 1.6} strokeLinecap="round" strokeLinejoin="round" fill="none"/>
    {accent && <circle cx="100" cy="170" r="9" fill={accent}/>}
  </g>
);

// ═══════════════════════════════════════════════════════════════
// 7 · HOJAS PENTÁGONO — geométrico estricto
// Dos formas hexagonales/almendradas perfectas, tallo recto.
// Personalidad: geométrico estricto + simétrico + determinado.
// ═══════════════════════════════════════════════════════════════
const Sprout7 = ({ color, accent }) => (
  <g>
    <path d="M 100 170 L 100 105" stroke={color} strokeWidth={SW} strokeLinecap="round" fill="none"/>
    {/* Almendra izq */}
    <path
      d="M 100 100 L 70 78 L 40 78 L 55 95 L 75 108 Z"
      fill={color} stroke={color} strokeWidth={SW * 0.8} strokeLinejoin="round"/>
    {/* Almendra der */}
    <path
      d="M 100 100 L 130 78 L 160 78 L 145 95 L 125 108 Z"
      fill={color} stroke={color} strokeWidth={SW * 0.8} strokeLinejoin="round"/>
    {accent && <circle cx="100" cy="170" r="9" fill={accent}/>}
  </g>
);

// ═══════════════════════════════════════════════════════════════
// 8 · BROTE NACIENTE — semilla partida + cotiledones cortos
// Una semilla partida en la base + dos cotiledones cortos asomando.
// Personalidad: tierno + recién nacido + asimétrico sutil.
// ═══════════════════════════════════════════════════════════════
const Sprout8 = ({ color, accent }) => (
  <g>
    {/* Línea de suelo / semilla */}
    <ellipse cx="100" cy="170" rx="28" ry="8" fill={color}/>
    {/* Tallito corto */}
    <path d="M 100 162 L 100 125" stroke={color} strokeWidth={SW} strokeLinecap="round" fill="none"/>
    {/* Cotiledón izq corto */}
    <path
      d="M 100 125 C 80 122, 62 110, 58 88 C 72 82, 92 100, 100 120"
      fill={color} stroke={color} strokeWidth={SW * 0.9} strokeLinejoin="round" strokeLinecap="round"/>
    {/* Cotiledón der corto, ligeramente más grande */}
    <path
      d="M 100 125 C 122 122, 142 108, 148 82 C 132 76, 108 96, 100 120"
      fill={color} stroke={color} strokeWidth={SW * 0.9} strokeLinejoin="round" strokeLinecap="round"/>
    {accent && <circle cx="100" cy="170" r="7" fill={accent}/>}
  </g>
);

const SPROUTS = [
  { id: 1, name: 'Clásico simétrico',    desc: 'Dos gotas ovaladas, tallo recto',           Comp: Sprout1 },
  { id: 2, name: 'Asimétrico abierto',   desc: 'Una hoja chica, una grande elevada',         Comp: Sprout2 },
  { id: 3, name: 'Círculos perfectos',   desc: 'Mínimo absoluto: dos círculos',              Comp: Sprout3 },
  { id: 4, name: 'Gotas hacia arriba',   desc: 'Cotiledones en V, determinado',              Comp: Sprout4 },
  { id: 5, name: 'Tallo curvo',          desc: 'En movimiento, vivo, asimétrico',            Comp: Sprout5 },
  { id: 6, name: 'Cotiledones en U',     desc: 'Hojas curvas que abrazan',                   Comp: Sprout6 },
  { id: 7, name: 'Geométrico estricto',  desc: 'Almendras, ángulos definidos',               Comp: Sprout7 },
  { id: 8, name: 'Brote naciente',       desc: 'Semilla visible + cotiledones cortos',       Comp: Sprout8 },
];

// ═══════════════════════════════════════════════════════════════
// CARD — un sprout en sus 3 versiones de color + wordmark abajo
// ═══════════════════════════════════════════════════════════════
function SproutCard({ id, name, desc, Comp }) {
  return (
    <div style={{
      width: '100%', height: '100%',
      background: '#FFFBF2',
      borderRadius: 24,
      padding: 36,
      display: 'flex',
      flexDirection: 'column',
      gap: 24,
    }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between' }}>
        <div>
          <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: 2, color: '#E08E63', textTransform: 'uppercase', marginBottom: 4 }}>
            Sprout {String(id).padStart(2, '0')}
          </div>
          <div style={{ fontSize: 22, fontWeight: 800, letterSpacing: -1, color: '#0E3A26' }}>{name}</div>
          <div style={{ fontSize: 12, color: 'rgba(15,58,38,0.55)', marginTop: 2 }}>{desc}</div>
        </div>
      </div>

      {/* 3 variantes de color en fila */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20, flex: 1 }}>
        {/* A · Verde sólido sobre crema */}
        <Tile bg="#F2EEE3" labelTop="A · Verde" labelBottom="#0E3A26 sobre crema">
          <SVGFrame>
            <Comp color="#0E3A26" accent={null}/>
          </SVGFrame>
          <Wordmark color="#0E3A26" accentColor="#E08E63"/>
        </Tile>

        {/* B · Verde + acento durazno */}
        <Tile bg="#F2EEE3" labelTop="B · Con acento" labelBottom="Verde + durazno">
          <SVGFrame>
            <Comp color="#0E3A26" accent="#E08E63"/>
          </SVGFrame>
          <Wordmark color="#0E3A26" accentColor="#E08E63"/>
        </Tile>

        {/* C · Crema sobre verde profundo */}
        <Tile bg="#0E3A26" labelTop="C · Dark mode" labelBottom="Crema sobre verde" dark>
          <SVGFrame>
            <Comp color="#FFFBF2" accent="#F2B58A"/>
          </SVGFrame>
          <Wordmark color="#FFFBF2" accentColor="#F2B58A"/>
        </Tile>
      </div>
    </div>
  );
}

function Tile({ bg, children, labelTop, labelBottom, dark }) {
  return (
    <div style={{
      background: bg,
      borderRadius: 16,
      padding: 24,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 18,
      border: dark ? 'none' : '1px solid rgba(15,58,38,0.06)',
    }}>
      <div style={{ alignSelf: 'flex-start' }}>
        <div style={{ fontSize: 9, fontWeight: 800, letterSpacing: 1.5, color: dark ? '#F2B58A' : '#E08E63', textTransform: 'uppercase' }}>
          {labelTop}
        </div>
        <div style={{ fontSize: 10, color: dark ? 'rgba(255,251,242,0.55)' : 'rgba(15,58,38,0.55)', marginTop: 2 }}>
          {labelBottom}
        </div>
      </div>
      {children}
    </div>
  );
}

function SVGFrame({ children }) {
  return (
    <svg viewBox="0 0 200 200" width="140" height="140" style={{ display: 'block' }}>
      {children}
    </svg>
  );
}

function Wordmark({ color, accentColor }) {
  return (
    <div style={{
      fontSize: 22,
      fontWeight: 800,
      letterSpacing: -1.1,
      color,
      lineHeight: 1,
      fontFamily: '-apple-system, "SF Pro Display", system-ui, sans-serif',
    }}>
      Manifiesto<span style={{ color: accentColor }}>.</span>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// HERO — el favorito en grande
// ═══════════════════════════════════════════════════════════════
function HeroSprout({ Comp, name }) {
  return (
    <div style={{
      width: '100%', height: '100%',
      background: '#0E3A26',
      borderRadius: 24,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 80,
      padding: 60,
      position: 'relative',
      overflow: 'hidden',
    }}>
      <div style={{ position: 'absolute', top: '-15%', left: '-10%', width: '50%', height: '50%', borderRadius: '50%', background: 'radial-gradient(circle, rgba(199,238,156,0.12), transparent 70%)', filter: 'blur(60px)' }}/>
      <div style={{ position: 'absolute', bottom: '-15%', right: '-10%', width: '50%', height: '50%', borderRadius: '50%', background: 'radial-gradient(circle, rgba(242,181,138,0.14), transparent 70%)', filter: 'blur(60px)' }}/>

      <div style={{ position: 'relative', zIndex: 1 }}>
        <svg viewBox="0 0 200 200" width="320" height="320">
          <Comp color="#FFFBF2" accent="#F2B58A"/>
        </svg>
      </div>

      <div style={{ position: 'relative', zIndex: 1, color: '#FFFBF2' }}>
        <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: 3, color: '#F2B58A', textTransform: 'uppercase', marginBottom: 14 }}>
          Logo · Sprout
        </div>
        <div style={{ fontSize: 84, fontWeight: 800, letterSpacing: -4, lineHeight: 1 }}>
          Manifiesto<span style={{ color: '#F2B58A' }}>.</span>
        </div>
        <div style={{ marginTop: 22, fontSize: 14, color: 'rgba(255,251,242,0.55)', maxWidth: 360, lineHeight: 1.6 }}>
          Una semilla recién germinada. Dos cotiledones — la primera forma de vida que aparece cuando algo empieza a crecer.
        </div>
      </div>
    </div>
  );
}

window.SPROUTS = SPROUTS;
window.SproutCard = SproutCard;
window.HeroSprout = HeroSprout;
