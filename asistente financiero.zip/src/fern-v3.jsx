// ─────────────────────────────────────────────────────────────
// Manifiesto · Fern v3 — botánico, asimétrico natural, centrado óptico
// ─────────────────────────────────────────────────────────────
// Cambios clave vs v2:
//  - Frondas en forma de hoja (path lágrima/teardrop), no elipses
//  - Frondas se CURVAN HACIA ARRIBA (como helecho real)
//  - Frondas más grandes y densas en la base, decrecientes hacia el ápice
//  - Espiral fiddlehead más prominente y orgánica
//  - Centrado óptico real: bbox visual ≈ (-30..30, -38..38) dentro del 100×100
//  - Movimiento sutil + opcional "live" mode para apps
// ─────────────────────────────────────────────────────────────

const FERN_PALETTES_V3 = {
  dark:   { stemA: '#1F7A4B', stemB: '#0E3A26', leafA: '#1F7A4B', leafB: '#0E3A26', tip: '#E08E63', tipDot: '#E08E63', tipRing: '#F2B58A' },
  light:  { stemA: '#8DD66A', stemB: '#C7EE9C', leafA: '#C7EE9C', leafB: '#FFFBF2', tip: '#F2B58A', tipDot: '#FFFBF2', tipRing: '#F2B58A' },
  hero:   { stemA: '#2E9E5F', stemB: '#0E3A26', leafA: '#1F7A4B', leafB: '#0E3A26', tip: '#E08E63', tipDot: '#FFFBF2', tipRing: '#F2B58A' },
  'mono-light': { stemA: '#FFFBF2', stemB: '#FFFBF2', leafA: '#FFFBF2', leafB: '#FFFBF2', tip: '#FFFBF2', tipDot: '#FFFBF2', tipRing: '#FFFBF2' },
  'mono-dark':  { stemA: '#0E3A26', stemB: '#0E3A26', leafA: '#0E3A26', leafB: '#0E3A26', tip: '#0E3A26', tipDot: '#0E3A26', tipRing: '#0E3A26' },
};

// ─────────────────────────────────────────────────────────────
// Geometría:
// - Raquis: curva en S sutil de (0, 38) hasta (-2, -22), terminando en fiddlehead centro (-8, -28)
// - Frondas: 6 pares (12 hojas) más 1 par chiquito en el ápice
// - Cada fronda es un path "leaf" (lágrima curvada hacia arriba)
// - Centro óptico del conjunto: aprox (0, 2) — corregido al renderizar
// ─────────────────────────────────────────────────────────────

// Path de una hoja de helecho: parte de base (0,0), apunta hacia (length, 0)
// con curva hacia arriba (y negativo). Width controla grosor.
function leafPath(length, width) {
  const w = width;
  const L = length;
  return `M 0 0
          C ${L * 0.15} ${-w * 0.4}, ${L * 0.45} ${-w}, ${L * 0.7} ${-w * 0.85}
          C ${L * 0.85} ${-w * 0.7}, ${L * 0.95} ${-w * 0.3}, ${L} 0
          C ${L * 0.85} ${w * 0.05}, ${L * 0.5} ${w * 0.15}, 0 0
          Z`;
}

// Punto y tangente sobre el raquis — t=0 base, t=1 cuello
function raquisAt(t) {
  // Raquis CASI vertical, centrado en x=0, pequeño quiebre al final hacia el rulo
  const pts = [
    { x:  0,  y:  38 },  // base
    { x:  0.5, y: 22 },
    { x:  0,  y:   8 },
    { x: -0.5, y: -8 },
    { x: -1.5, y: -20 },
    { x: -3,  y: -28 },  // cuello fiddlehead
  ];
  const u = t * (pts.length - 1);
  const i = Math.min(Math.floor(u), pts.length - 2);
  const f = u - i;
  const p0 = pts[i], p1 = pts[i + 1];
  const x = p0.x + (p1.x - p0.x) * f;
  const y = p0.y + (p1.y - p0.y) * f;
  // tangente (en grados, apuntando hacia el ápice)
  const dx = p1.x - p0.x;
  const dy = p1.y - p0.y;
  const ang = Math.atan2(dy, dx) * 180 / Math.PI;
  return { x, y, ang };
}

// ─────────────────────────────────────────────────────────────
// PINNAE — definición declarativa
// [t, length, width, side, lift, dark]
//   t = posición en raquis (0 base → 1 cuello)
//   length, width = tamaño
//   side = -1 izq, +1 der
//   lift = grados extra hacia arriba (más = más curvada hacia el sol)
//   dark = usar leafA (oscuro) vs leafB (claro)
// ─────────────────────────────────────────────────────────────
const PINNAE_V3 = [
  // Base — frondas grandes
  [0.05, 18, 6.5, -1, 22, true],
  [0.08, 17, 6.2,  1, 20, true],
  [0.20, 17, 6.0, -1, 25, true],
  [0.22, 16, 5.8,  1, 23, false],
  [0.36, 15, 5.4, -1, 28, true],
  [0.38, 14, 5.1,  1, 26, false],
  // Medio
  [0.52, 12, 4.5, -1, 32, false],
  [0.54, 11, 4.2,  1, 30, true],
  [0.66, 10, 3.7, -1, 36, false],
  [0.68,  9, 3.4,  1, 34, false],
  // Ápice
  [0.80,  7, 2.8, -1, 42, false],
  [0.82,  6, 2.5,  1, 40, false],
  [0.92,  4, 1.8, -1, 50, false],
];

function FernV3({
  size = 96,
  palette = 'dark',
  animate = true,
  delay = 0,
  iconMode = false, // true = sin padding, llena el viewBox
}) {
  const c = FERN_PALETTES_V3[palette] || FERN_PALETTES_V3.dark;
  const id = React.useId();
  const vb = iconMode ? '-32 -42 64 84' : '-50 -50 100 100';

  // Centrado óptico real con raquis vertical:
  // bbox visual ≈ x ∈ [-21, 21], y ∈ [-38, 38] → ya casi centrado.
  const offsetX = 0;
  const offsetY = 0;

  return (
    <svg
      width={size}
      height={size}
      viewBox={vb}
      style={{
        overflow: 'visible',
        animation: animate ? `fern3-rise 1s cubic-bezier(.2,.8,.2,1) ${delay}ms both` : 'none',
      }}
    >
      <g transform={`translate(${offsetX} ${offsetY}) scale(0.95)`}>
        <g style={{
          animation: animate ? `fern3-sway 9s ease-in-out ${delay + 1400}ms infinite` : 'none',
          transformOrigin: '0px 38px',
        }}>

          {/* ── RAQUIS ── doble trazo: sombra + claro encima */}
          <path
            d="M 0 38 C 0.5 22, 0 8, -0.5 -8 C -1.5 -20, -2 -25, -3 -28"
            fill="none"
            stroke={c.stemB}
            strokeWidth="3.2"
            strokeLinecap="round"
            style={{
              strokeDasharray: 80,
              strokeDashoffset: animate ? 80 : 0,
              animation: animate ? `fern3-stem-draw 1.1s cubic-bezier(.4,0,.2,1) ${delay + 200}ms forwards` : 'none',
            }}
          />
          <path
            d="M 0 38 C 0.5 22, 0 8, -0.5 -8 C -1.5 -20, -2 -25, -3 -28"
            fill="none"
            stroke={c.stemA}
            strokeWidth="1.4"
            strokeLinecap="round"
            opacity="0.9"
            style={{
              strokeDasharray: 80,
              strokeDashoffset: animate ? 80 : 0,
              animation: animate ? `fern3-stem-draw 1.1s cubic-bezier(.4,0,.2,1) ${delay + 300}ms forwards` : 'none',
            }}
          />

          {/* ── PINNAE ── frondas curvas hacia arriba */}
          {PINNAE_V3.map((p, i) => {
            const [t, len, w, side, lift, isDark] = p;
            const pos = raquisAt(t);
            // ángulo: tangente del raquis + perpendicular hacia el lado + lift hacia el ápice
            // tangente apunta hacia ápice (negativo en y al subir)
            // perpendicular = tangente ± 90°
            const baseAng = pos.ang + side * 90;
            // Lift: rotamos hacia el ápice (hacia arriba en este orientación = hacia ang del raquis)
            const ang = baseAng - side * lift; // signo invertido para que ambas se curven hacia arriba

            return (
              <g
                key={i}
                transform={`translate(${pos.x} ${pos.y}) rotate(${ang}) scale(${side === 1 ? 1 : 1} ${side === 1 ? 1 : -1})`}
                style={{
                  opacity: animate ? 0 : 1,
                  transformOrigin: '0 0',
                  animation: animate
                    ? `fern3-leaf 0.6s cubic-bezier(.2,.9,.3,1.1) ${delay + 600 + i * 60}ms forwards`
                    : 'none',
                }}
              >
                <path
                  d={leafPath(len, w)}
                  fill={isDark ? c.leafA : c.leafB}
                />
                {/* Vena central — sutil */}
                <path
                  d={`M 0 0 Q ${len * 0.5} ${-w * 0.35}, ${len} 0`}
                  fill="none"
                  stroke={c.stemB}
                  strokeWidth="0.5"
                  strokeLinecap="round"
                  opacity="0.35"
                />
              </g>
            );
          })}

          {/* ── FIDDLEHEAD ── cabeza enrollada con punto durazno */}
          {/* Posicionado encima del cuello del raquis (-3, -28) */}
          <g
            transform="translate(-1 -33)"
            style={{
              animation: animate ? `fern3-curl 1.4s cubic-bezier(.2,.8,.2,1) ${delay + 500}ms both` : 'none',
              transformOrigin: '-4px -32px',
            }}
          >
            {/* Espiral fiddlehead — más vueltas para que se lea como rulo */}
            <path
              d={spiralPathV3(0, 0, 7, 1.6, 720, 90)}
              fill="none"
              stroke={c.tip}
              strokeWidth="1.8"
              strokeLinecap="round"
            />
            {/* Punto durazno en el centro del rulo */}
            <circle
              cx={spiralCenterV3(0, 0, 7, 1.6, 720, 90).x}
              cy={spiralCenterV3(0, 0, 7, 1.6, 720, 90).y}
              r="1.8"
              fill={c.tipDot}
              style={{
                transformOrigin: 'center',
                transformBox: 'fill-box',
                animation: animate ? `fern3-pulse 2.6s ease-in-out ${delay + 1900}ms infinite` : 'none',
              }}
            />
          </g>
        </g>
      </g>
    </svg>
  );
}

function spiralPathV3(cx, cy, r0, decay, totalDeg, startDeg) {
  const steps = 80;
  let d = '';
  for (let i = 0; i <= steps; i++) {
    const frac = i / steps;
    const ang = (startDeg + frac * totalDeg) * Math.PI / 180;
    const r = r0 / Math.pow(decay, frac * 1.8);
    const x = cx + Math.cos(ang) * r;
    const y = cy + Math.sin(ang) * r;
    d += (i === 0 ? 'M ' : 'L ') + x.toFixed(2) + ' ' + y.toFixed(2) + ' ';
  }
  return d;
}

function spiralCenterV3(cx, cy, r0, decay, totalDeg, startDeg) {
  const ang = (startDeg + totalDeg) * Math.PI / 180;
  const r = r0 / Math.pow(decay, 1.8);
  return { x: cx + Math.cos(ang) * r, y: cy + Math.sin(ang) * r };
}

if (typeof document !== 'undefined' && !document.getElementById('fern3-css')) {
  const s = document.createElement('style');
  s.id = 'fern3-css';
  s.textContent = `
    @keyframes fern3-rise {
      from { opacity: 0; transform: translateY(6px) scale(0.97); }
      to   { opacity: 1; transform: translateY(0) scale(1); }
    }
    @keyframes fern3-sway {
      0%, 100% { transform: rotate(-1.4deg); }
      50%      { transform: rotate(1.4deg); }
    }
    @keyframes fern3-stem-draw {
      from { stroke-dashoffset: 80; }
      to   { stroke-dashoffset: 0; }
    }
    @keyframes fern3-leaf {
      0%   { opacity: 0; }
      100% { opacity: 1; }
    }
    @keyframes fern3-curl {
      from { opacity: 0; transform: rotate(-200deg) scale(0.3); }
      to   { opacity: 1; transform: rotate(0) scale(1); }
    }
    @keyframes fern3-pulse {
      0%, 100% { transform: scale(1); }
      50%      { transform: scale(1.5); }
    }
  `;
  document.head.appendChild(s);
}

window.FernV3 = FernV3;
